﻿namespace X4
{
    public static class License
    {
        public const string CapitalEquipment = "capitalequipment";
        public const string MilitaryEquipment = "militaryequipment";
        public const string Police = "police";
        public const string StationIllegal = "station_illegal";
    }
}