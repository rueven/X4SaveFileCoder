﻿using System.Xml;
using Power.Utilities;
using X4.Constants;
using X4.Objects.Interfaces;

namespace X4.Objects.Implementations
{
    class Pilot
        : Component<IPilot>, IPilot
    {
        #region Constructor
        public Pilot(XmlDocument document)
            : base(document) { }
        #endregion

        #region Properties
        public string RawSeed => this
            .Node
            .SelectSingleNode("npcseed/@seed")
            .Value;

        public long Seed => this
            .RawSeed
            .WithSelect(DataHelper.ToNullableLong)
            .Value;
        #endregion

        public override IPilot Clone()
        {
            var output = new Pilot(this.Document);
            output.SetActiveNode(this.Node);
            return output;
        }

        public IPilot SetSeed(long value)
        {
            this.Node
                .SelectSingleNode("npcseed/@seed")
                .Value = value.ToString();
            return this;
        }

        public IPilot SetTraitValue(CharacterTrait trait, CharacterTraitValue value)
        {
            var traitString = trait
                .ToString()
                .ToLower();
            var numericValue = (int)value;
            this.Node
                .ResolveOrCreate(this.Document, $"traits/skill[@type='{traitString}']/@value")
                .Value = numericValue.ToString();
            return this;
        }
    }
}
