﻿using System.Collections.Generic;
using System.Linq;
using X4.Extensions;
using X4.Models.Interfaces;
using X4.Objects.Interfaces;
using X4.Services.Interfaces;

namespace X4.Objects.Implementations
{
    class CharacterLibraryYielder
        : ICharacterLibraryYielder
    {
        public CharacterLibraryYielder(ICharacterLibraryService service, ISaveFile file, bool checkPilots = true, bool checkPassengers = true)
        {
            var list = service
                .Fetch()
                .ToList();
            file?.ForEachPlayerShip(ship =>
            {
                if (checkPilots)
                {
                    ship.Pilot(pilot =>
                    {
                        var match = list
                            .FirstOrDefault(x => x.IsMatch(pilot));
                        if (match != null)
                        {
                            list.Remove(match);
                        }
                    });
                }
                if (checkPassengers)
                {
                    ship.ForEachPassenger(passenger =>
                    {
                        var match = list
                            .FirstOrDefault(x => x.IsMatch(passenger));
                        if (match != null)
                        {
                            list.Remove(match);
                        }
                    });
                }
            });
            this.BluePrints = list;
        }

        protected IReadOnlyList<IReadOnlyCharacterBluePrint> BluePrints { get; }
        private int Cursor { get; set; } = 0;

        public void AssignUniform<T>(ICharacter<T> character)
            where T : class, ICharacter<T>
        {
            var isInRange = this.Cursor < this.BluePrints.Count;
            if (!isInRange)
            {
                return;
            }
            var bluePrint = this
                .BluePrints[this.Cursor];
            character
                .SetSeed(bluePrint.Seed)
                .SetModel(bluePrint.Model);
            this.Cursor += 1;
        }
    }
}
