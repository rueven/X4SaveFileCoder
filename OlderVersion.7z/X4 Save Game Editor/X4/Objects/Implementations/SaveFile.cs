﻿using Power.Utilities;
using System;
using System.Xml;
using X4.Constants;
using X4.Objects.Interfaces;

namespace X4.Objects.Implementations
{
    public class SaveFile
        : ISaveFile
    {
        #region Constructor
        public SaveFile(XmlDocument document, string filePath, bool isCompressed)
        {
            this.Document = document;
            this.FilePath = filePath;
            IsCompressed = isCompressed;
        }
        #endregion

        #region Properties
        public bool IsCompressed { get; }
        public string FilePath { get; }
        public XmlDocument Document { get; }
        #endregion

        #region Ships
        public ISaveFile FindShipByCode(string code, Action<IShip> method)
        {
            var node = this
                .Document
                .SelectSingleNode($@"//component[@class='ship_s' or @class='ship_m' or @class='ship_l' or @class='ship_xl'][@code='{code}']");
            if (node != null)
            {
                var ship = new Ship(this.Document);
                ship.SetActiveNode(node);
                method(ship);
            }
            return this;
        }

        public ISaveFile ForEachShip(Action<IShip> method)
        {
            var nodes = this
                .Document
                .SelectNodes($@"//component[@class='ship_s' or @class='ship_m' or @class='ship_l' or @class='ship_xl']");
            var ship = new Ship(this.Document);
            foreach (XmlNode node in nodes)
            {
                ship.SetActiveNode(node);
                method(ship);
            }
            return this;
        }

        public ISaveFile ForEachPlayerShip(Action<IShip> method)
        {
            var nodes = this
                .Document
                .SelectNodes($@"//component[@class='ship_s' or @class='ship_m' or @class='ship_l' or @class='ship_xl'][@owner='player']");
            var ship = new Ship(this.Document);
            foreach (XmlNode node in nodes)
            {
                ship.SetActiveNode(node);
                method(ship);
            }
            return this;
        }

        public ISaveFile ForEachNonPlayerShip(Action<IShip> method)
        {
            var nodes = this
                .Document
                .SelectNodes($@"//component[@class='ship_s' or @class='ship_m' or @class='ship_l' or @class='ship_xl'][not(@owner='player')]");
            var ship = new Ship(this.Document);
            foreach (XmlNode node in nodes)
            {
                ship.SetActiveNode(node);
                method(ship);
            }
            return this;
        }
        #endregion

        #region Stations
        public ISaveFile FindStationByCode(string code, Action<IStation> method)
        {
            var node = this
                .Document
                .SelectSingleNode($@"//component[@class='station'][@code='{code}']");
            if (node != null)
            {
                var station = new Station(this.Document);
                station.SetActiveNode(node);
                method(station);
            }
            return this;
        }

        public ISaveFile ForEachStation(Action<IStation> method)
        {
            var nodes = this
                .Document
                .SelectNodes($@"//component[@class='station']");
            var station = new Station(this.Document);
            foreach (XmlNode node in nodes)
            {
                station.SetActiveNode(node);
                method(station);
            }
            return this;
        }

        public ISaveFile ForEachPlayerStation(Action<IStation> method)
        {
            var nodes = this
                .Document
                .SelectNodes($@"//component[@class='station'][@owner='player']");
            var station = new Station(this.Document);
            foreach (XmlNode node in nodes)
            {
                station.SetActiveNode(node);
                method(station);
            }
            return this;
        }

        public ISaveFile ForEachNonPlayerStation(Action<IStation> method)
        {
            var nodes = this
                .Document
                .SelectNodes($@"//component[@class='station'][not(@owner='player')]");
            var station = new Station(this.Document);
            foreach (XmlNode node in nodes)
            {
                station.SetActiveNode(node);
                method(station);
            }
            return this;
        }
        #endregion

        public ISaveFile ForEachPlayerCharacter(Action<CharacterType, ICharacter> method)
        {
            this.ForEachPlayerShip(ship =>
            {
                ship.Pilot(x =>
                {
                    method(CharacterType.Pilot, x);
                });
                ship.ForEachPassenger(x =>
                {
                    method(x.Type, x);
                });
            });
            this.ForEachPlayerStation(station =>
            {
                station.Manager(x =>
                {
                    method(CharacterType.Manager, x);
                });
                station.ShipTrader(x =>
                {
                    method(CharacterType.ShipTrader, x);
                });
            });
            return this;
        }

        public ISaveFile Player(Action<IPlayer> method)
        {
            var node = this
                .Document
                .SelectSingleNode("//component[@class='player']");
            if (node != null)
            {
                var player = new Player(this.Document);
                player.SetActiveNode(node);
                method(player);
            }
            return this;
        }

        public ISaveFile RemoveAllCurrentBuildRequirements()
        {
            this.Document
                .SelectNodes("//component[@class='buildprocessor']/resources/ware/@amount")
                .Iterate(x => x.Value = "0");
            return this;
        }

        public ISaveFile WithNamedNpc(string name, Action<IPilot> method)
        {
            var pilot = new Pilot(this.Document);
            this.Document
                .SelectNodes($"//component[@class='npc'][@name='{name}']")
                .Iterate(node =>
                {
                    pilot
                        .SetActiveNode(node);
                    method
                        ?.Invoke(pilot);
                });
            return this;
        }

        public ISaveFile SetVariable(string name, string value)
        {
            //<value name="$CoverShip" type="component" value="[0x48767b6]"/
            this.Document
                .SelectSingleNode($"//value[@name='${name}']")
                .Attributes["value"]
                .Value = value;
            return this;
        }
    }
}