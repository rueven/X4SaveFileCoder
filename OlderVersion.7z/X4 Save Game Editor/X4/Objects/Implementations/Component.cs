﻿using Power.Utilities;
using System.Xml;

namespace X4.Objects.Implementations
{
    abstract class Component<T> : NodeEditor
        where T : class
    {
        #region Constructor
        protected Component(XmlDocument document)
            : base(document) { }
        #endregion

        #region Properties
        public string Model => this
            .Node
            .SelectSingleNode("@macro")
            .Value;

        public string Name => this
            .Node
            .SelectSingleNode("@name")
            ?.Value;

        public string Code => this
            .Node
            .SelectSingleNode("@code")
            .Value;
        #endregion

        #region Methods
        public T SetModel(string model)
        {
            this.Node
                .SelectSingleNode("@macro")
                .Value = model;
            return this as T;
        }

        public T SetName(string name)
        {
            this.Node
                .ResolveOrCreate(this.Document, "@name")
                .Value = name;
            return this as T;
        }

        public T SetCode(string code)
        {
            this.Node
                .SelectSingleNode("@code")
                .Value = code;
            return this as T;
        }
        #endregion

        public abstract T Clone();
    }
}
