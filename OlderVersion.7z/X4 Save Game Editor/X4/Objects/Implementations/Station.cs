﻿using Power.Utilities;
using System;
using System.Collections.Generic;
using System.Xml;
using System.Xml.Linq;
using X4.Objects.Interfaces;

namespace X4.Objects.Implementations
{
    class Station
        : Component<IStation>, IStation
    {
        #region Constructor
        public Station(XmlDocument document)
            : base(document) { }
        #endregion

        public string Owner => this
            .Node
            .SelectSingleNode("@owner")
            .Value;

        public override IStation Clone()
        {
            var output = new Station(this.Document);
            output.SetActiveNode(this.Node);
            return output;
        }

        public IReadOnlyList<string> GetListOfStationModules() => this
            .Node
            .SelectNodes($@"connections/connection[@connection=""modules""]/component/@macro")
            ?.WithSelect(x =>
            {
                var output = new List<string>();
                x.Iterate(node => output.Add(node.Value));
                return output;
            }) ?? new List<string>();

        public IStation Manager(Action<IPilot> method)
        {
            var managerControlComponentPointer = this
                .Node
                .SelectSingleNode(@"control/post[@id='manager']/@component");
            if (managerControlComponentPointer != null)
            {
                var managerNode = this
                    .Node
                    .SelectSingleNode($"//component[@class='npc'][@id='{managerControlComponentPointer.Value}']");
                if (managerNode != null)
                {
                    var pilot = new Pilot(this.Document);
                    pilot.SetActiveNode(managerNode);
                    method(pilot);
                }
            }
            return this;
        }

        public IStation ShipTrader(Action<IPilot> method)
        {
            var node = this
                .Node
                .SelectSingleNode(@".//component[@class='npc'][entity[@post='shiptrader']]");
            if (node != null)
            {
                var pilot = new Pilot(this.Document);
                pilot.SetActiveNode(node);
                method(pilot);
            }
            return this;
        }

        public IStation InventoryTraders(Action<IPilot> method)
        {
            var nodes = this
                .Node
                .SelectNodes(@".//component[@class='npc'][entity[@type='trader']]");
            foreach (XmlNode node in nodes)
            {
                var pilot = new Pilot(this.Document);
                pilot.SetActiveNode(node);
                method(pilot);
            }
            return this;
        }
    }
}
