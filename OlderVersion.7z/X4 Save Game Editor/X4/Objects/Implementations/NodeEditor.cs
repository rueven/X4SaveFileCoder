﻿using System.Xml;

namespace X4.Objects.Implementations
{
    abstract class NodeEditor
    {
        #region Constructor
        protected NodeEditor(XmlDocument document)
        {
            this.Document = document;
        }
        #endregion

        #region Properties
        public XmlDocument Document { get; }
        public XmlNode Node { get; private set; }
        #endregion

        #region Methods
        public void SetActiveNode(XmlNode node)
        {
            this.Node = node;
        }
        #endregion
    }
}
