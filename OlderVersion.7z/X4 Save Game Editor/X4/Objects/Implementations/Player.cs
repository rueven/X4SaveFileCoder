﻿using System.Linq;
using System.Xml;
using Power.Utilities;
using X4.Constants;
using X4.Objects.Interfaces;

namespace X4.Objects.Implementations
{
    internal class Player
        : Component<IPlayer>, IPlayer
    {
        public Player(XmlDocument document)
            : base(document)
        { }

        public long Money => this
            .Document
            .SelectSingleNode("savegame/universe/factions/faction[@id='player']/account/@amount")
            .Value
            .WithSelect(DataHelper.ToNullableInt64) ?? 0;

        public IPlayer AddBluePrint(string name)
        {
            var playerBluePrints = this
                .Node
                .SelectSingleNode("blueprints");
            var node = playerBluePrints
                .ResolveOrCreate(this.Document, $"blueprint[@ware='{name}']");
            return this;
        }

        public IPlayer RemoveBluePrint(string name)
        {
            var node = this
                .Node
                .SelectSingleNode($"blueprints/blueprint[@ware='{name}']");
            if (node != null)
            {
                node.ParentNode
                    .RemoveChild(node);
            }
            return this;
        }

        public override IPlayer Clone()
        {
            var output = new Player(this.Document);
            output.SetActiveNode(this.Node);
            return output;
        }

        public IPlayer AddInventory(string name, int? amount = null)
        {
            var playerInventory = this
                .Node
                .SelectSingleNode("inventory");
            var node = playerInventory
                .ResolveOrCreate(this.Document, $"ware[@ware='{name}']");
            if (amount.HasValue)
            {
                node.ResolveOrCreate(this.Document, "@amount")
                    .Value = amount.Value.ToString();
            }
            return this;
        }

        public IPlayer AddLicense(string name, params string[] faction)
        {
            var factions = faction
                .Aggregate(string.Empty, (x, y) => $"{x} {y}");
            this.Document
                .ResolveOrCreate($"savegame/universe/factions/faction[@id='player']/licenses/license[@type='{name}']/@factions")
                .Value = factions;
            return this;
        }

        public IPlayer ReadEnclopedia()
        {
            this.Node
                .SelectNodes("known//entry/@read")
                .Iterate(x => x.Value = "1");
            return this;
        }

        public IPlayer SetMoney(long value)
        {
            this.Document
                .SelectSingleNode("savegame/universe/factions/faction[@id='player']/account/@amount")
                .Value = value.ToString();
            return this;
        }

        public IPlayer SetRelation(string faction, double value)
        {
            this.Document
                .SelectSingleNode($"savegame/universe/factions/faction[@id='{faction}']/relations")
                .ResolveOrCreate(this.Document, "relation[@faction='player']/@relation")
                .Value = value.ToString();
            return this;
        }
    }
}
