﻿using Power.Utilities;
using System;
using System.Collections.Generic;
using System.Xml;
using X4.Constants;
using X4.Objects.Interfaces;
using static System.Net.Mime.MediaTypeNames;
using static X4.Constants.BluePrints;

namespace X4.Objects.Implementations
{
    class Ship
        : Component<IShip>, IShip
    {
        #region Constructor
        public Ship(XmlDocument document)
            : base(document) { }
        #endregion

        #region Properties
        public string Class => this
            .Node
            .SelectSingleNode("@class")
            .Value;

        public string Owner => this
            .Node
            .SelectSingleNode("@owner")
            .Value;

        public ShipSize? Size => this
            .Class
            .WithSelect(shipClass =>
            {
                switch (shipClass)
                {
                    case "ship_s": return ShipSize.Small;
                    case "ship_m": return ShipSize.Medium;
                    case "ship_l": return ShipSize.Large;
                    case "ship_xl": return ShipSize.ExtraLarge;
                    default: return (ShipSize?)null;
                }
            });
        #endregion

        public override IShip Clone()
        {
            var output = new Ship(this.Document);
            output.SetActiveNode(this.Node);
            return output;
        }

        public IShip ForEachPassenger(Action<IPassenger> method)
        {
            var nodes = this
                .Node
                .SelectNodes(@"people/person");
            var passenger = new Passenger(this.Document);
            foreach (XmlNode node in nodes)
            {
                passenger.SetActiveNode(node);
                method(passenger);
            }
            return this;
        }

        public IShip RemoveAllPassengers()
        {
            var xmlNode = this
                .Node
                .SelectSingleNode(@"people");
            xmlNode
                .RemoveAll();
            return this;
        }

        public IShip Pilot(Action<IPilot> method)
        {
            var node = this
                .Node//<entity type="officer" post="aipilot"/>
                .SelectSingleNode(@"connections/connection[@connection='con_cockpit'][@macro='con_cockpit']/component[@class='cockpit']/connections/connection[component[@class='npc']]/component[@class='npc'][entity[@type='officer'][@post='aipilot']]");
            if (node != null)
            {
                var pilot = new Pilot(this.Document);
                pilot.SetActiveNode(node);
                method(pilot);
            }
            return this;
        }

        public IShip WithThrusterType(string type)
        {
            var node = this
                .Node
                .SelectSingleNode("@thruster");
            if (node != null)
            {
                node.Value = type;
            }
            return this;
        }

        public IShip WithEngineModification(double forwardThrust, double strafeThrust, double rotationThrust, double travelThrust, double travelStartThrust, double travelAttackTime, double travelReleaseTime, double travelChargeTime)
        {
            this.Node
                .ResolveOrCreate(this.Document, "modification/engine[@ware='mod_engine_travelthrust_01_mk3']")
                .With(engine =>
                {
                    engine.ResolveOrCreate(this.Document, "@forwardthrust").Value = forwardThrust.ToString();
                    engine.ResolveOrCreate(this.Document, "@strafethrust").Value = strafeThrust.ToString();
                    engine.ResolveOrCreate(this.Document, "@rotationthrust").Value = rotationThrust.ToString();
                    engine.ResolveOrCreate(this.Document, "@travelthrust").Value = travelThrust.ToString();
                    engine.ResolveOrCreate(this.Document, "@travelstartthrust").Value = travelStartThrust.ToString();
                    engine.ResolveOrCreate(this.Document, "@travelattacktime").Value = travelAttackTime.ToString();
                    engine.ResolveOrCreate(this.Document, "@travelreleasetime").Value = travelReleaseTime.ToString();
                    engine.ResolveOrCreate(this.Document, "@travelchargetime").Value = travelChargeTime.ToString();
                });
            return this;
        }

        public IShip WithEngineRotationModification(double forwardThrust, double strafeThrust, double rotationThrust)
        {
            this.Node
                .ResolveOrCreate(this.Document, "modification/engine[@ware='mod_engine_rotationthrust_01_mk3']")
                .With(engine =>
                {
                    engine.ResolveOrCreate(this.Document, "@forwardthrust").Value = forwardThrust.ToString();
                    engine.ResolveOrCreate(this.Document, "@strafethrust").Value = strafeThrust.ToString();
                    engine.ResolveOrCreate(this.Document, "@rotationthrust").Value = rotationThrust.ToString();
                });
            return this;
        }

        public IShip WithStreamlinedHullChassisModification(double mass, double drag)
        {
            var modification = this
                .Node
                .ResolveOrCreate(this.Document, $"modification/ship[@ware='mod_ship_mass_01_mk3']");
            modification
                .ResolveOrCreate(modification.OwnerDocument, "@mass")
                .Value = mass.ToString();
            modification
                .ResolveOrCreate(modification.OwnerDocument, "@drag")
                .Value = drag.ToString();
            return this;
        }

        public IShip WithNoChassisModification()
        {
            var chassisModificationNode = this
                .Node
                .SelectNodes("modification/ship");
            if (chassisModificationNode != null && chassisModificationNode.Count > 0)
            {
                foreach (XmlNode node in chassisModificationNode)
                {
                    node.ParentNode
                        .RemoveChild(node);
                }
            }
            return this;
        }

        public IShip WithScanProtectedChassisModication()
        {
            var modification = this
                .Node
                .ResolveOrCreate(this.Document, $"modification/ship[@ware='mod_ship_hidecargo_01']");
            modification
                .ResolveOrCreate(modification.OwnerDocument, "@hidecargochance")
                .Value = "1";
            return this;
        }

        public IShip WithPaintJob(string paint)
        {
            this.Node
                .ResolveOrCreate(this.Document, $"modification/paint")
                .With(node =>
                {
                    node.ResolveOrCreate(this.Document, "@ware")
                        .Value = paint;
                    node.Attributes
                        .RemoveNamedItem("generated");
                });
            return this;
        }

        public IShip WithShieldsModification(double capacity, double rechargeDelay, double rechargeRate)
        {
            var shieldsNode = this
                .Node
                .ResolveOrCreate(this.Document, "shields");
            var groupNode = shieldsNode
                .SelectSingleNode("group[not(@*)]");
            if (groupNode == null)
            {
                groupNode = this
                    .Document
                    .CreateElement(null, "group", null);
                shieldsNode
                    .AppendChild(groupNode);
            }
            var newNode = groupNode
                .ResolveOrCreate(this.Document, "modification")
                .WithSelect(shields =>
                {
                    shields.ResolveOrCreate(this.Document, "@ware").Value = "mod_shield_capacity_02_mk3";
                    shields.ResolveOrCreate(this.Document, "@capacity").Value = capacity.ToString();
                    shields.ResolveOrCreate(this.Document, "@rechargedelay").Value = rechargeDelay.ToString();
                    shields.ResolveOrCreate(this.Document, "@rechargerate").Value = rechargeRate.ToString();
                    return shields
                        .ParentNode
                        .ParentNode;
                });
            newNode
                .SelectSingleNode("group")
                .Attributes
                .RemoveNamedItem("context");
            this.Node
                .RemoveChild(newNode);
            var placementNode = this
                .Node
                .SelectSingleNode("ammunition");
            if (placementNode != null)
            {
                placementNode
                    .ParentNode
                    .InsertBefore(newNode, placementNode);
            }
            return this;
        }

        public IShip WithNoShieldsModification()
        {
            var shieldsNode = this
                .Node
                .ResolveOrCreate(this.Document, "shields");
            var groupNode = shieldsNode
                .SelectSingleNode("group[not(@*)]");
            if (groupNode == null)
            {
                groupNode = this
                    .Document
                    .CreateElement(null, "group", null);
                shieldsNode
                    .AppendChild(groupNode);
            }
            var shieldModification = groupNode
                .SelectSingleNode("modification");
            shieldModification
                .ParentNode
                .RemoveChild(shieldModification);
            return this;
        }

        public IShip WithWeaponModificationInSlot(int slot, double damage, double reload, double speed, double rotationSpeed)
        {
            this.WithWeaponSlot(slot, node =>
            {
                node.ResolveOrCreate(this.Document, "component/modification[@ware='mod_weapon_speed_01_mk3']")
                    .With(weapon =>
                    {
                        weapon.ResolveOrCreate(this.Document, "@damage").Value = damage.ToString();
                        weapon.ResolveOrCreate(this.Document, "@reload").Value = reload.ToString();
                        weapon.ResolveOrCreate(this.Document, "@speed").Value = speed.ToString();
                        weapon.ResolveOrCreate(this.Document, "@rotationspeed").Value = rotationSpeed.ToString();
                    });
            });
            return this;
        }
        
        public IShip WithWeaponTypeInSlot(int slot, string weapon)
        {
            this.WithWeaponSlot(slot, node =>
            {
                var component = node
                  .SelectSingleNode("component");
                if (component != null)
                {
                    component.ResolveOrCreate(this.Document, "@macro").Value = weapon;
                    component.ResolveOrCreate(this.Document, "@class").Value = "weapon";
                }
            });
            return this;
        }
        
        public IShip WithWeaponModifications(double damage, double reload, double speed, double rotationSpeed)
        {
            this.ForEachWeapon(node =>
            {
                node.ResolveOrCreate(this.Document, "component/modification[@ware='mod_weapon_speed_01_mk3']")
                    .With(weapon =>
                    {
                        weapon.ResolveOrCreate(this.Document, "@damage").Value = damage.ToString();
                        weapon.ResolveOrCreate(this.Document, "@reload").Value = reload.ToString();
                        weapon.ResolveOrCreate(this.Document, "@speed").Value = speed.ToString();
                        weapon.ResolveOrCreate(this.Document, "@rotationspeed").Value = rotationSpeed.ToString();
                    });
            });
            return this;
        }

        public IShip WithTurretModifications(double speed, double damage, double rotationSpeed, double reload)
        {
            this.ForEachTurret(node =>
            {
                node.ResolveOrCreate(this.Document, "component/modification")
                    .With(modification =>
                    {
                        modification.ResolveOrCreate(this.Document, "@ware").Value = "mod_weapon_speed_01_mk3";
                        modification.ResolveOrCreate(this.Document, "@damage").Value = damage.ToString();
                        modification.ResolveOrCreate(this.Document, "@speed").Value = speed.ToString();
                        modification.ResolveOrCreate(this.Document, "@reload").Value = reload.ToString();
                        modification.ResolveOrCreate(this.Document, "@rotationspeed").Value = rotationSpeed.ToString();
                        //modification.ResolveOrCreate(this.Document, "@lifetime").Value = lifetime.ToString();
                    });
            });
            return this;
        }

        public IShip WithNoTurretModifications()
        {
            this.ForEachTurret(node =>
            {
                var component = node
                    .SelectSingleNode("component");
                var modification = component
                    .SelectSingleNode("modification");
                if (modification != null)
                {
                    component
                        .RemoveChild(modification);
                }
            });
            return this;
        }

        public IShip WithCapitalShipTurretModifications(double capacity, double rechargeDelay, double rechargeRate, double speed, double damage, double rotationSpeed, double reload)
        {
            this.Node
                .SelectNodes("shields/group")
                .Iterate(node =>
                {
                    node.SelectNodes("modification")
                        .Iterate(child =>
                        {
                            node.RemoveChild(child);
                        });
                    node.ResolveOrCreate(this.Document, "modification")
                        .With(modification =>
                        {
                            modification.ResolveOrCreate(this.Document, "@ware").Value = "mod_shield_capacity_02_mk3";
                            modification.ResolveOrCreate(this.Document, "@capacity").Value = capacity.ToString();
                            modification.ResolveOrCreate(this.Document, "@rechargedelay").Value = rechargeDelay.ToString();
                            modification.ResolveOrCreate(this.Document, "@rechargerate").Value = rechargeRate.ToString();
                        })
                        .ResolveOrCreate(this.Document, "weapon")
                        .With(modification =>
                        {
                            modification.ResolveOrCreate(this.Document, "@ware").Value = "mod_weapon_speed_01_mk3";
                            modification.ResolveOrCreate(this.Document, "@damage").Value = damage.ToString();
                            modification.ResolveOrCreate(this.Document, "@speed").Value = speed.ToString();
                            modification.ResolveOrCreate(this.Document, "@reload").Value = reload.ToString();
                            modification.ResolveOrCreate(this.Document, "@rotationspeed").Value = rotationSpeed.ToString();
                        });
                });
            return this;
        }

        public void ExtractAllWeaponsXml(IList<string> target)
        {
            this.ForEachWeapon(x =>
            {
                if (!target.Contains(x.OuterXml))
                {
                    target.Add(x.OuterXml);
                }
            });
        }

        public IShip WithWeaponsType(string weapon)
        {
            this.ForEachWeapon(node =>
            {
                var component = node
                  .SelectSingleNode("component");
                if (component != null)
                {
                    component.ResolveOrCreate(this.Document, "@macro").Value = weapon;
                }
            });
            return this;
        }

        public IShip WithShieldType(string type)
        {
            this.ForEachShield(node =>
            {
                var component = node
                    .SelectSingleNode("component");
                if (component != null)
                {
                    component.ResolveOrCreate(this.Document, "@macro").Value = type;
                }
            });
            return this;
        }

        public IShip WithReplaceShieldType(string targetType, string newType)
        {
            this.ForEachShield(node =>
            {
                var component = node
                    .SelectSingleNode("component");
                if (component != null)
                {
                    var shieldMacroNode = component
                        .SelectSingleNode("@macro");
                    if (shieldMacroNode.Value == targetType)
                    {
                        shieldMacroNode.Value = newType;
                    }
                }
            });
            return this;
        }

        public IShip WithSplitBeamTurrets()
        {
            this.ForEachTurret(node =>
            {
                var component = node
                    .SelectSingleNode("component");
                if (component != null)
                {
                    component.ResolveOrCreate(this.Document, "@macro").Value = "turret_spl_m_beam_01_mk1_macro";
                    component.ResolveOrCreate(this.Document, "@connection").Value = "con_beam_turret_01";
                    component.ResolveOrCreate(this.Document, "@lastshottime").Value = "117117.245";
                    component.ResolveOrCreate(this.Document, "@attackmethod").Value = "lowattentionattack";
                    component.ResolveOrCreate(this.Document, "@attacktime").Value = "113301.762";
                    component.ResolveOrCreate(this.Document, "@shipattacktime").Value = "113301.762";
                    component
                        .ResolveOrCreate(this.Document, "animations")
                        .With(animations =>
                        {
                            animations.InnerXml = @"
					<animation part='detail_xl_rotator'>
						<part time='117990.222' sequence='turret_deactivating turret_inactive' />
					</animation>
					<animation part='part_socket'>
						<part time='117990.222' sequence='turret_deactivating turret_inactive' />
					</animation>
					<animation part='detail_xl_gun'>
						<part time='117990.222' sequence='turret_deactivating turret_inactive' />
					</animation>
					<animation part='detail_xl_barrel'>
						<part time='117990.222' sequence='turret_deactivating turret_inactive' />
					</animation>
					<animation part='anim_lights'>
						<part time='117990.222' sequence='turret_deactivating turret_inactive' />
						<texture>
							<channel channel='1'>
								<value time='117990.222' sequence='turret_deactivating turret_inactive' property='u_offset' />
							</channel>
						</texture>
					</animation>
					<animation part='fx_gun_decals'>
						<part time='117990.222' sequence='turret_deactivating turret_inactive' />
					</animation>
					<animation part='fx_barrel_decal'>
						<part time='117990.222' sequence='turret_deactivating turret_inactive' />
					</animation>
					<animation light='xu arealight01'>
						<float time='117990.222' sequence='turret_deactivating turret_inactive' property='intensity' />
					</animation>
					<animation light='xu arealight002'>
						<float time='117990.222' sequence='turret_deactivating turret_inactive' property='intensity' />
					</animation>".Replace("'", "\"");
                        });
                }
            });
            return this;
        }

        public IShip WithSplitFlakTurrets()
        {
            this.ForEachTurret(node =>
            {
                var component = node
                    .SelectSingleNode("component");
                if (component != null)
                {
                    component.ResolveOrCreate(this.Document, "@macro").Value = "turret_spl_m_flak_01_mk1_macro";
                    component.ResolveOrCreate(this.Document, "@connection").Value = "con_flak_turret";
                    component.ResolveOrCreate(this.Document, "@lastshottime").Value = "121956.876";
                    component.Attributes.RemoveNamedItem("attackmethod");
                    component.Attributes.RemoveNamedItem("attacktime");
                    component.Attributes.RemoveNamedItem("shipattacktime");
                    component
                        .ResolveOrCreate(this.Document, "animations")
                        .With(animations =>
                        {
                            animations.InnerXml = @"
					<animation part='part_rotator'>
						<part time='121956.876' sequence='turret_inactive turret_activating turret_active'>
							<control current='turret_active' />
						</part>
					</animation>
					<animation part='part_socket'>
						<part time='121956.876' sequence='turret_inactive turret_activating turret_active'>
							<control current='turret_active' />
						</part>
					</animation>
					<animation part='part_gun'>
						<part time='121956.876' sequence='turret_inactive turret_activating turret_active'>
							<control current='turret_active' />
						</part>
					</animation>
					<animation part='fx_gun_decal'>
						<part time='121956.876' sequence='turret_inactive turret_activating turret_active'>
							<control current='turret_active' />
						</part>
					</animation>
					<animation part='part_barrel'>
						<part time='121956.876' sequence='turret_inactive turret_activating turret_active'>
							<control current='turret_active' />
						</part>
					</animation>
					<animation part='anim_lights'>
						<part time='121956.876' sequence='turret_inactive turret_activating turret_active'>
							<control current='turret_active' />
						</part>
						<texture>
							<channel channel='1'>
								<value time='121956.876' sequence='turret_inactive turret_activating turret_active' property='u_offset'>
									<control current='turret_active' />
								</value>
							</channel>
						</texture>
					</animation>
					<animation light='xu arealight01'>
						<float time='121956.876' sequence='turret_inactive turret_activating turret_active' property='intensity'>
							<control current='turret_active' />
						</float>
					</animation>
					<animation light='xu arealight002'>
						<float time='121956.876' sequence='turret_inactive turret_activating turret_active' property='intensity'>
							<control current='turret_active' />
						</float>
					</animation>".Replace("'", "\"");
                        });
                }
            });
            return this;
        }

        public IShip WithEngineType(string type)
        {
            this.ForEachEngine(node =>
            {
                var component = node
                    .SelectSingleNode("component");
                if (component != null)
                {
                    component.ResolveOrCreate(this.Document, "@macro").Value = type;
                }
            });
            return this;
        }

        private void ClearNodeChildren(XmlNode node)
        {
            var nodesToClear = new List<XmlNode>()
                .With(x => node.ChildNodes.Iterate(x.Add));
            nodesToClear
                .ForEach(x => node.RemoveChild(x));
        }

        private void ForEachTurret(Action<XmlNode> method)
        {
            this.Node
                .SelectNodes("connections/connection[starts-with(@connection, 'con_') and contains(@connection, 'turret')]/component[@class='turret']/..")
                .Iterate(method);
        }

        private void ForEachEngine(Action<XmlNode> method)
        {
            this.Node
                .SelectNodes("connections/connection[starts-with(@connection, 'con_') and contains(@connection, 'engine')]/component[@class='engine']/..")
                .Iterate(method);
        }

        private void ForEachShield(Action<XmlNode> method)
        {
            this.Node
                .SelectNodes("connections/connection[starts-with(@connection, 'con_') and contains(@connection, 'shield')]/component[@class='shieldgenerator']/..")
                .Iterate(method);
        }
        
        private void ForEachWeapon(Action<XmlNode> method)
        {
            this.Node
                .SelectNodes("connections/connection[starts-with(@connection, 'con_') and contains(@connection, 'weapon')]/component[@class='weapon']/..")
                .Iterate(method);
        }

        private void WithWeaponSlot(int slot, Action<XmlNode> method)
        {
            var node = this
                .SelectFirstSingleNonNullNode
                (
                    $"connections/connection[@connection='con_primaryweapon_{slot.ToString("D2")}']",
                    $"connections/connection[@connection='con_primaryweapon_{slot.ToString("D3")}']",
                    $"connections/connection[@connection='con_primaryweapon_{slot.ToString("D4")}']",
                    $"connections/connection[@connection='con_secondaryweapon_{slot.ToString("D2")}']",
                    $"connections/connection[@connection='con_secondaryweapon_{slot.ToString("D3")}']",
                    $"connections/connection[@connection='con_secondaryweapon_{slot.ToString("D4")}']",
                    $"connections/connection[@connection='con_weapon_{slot.ToString("D2")}']",
                    $"connections/connection[@connection='con_weapon_{slot.ToString("D3")}']",
                    $"connections/connection[@connection='con_weapon_{slot.ToString("D4")}']"
                );
            if (node != null)
            {
                method(node);
            }
        }

        private XmlNode SelectFirstSingleNonNullNode(params string[] paths)
        {
            foreach (var path in paths)
            {
                var node = this
                    .Node
                    .SelectSingleNode(path);
                if (node != null)
                {
                    return node;
                }
            }
            return null;
        }
    }
}