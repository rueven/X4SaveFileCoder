﻿using System;
using System.Linq;
using X4.Objects.Interfaces;

namespace X4.Objects.Implementations
{
    public class ShipCoder
        : IShipCoder
    {
        public ShipCoder(string code, Func<IShip, bool> selector, int seed)
        {
            this.Code = code;
            this.Selector = selector;
            this.Counter = seed;
        }

        public string Code { get; }
        public Func<IShip, bool> Selector { get; }
        public int Counter { get; private set; }

        public void Encode(IShip ship)
        {
            if (this.Selector(ship))
            {
                if (this.IsCodified(ship))
                {
                    return;
                }
                ship.SetCode($"{this.Code}-{this.Counter.ToString("D3")}");
                this.Counter += 1;
            }
        }

        public void Initialize(ISaveFile file)
        {
            var maxValue = -1;
            file.ForEachPlayerShip(ship =>
            {
                if (this.IsCodified(ship))
                {
                    var id = ship
                        .Code
                        .Split('-')
                        .Last();
                    var value = Convert
                        .ToInt32(id);
                    if (value > maxValue)
                    {
                        maxValue = value;
                    }
                }
            });
            this.Counter = maxValue + 1;
        }

        private bool IsCodified(IShip ship)
        {
            return ship
                .Code
                .StartsWith(this.Code);
        }
    }
}
