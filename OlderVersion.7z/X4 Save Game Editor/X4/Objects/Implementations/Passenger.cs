﻿using Power.Utilities;
using System.Xml;
using X4.Constants;
using X4.Objects.Interfaces;

namespace X4.Objects.Implementations
{
    class Passenger
        : NodeEditor, IPassenger
    {
        #region Constructor
        public Passenger(XmlDocument document)
            : base(document) { }
        #endregion

        #region Properties
        public string RawType => this
            .Node
            .SelectSingleNode("@role")
            .Value;

        public string RawSeed => this
            .Node
            .SelectSingleNode("npcseed/@seed")
            .Value;

        public long Seed => this
            .RawSeed
            .WithSelect(DataHelper.ToNullableLong)
            .Value;

        public CharacterType Type => this
            .RawType
            .WithSelect(x => DataHelper.ToEnum(x, CharacterType.Service));

        public string Model => this
            .Node
            .SelectSingleNode("@macro")
            .Value;
        #endregion

        public IPassenger SetSeed(long value)
        {
            this.Node
                .SelectSingleNode("npcseed/@seed")
                .Value = value.ToString();
            return this;
        }

        public IPassenger SetTraitValue(CharacterTrait trait, CharacterTraitValue value)
        {
            var traitString = trait
                .ToString()
                .ToLower();
            var numericValue = (int)value;
            this.Node
                .ResolveOrCreate(this.Document, $"skill[@type='{traitString}']/@value")
                .Value = numericValue.ToString();
            return this;
        }

        public IPassenger SetModel(string name)
        {
            this.Node
                .SelectSingleNode("@macro")
                .Value = name;
            return this;
        }
    }
}
