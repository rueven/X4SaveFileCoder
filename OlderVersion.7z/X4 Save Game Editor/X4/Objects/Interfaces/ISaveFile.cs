﻿using System;
using X4.Constants;

namespace X4.Objects.Interfaces
{
    public interface ISaveFile
    {
        #region Stations
        ISaveFile ForEachStation(Action<IStation> method);
        ISaveFile ForEachPlayerStation(Action<IStation> method);
        ISaveFile ForEachNonPlayerStation(Action<IStation> method);
        ISaveFile FindStationByCode(string code, Action<IStation> method);
        #endregion

        #region Ships
        ISaveFile ForEachShip(Action<IShip> method);
        ISaveFile ForEachPlayerShip(Action<IShip> method);
        ISaveFile ForEachNonPlayerShip(Action<IShip> method);
        ISaveFile FindShipByCode(string code, Action<IShip> method);
        #endregion


        ISaveFile ForEachPlayerCharacter(Action<CharacterType, ICharacter> method);
        ISaveFile RemoveAllCurrentBuildRequirements();
        ISaveFile WithNamedNpc(string name, Action<IPilot> method);
        
        ISaveFile Player(Action<IPlayer> method);
        ISaveFile SetVariable(string name, string value);
    }
}
