﻿using System;
using System.Collections.Generic;

namespace X4.Objects.Interfaces
{
    public interface IStation
        : IComponent<IStation>
    {
        string Owner { get; }

        IStation Manager(Action<IPilot> method);
        IStation ShipTrader(Action<IPilot> method);
        IStation InventoryTraders(Action<IPilot> method);

        IReadOnlyList<string> GetListOfStationModules();
    }
}
