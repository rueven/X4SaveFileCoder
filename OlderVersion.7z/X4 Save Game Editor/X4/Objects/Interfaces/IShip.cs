﻿using System;
using System.Collections.Generic;
using X4.Constants;

namespace X4.Objects.Interfaces
{
    public interface IShip
        : IComponent<IShip>
    {
        string Class { get; }
        string Owner { get; }
        ShipSize? Size { get; }
        IShip ForEachPassenger(Action<IPassenger> method);
        IShip RemoveAllPassengers();
        IShip Pilot(Action<IPilot> method);
        IShip WithThrusterType(string type);
        IShip WithShieldType(string type);
        IShip WithReplaceShieldType(string targetType, string newType);
        IShip WithEngineType(string type);
        IShip WithSplitBeamTurrets();
        IShip WithSplitFlakTurrets();
        IShip WithEngineModification(double forwardThrust = 1.3, double strafeThrust = 1.45, double rotationThrust = 1.2, double travelThrust = 1.3, double travelStartThrust = 1.2, double travelAttackTime = .7, double travelReleaseTime = 1, double travelChargeTime = .8);
        IShip WithEngineRotationModification(double forwardThrust, double strafeThrust, double rotationThrust);
        IShip WithNoChassisModification();
        IShip WithStreamlinedHullChassisModification(double mass = .8, double drag = .7);
        IShip WithScanProtectedChassisModication();
        IShip WithNoTurretModifications();
        IShip WithTurretModifications(double speed = 1.15, double damage = 1.3, double rotationSpeed = 1.3, double reload = 1.1);
        IShip WithCapitalShipTurretModifications(double capacity = 1.3, double rechargeDelay = .7, double rechargeRate = 1.7, double speed = 1.15, double damage = 1.3, double rotationSpeed = 1.3, double reload = 1.1);
        IShip WithPaintJob(string paint = "paintmod_0019");
        IShip WithShieldsModification(double capacity = 1.3, double rechargeDelay = .7, double rechargeRate = 1.7);
        IShip WithNoShieldsModification();
        IShip WithWeaponTypeInSlot(int slot, string weapon = "weapon_gen_s_gatling_01_mk2_macro");
        IShip WithWeaponModificationInSlot(int slot, double damage = 1.5, double reload = 1.5, double speed = 1.5, double rotationSpeed = 1.5);
        IShip WithWeaponsType(string weapon = "weapon_gen_s_gatling_01_mk2_macro");
        IShip WithWeaponModifications(double damage = 1.75D, double reload = 1.5D, double speed = 2D, double rotationSpeed = 1.5D);
        void ExtractAllWeaponsXml(IList<string> target);
    }
}
