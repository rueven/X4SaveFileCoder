﻿namespace X4.Objects.Interfaces
{
    public interface IShipCoder
    {
        void Initialize(ISaveFile file);
        void Encode(IShip ship);
    }
}
