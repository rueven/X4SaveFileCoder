﻿namespace X4.Objects.Interfaces
{
    public interface IComponent<T>
        where T : class
    {
        string Name { get; }
        string Code { get; }
        string Model { get; }

        T SetName(string name);
        T SetCode(string code);
        T SetModel(string model);

        T Clone();
    }
}
