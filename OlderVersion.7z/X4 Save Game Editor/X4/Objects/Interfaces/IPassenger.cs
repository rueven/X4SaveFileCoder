﻿using X4.Constants;

namespace X4.Objects.Interfaces
{
    public interface IPassenger
        : ICharacter<IPassenger>
    {
        CharacterType Type { get; }
        string Model { get; }
        IPassenger SetModel(string name);
    }
}
