﻿namespace X4.Objects.Interfaces
{
    public interface IPilot
        : IComponent<IPilot>, ICharacter<IPilot>
    {
        new string Model { get; }
        new IPilot SetModel(string model);
    }
}
