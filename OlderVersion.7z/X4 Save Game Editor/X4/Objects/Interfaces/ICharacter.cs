﻿using X4.Constants;

namespace X4.Objects.Interfaces
{
    public interface ICharacter
    {
        string Model { get; }
        long Seed { get; }
    }

    public interface ICharacter<T> : ICharacter
        where T : class
    {
        T SetModel(string model);
        T SetSeed(long value);
        T SetTraitValue(CharacterTrait trait, CharacterTraitValue value);
    }
}
