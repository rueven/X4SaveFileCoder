﻿namespace X4.Objects.Interfaces
{
    public interface IPlayer
    {
        string Model { get; }
        long Money { get; }
        IPlayer SetModel(string model);
        IPlayer SetMoney(long value);
        IPlayer AddLicense(string name, params string[] faction);
        IPlayer AddInventory(string name, int? amount = null);
        IPlayer ReadEnclopedia();
        IPlayer SetRelation(string faction, double value);
        IPlayer AddBluePrint(string name);
        IPlayer RemoveBluePrint(string name);
    }
}