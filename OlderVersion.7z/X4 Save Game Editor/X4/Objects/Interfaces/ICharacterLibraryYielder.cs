﻿namespace X4.Objects.Interfaces
{
    public interface ICharacterLibraryYielder
    {
        void AssignUniform<T>(ICharacter<T> character)
            where T : class, ICharacter<T>;
    }
}
