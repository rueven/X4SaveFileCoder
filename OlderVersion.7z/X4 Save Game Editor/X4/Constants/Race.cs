﻿namespace X4.Constants
{
    public enum Race
    {
        Generic,
        Argon,
        Teladi,
        Split,
        Paranid,
        Khak,
        Xenon
    }
}
