﻿namespace X4.Constants
{
    public static partial class BluePrints
    {
        public static class Thrusters
        {
            public static class Large
            {
                public static class AllRound
                {
                    public const string Mk1 = "thruster_gen_l_allround_01_mk1";
                    public const string Mk2 = "thruster_gen_l_allround_01_mk2";
                    public const string Mk3 = "thruster_gen_l_allround_01_mk3";
                }
            }

            public static class Medium
            {
                public static class AllRound
                {
                    public const string Mk1 = "thruster_gen_m_allround_01_mk1";
                    public const string Mk2 = "thruster_gen_m_allround_01_mk2";
                    public const string Mk3 = "thruster_gen_m_allround_01_mk3";
                }

                public static class Combat
                {
                    public const string Mk1 = "thruster_gen_m_combat_01_mk1";
                    public const string Mk2 = "thruster_gen_m_combat_01_mk2";
                    public const string Mk3 = "thruster_gen_m_combat_01_mk3";
                }
            }

            public static class Small
            {
                public static class AllRound
                {
                    public const string Mk1 = "thruster_gen_s_allround_01_mk1";
                    public const string Mk2 = "thruster_gen_s_allround_01_mk2";
                    public const string Mk3 = "thruster_gen_s_allround_01_mk3";
                }

                public static class Combat
                {
                    public const string Mk1 = "thruster_gen_s_combat_01_mk1";
                    public const string Mk2 = "thruster_gen_s_combat_01_mk2";
                    public const string Mk3 = "thruster_gen_s_combat_01_mk3";
                }
            }

            public static class ExtraLarge
            {
                public static class AllRound
                {
                    public const string Mk1 = "thruster_gen_xl_allround_01_mk1";
                    public const string Mk2 = "thruster_gen_xl_allround_01_mk2";
                    public const string Mk3 = "thruster_gen_xl_allround_01_mk3";
                }
            }
        }

        public static class Engines
        {
            public static class Terran
            {
                public static class Large
                {
                    public static class AllRound
                    {
                        public const string Mk1 = "engine_ter_l_allround_01_mk1";
                    }

                    public static class Travel
                    {
                        public const string Mk1 = "engine_ter_l_travel_01_mk1";
                    }
                }

                public static class Medium
                {
                    public static class AllRound
                    {
                        public const string Mk1 = "engine_ter_m_allround_01_mk1";
                        public const string Mk2 = "engine_ter_m_allround_01_mk2";
                        public const string Mk3 = "engine_ter_m_allround_01_mk3";
                    }

                    public static class Combat
                    {
                        public const string Mk1 = "engine_ter_m_combat_01_mk1";
                        public const string Mk2 = "engine_ter_m_combat_01_mk2";
                        public const string Mk3 = "engine_ter_m_combat_01_mk3";
                    }

                    public static class Travel
                    {
                        public const string Mk1 = "engine_ter_m_travel_01_mk1";
                        public const string Mk2 = "engine_ter_m_travel_01_mk2";
                        public const string Mk3 = "engine_ter_m_travel_01_mk3";
                    }
                }

                public static class Small
                {
                    public static class AllRound
                    {
                        public const string Mk1 = "engine_ter_s_allround_01_mk1";
                        public const string Mk2 = "engine_ter_s_allround_01_mk2";
                        public const string Mk3 = "engine_ter_s_allround_01_mk3";
                    }

                    public static class Combat
                    {
                        public const string Mk1 = "engine_ter_s_combat_01_mk1";
                        public const string Mk2 = "engine_ter_s_combat_01_mk2";
                        public const string Mk3 = "engine_ter_s_combat_01_mk3";
                    }

                    public static class Travel
                    {
                        public const string Mk1 = "engine_ter_s_travel_01_mk1";
                        public const string Mk2 = "engine_ter_s_travel_01_mk2";
                        public const string Mk3 = "engine_ter_s_travel_01_mk3";
                    }
                }

                public static class ExtraLarge
                {
                    public static class AllRound
                    {
                        public const string Mk1 = "engine_ter_xl_allround_01_mk1";
                    }

                    public static class Travel
                    {
                        public const string Mk1 = "engine_ter_xl_travel_01_mk1";
                    }
                }
            }

            public static class Argon
            {
                public static class Large
                {
                    public static class AllRound
                    {
                        public const string Mk1 = "engine_arg_l_allround_01_mk1";
                    }

                    public static class Travel
                    {
                        public const string Mk1 = "engine_arg_l_travel_01_mk1";
                    }
                }

                public static class Medium
                {
                    public static class AllRound
                    {
                        public const string Mk1 = "engine_arg_m_allround_01_mk1";
                        public const string Mk2 = "engine_arg_m_allround_01_mk2";
                        public const string Mk3 = "engine_arg_m_allround_01_mk3";
                    }

                    public static class Combat
                    {
                        public const string Mk1 = "engine_arg_m_combat_01_mk1";
                        public const string Mk2 = "engine_arg_m_combat_01_mk2";
                        public const string Mk3 = "engine_arg_m_combat_01_mk3";
                    }

                    public static class Travel
                    {
                        public const string Mk1 = "engine_arg_m_travel_01_mk1";
                        public const string Mk2 = "engine_arg_m_travel_01_mk2";
                        public const string Mk3 = "engine_arg_m_travel_01_mk3";
                    }
                }

                public static class Small
                {
                    public static class AllRound
                    {
                        public const string Mk1 = "engine_arg_s_allround_01_mk1";
                        public const string Mk2 = "engine_arg_s_allround_01_mk2";
                        public const string Mk3 = "engine_arg_s_allround_01_mk3";
                    }

                    public static class Combat
                    {
                        public const string Mk1 = "engine_arg_s_combat_01_mk1";
                        public const string Mk2 = "engine_arg_s_combat_01_mk2";
                        public const string Mk3 = "engine_arg_s_combat_01_mk3";
                    }

                    public static class Travel
                    {
                        public const string Mk1 = "engine_arg_s_travel_01_mk1";
                        public const string Mk2 = "engine_arg_s_travel_01_mk2";
                        public const string Mk3 = "engine_arg_s_travel_01_mk3";
                    }
                }

                public static class ExtraLarge
                {
                    public static class AllRound
                    {
                        public const string Mk1 = "engine_arg_xl_allround_01_mk1";
                    }

                    public static class Travel
                    {
                        public const string Mk1 = "engine_arg_xl_travel_01_mk1";
                    }
                }
            }

            public static class Khak
            {
                public static class Medium
                {
                    public static class Combat
                    {
                        public const string Mk1 = "engine_kha_m_combat_01_mk1";
                        public const string Mk2 = "engine_kha_m_combat_02_mk1";
                    }
                }

                public static class Small
                {
                    public static class Combat
                    {
                        public const string Mk1 = "engine_kha_s_combat_01_mk1";
                    }
                }
            }

            public static class Paranid
            {
                public static class Large
                {
                    public static class AllRound
                    {
                        public const string Mk1 = "engine_par_l_allround_01_mk1";
                    }

                    public static class Travel
                    {
                        public const string Mk1 = "engine_par_l_travel_01_mk1";
                    }
                }

                public static class Medium
                {
                    public static class AllRound
                    {
                        public const string Mk1 = "engine_par_m_allround_01_mk1";
                        public const string Mk2 = "engine_par_m_allround_01_mk2";
                        public const string Mk3 = "engine_par_m_allround_01_mk3";
                    }

                    public static class Combat
                    {
                        public const string Mk1 = "engine_par_m_combat_01_mk1";
                        public const string Mk2 = "engine_par_m_combat_01_mk2";
                        public const string Mk3 = "engine_par_m_combat_01_mk3";
                    }

                    public static class Travel
                    {
                        public const string Mk1 = "engine_par_m_travel_01_mk1";
                        public const string Mk2 = "engine_par_m_travel_01_mk2";
                        public const string Mk3 = "engine_par_m_travel_01_mk3";
                    }
                }

                public static class Small
                {
                    public static class AllRound
                    {
                        public const string Mk1 = "engine_par_s_allround_01_mk1";
                        public const string Mk2 = "engine_par_s_allround_01_mk2";
                        public const string Mk3 = "engine_par_s_allround_01_mk3";
                    }

                    public static class Combat
                    {
                        public const string Mk1 = "engine_par_s_combat_01_mk1";
                        public const string Mk2 = "engine_par_s_combat_01_mk2";
                        public const string Mk3 = "engine_par_s_combat_01_mk3";
                    }

                    public static class Travel
                    {
                        public const string Mk1 = "engine_par_s_travel_01_mk1";
                        public const string Mk2 = "engine_par_s_travel_01_mk2";
                        public const string Mk3 = "engine_par_s_travel_01_mk3";
                    }
                }

                public static class ExtraLarge
                {
                    public static class AllRound
                    {
                        public const string Mk1 = "engine_par_xl_allround_01_mk1";
                    }

                    public static class Travel
                    {
                        public const string Mk1 = "engine_par_xl_travel_01_mk1";
                    }
                }
            }

            public static class Split
            {
                public static class Large
                {
                    public static class AllRound
                    {
                        public const string Mk1 = "engine_spl_l_allround_01_mk1";
                    }

                    public static class Travel
                    {
                        public const string Mk1 = "engine_spl_l_travel_01_mk1";
                    }
                }

                public static class Medium
                {
                    public static class AllRound
                    {
                        public const string Mk1 = "engine_spl_m_allround_01_mk1";
                        public const string Mk2 = "engine_spl_m_allround_01_mk2";
                        public const string Mk3 = "engine_spl_m_allround_01_mk3";
                    }

                    public static class Combat
                    {
                        public const string Mk1 = "engine_spl_m_combat_01_mk1";
                        public const string Mk2 = "engine_spl_m_combat_01_mk2";
                        public const string Mk3 = "engine_spl_m_combat_01_mk3";
                        public const string Mk4 = "engine_spl_m_combat_01_mk4";
                    }

                    public static class Travel
                    {
                        public const string Mk1 = "engine_spl_m_travel_01_mk1";
                        public const string Mk2 = "engine_spl_m_travel_01_mk2";
                        public const string Mk3 = "engine_spl_m_travel_01_mk3";
                    }
                }

                public static class Small
                {
                    public static class AllRound
                    {
                        public const string Mk1 = "engine_spl_s_allround_01_mk1";
                        public const string Mk2 = "engine_spl_s_allround_01_mk2";
                        public const string Mk3 = "engine_spl_s_allround_01_mk3";
                    }

                    public static class Combat
                    {
                        public const string Mk1 = "engine_spl_s_combat_01_mk1";
                        public const string Mk2 = "engine_spl_s_combat_01_mk2";
                        public const string Mk3 = "engine_spl_s_combat_01_mk3";
                        public const string Mk4 = "engine_spl_s_combat_01_mk4";
                    }

                    public static class Travel
                    {
                        public const string Mk1 = "engine_spl_s_travel_01_mk1";
                        public const string Mk2 = "engine_spl_s_travel_01_mk2";
                        public const string Mk3 = "engine_spl_s_travel_01_mk3";
                    }
                }

                public static class ExtraLarge
                {
                    public static class AllRound
                    {
                        public const string Mk1 = "engine_spl_xl_allround_01_mk1";
                    }

                    public static class Travel
                    {
                        public const string Mk1 = "engine_spl_xl_travel_01_mk1";
                    }
                }
            }

            public static class Teladi
            {
                public static class Large
                {
                    public static class AllRound
                    {
                        public const string Mk1 = "engine_tel_l_allround_01_mk1";
                    }

                    public static class Travel
                    {
                        public const string Mk1 = "engine_tel_l_travel_01_mk1";
                    }
                }

                public static class Medium
                {
                    public static class AllRound
                    {
                        public const string Mk1 = "engine_tel_m_allround_01_mk1";
                        public const string Mk2 = "engine_tel_m_allround_01_mk2";
                        public const string Mk3 = "engine_tel_m_allround_01_mk3";
                    }

                    public static class Combat
                    {
                        public const string Mk1 = "engine_tel_m_combat_01_mk1";
                        public const string Mk2 = "engine_tel_m_combat_01_mk2";
                        public const string Mk3 = "engine_tel_m_combat_01_mk3";
                    }

                    public static class Travel
                    {
                        public const string Mk1 = "engine_tel_m_travel_01_mk1";
                        public const string Mk2 = "engine_tel_m_travel_01_mk2";
                        public const string Mk3 = "engine_tel_m_travel_01_mk3";
                    }
                }

                public static class Small
                {
                    public static class AllRound
                    {
                        public const string Mk1 = "engine_tel_s_allround_01_mk1";
                        public const string Mk2 = "engine_tel_s_allround_01_mk2";
                        public const string Mk3 = "engine_tel_s_allround_01_mk3";
                    }

                    public static class Combat
                    {
                        public const string Mk1 = "engine_tel_s_combat_01_mk1";
                        public const string Mk2 = "engine_tel_s_combat_01_mk2";
                        public const string Mk3 = "engine_tel_s_combat_01_mk3";
                    }

                    public static class Travel
                    {
                        public const string Mk1 = "engine_tel_s_travel_01_mk1";
                        public const string Mk2 = "engine_tel_s_travel_01_mk2";
                        public const string Mk3 = "engine_tel_s_travel_01_mk3";
                    }
                }

                public static class ExtraLarge
                {
                    public static class AllRound
                    {
                        public const string Mk1 = "engine_tel_xl_allround_01_mk1";
                    }

                    public static class Travel
                    {
                        public const string Mk1 = "engine_tel_xl_travel_01_mk1";
                    }
                }
            }

            public static class Xenon
            {
                public static class Large
                {
                    public static class AllRound
                    {
                        public const string Mk1 = "engine_xen_l_allround_01_mk1";
                    }
                }

                public static class Medium
                {
                    public static class Combat
                    {
                        public const string Mk1 = "engine_xen_m_combat_01_mk1";
                    }

                    public static class Travel
                    {
                        public const string Mk1 = "engine_xen_m_travel_01_mk1";
                    }
                }

                public static class Small
                {
                    public static class Combat
                    {
                        public const string Mk1 = "engine_xen_s_combat_01_mk1";
                    }
                }

                public static class ExtraLarge
                {
                    public static class AllRound
                    {
                        public const string Mk1 = "engine_xen_xl_allround_01_mk1";
                    }
                }
            }
        }

        public static class Shields
        {
            public static class Terran
            {
                public static class Large
                {
                    public const string Mk1 = "shield_ter_l_standard_01_mk1";
                    public const string Mk2 = "shield_ter_l_standard_01_mk2";
                }

                public static class Medium
                {
                    public const string Mk1 = "shield_ter_m_standard_02_mk1";
                    public const string Mk2 = "shield_ter_m_standard_02_mk2";
                    public const string Mk3 = "shield_ter_m_standard_01_mk3";
                }

                public static class Small
                {
                    public const string Mk1 = "shield_ter_s_standard_01_mk1";
                    public const string Mk2 = "shield_ter_s_standard_01_mk2";
                    public const string Mk3 = "shield_ter_s_standard_01_mk3";
                }

                public static class ExtraLarge
                {
                    public const string Mk1 = "shield_ter_xl_standard_01_mk1";
                }
            }

            public static class Argon
            {
                public static class Large
                {
                    public const string Mk1 = "shield_arg_l_standard_01_mk1";
                    public const string Mk2 = "shield_arg_l_standard_01_mk2";
                }

                public static class Medium
                {
                    public const string Mk1 = "shield_arg_m_standard_02_mk1";
                    public const string Mk2 = "shield_arg_m_standard_02_mk2";
                }

                public static class Small
                {
                    public const string Mk1 = "shield_arg_s_standard_01_mk1";
                    public const string Mk2 = "shield_arg_s_standard_01_mk2";
                    public const string Mk3 = "shield_arg_s_standard_01_mk3";
                }

                public static class ExtraLarge
                {
                    public const string Mk1 = "shield_arg_xl_standard_01_mk1";
                }
            }

            public static class Khak
            {
                public static class Small
                {
                    public const string Mk1 = "shield_kha_s_standard_01_mk1";
                }
            }

            public static class Paranid
            {
                public static class Large
                {
                    public const string Mk1 = "shield_par_l_standard_01_mk1";
                    public const string Mk2 = "shield_par_l_standard_01_mk2";
                }

                public static class Medium
                {
                    public const string Mk1 = "shield_par_m_standard_02_mk1";
                    public const string Mk2 = "shield_par_m_standard_02_mk2";
                }

                public static class Small
                {
                    public const string Mk1 = "shield_par_s_standard_01_mk1";
                    public const string Mk2 = "shield_par_s_standard_01_mk2";
                    public const string Mk3 = "shield_par_s_standard_01_mk3";
                }

                public static class ExtraLarge
                {
                    public const string Mk1 = "shield_par_xl_standard_01_mk1";
                }
            }

            public static class Split
            {
                public static class Large
                {
                    public const string Mk1 = "shield_spl_l_standard_01_mk1";
                    public const string Mk2 = "shield_spl_l_standard_01_mk2";
                }

                public static class Medium
                {
                    public const string Mk1 = "shield_spl_m_standard_02_mk1";
                    public const string Mk2 = "shield_spl_m_standard_02_mk2";
                }

                public static class Small
                {
                    public const string Mk1 = "shield_spl_s_standard_01_mk1";
                    public const string Mk2 = "shield_spl_s_standard_01_mk2";
                    public const string Mk3 = "shield_spl_s_standard_01_mk3";
                }

                public static class ExtraLarge
                {
                    public const string Mk1 = "shield_spl_xl_standard_01_mk1";
                }
            }

            public static class Teladi
            {
                public static class Large
                {
                    public const string Mk1 = "shield_tel_l_standard_01_mk1";
                    public const string Mk2 = "shield_tel_l_standard_01_mk2";
                }

                public static class Medium
                {
                    public const string Mk1 = "shield_tel_m_standard_02_mk1";
                    public const string Mk2 = "shield_tel_m_standard_02_mk2";
                }

                public static class Small
                {
                    public const string Mk1 = "shield_tel_s_standard_01_mk1";
                    public const string Mk2 = "shield_tel_s_standard_01_mk2";
                    public const string Mk3 = "shield_tel_s_standard_01_mk3";
                }

                public static class ExtraLarge
                {
                    public const string Mk1 = "shield_tel_xl_standard_01_mk1";
                }
            }

            public static class Xenon
            {
                public static class Large
                {
                    public const string Mk1 = "shield_xen_l_standard_01_mk1";
                    public const string Mk2 = "shield_xen_l_standard_01_mk2";
                }

                public static class Medium
                {
                    public const string Mk1 = "shield_xen_m_standard_02_mk1";
                    public const string Mk2 = "shield_xen_m_standard_02_mk2";
                }

                public static class Small
                {
                    public const string Mk1 = "shield_xen_s_standard_01_mk1";
                    public const string Mk2 = "shield_xen_s_standard_01_mk2";
                }

                public static class ExtraLarge
                {
                    public const string Mk1 = "shield_xen_xl_standard_01_mk1";
                }
            }
        }

        public static class Weapons
        {
            public static class Argon
            {
                public static class Large
                {
                    public static class Destroyer
                    {
                        public const string Mk1 = "weapon_arg_l_destroyer_01_mk1";
                    }
                }

                public static class Medium
                {
                    public static class Ion
                    {
                        public const string Mk1 = "weapon_arg_m_ion_01_mk1";
                        public const string Mk2 = "weapon_arg_m_ion_01_mk2";
                    }
                }

                public static class Small
                {
                    public static class Ion
                    {
                        public const string Mk1 = "weapon_arg_s_ion_01_mk1";
                        public const string Mk2 = "weapon_arg_s_ion_01_mk2";
                    }
                }
            }

            public static class Generic
            {
                public static class Medium
                {
                    public static class Beam
                    {
                        public const string Mk1 = "weapon_gen_m_beam_01_mk1";
                        public const string Mk2 = "weapon_gen_m_beam_01_mk2";
                    }

                    public static class Dumbfire
                    {
                        public const string Mk1 = "weapon_gen_m_dumbfire_01_mk1";
                        public const string Mk2 = "weapon_gen_m_dumbfire_01_mk2";
                    }

                    public static class Gatling
                    {
                        public const string Mk1 = "weapon_gen_m_gatling_01_mk1";
                        public const string Mk2 = "weapon_gen_m_gatling_01_mk2";
                    }

                    public static class Guided
                    {
                        public const string Mk1 = "weapon_gen_m_guided_01_mk1";
                        public const string Mk2 = "weapon_gen_m_guided_01_mk2";
                    }

                    public static class Laser
                    {
                        public const string Mk1 = "weapon_gen_m_laser_01_mk1";
                        public const string Mk2 = "weapon_gen_m_laser_01_mk2";
                    }

                    public static class Mining
                    {
                        public const string Mk1 = "weapon_gen_m_mining_01_mk1";
                        public const string Mk2 = "weapon_gen_m_mining_01_mk2";
                    }

                    public static class Plasma
                    {
                        public const string Mk1 = "weapon_gen_m_plasma_01_mk1";
                        public const string Mk2 = "weapon_gen_m_plasma_01_mk2";
                    }

                    public static class Shotgun
                    {
                        public const string Mk1 = "weapon_gen_m_shotgun_01_mk1";
                        public const string Mk2 = "weapon_gen_m_shotgun_01_mk2";
                    }

                    public static class Torpedo
                    {
                        public const string Mk1 = "weapon_gen_m_torpedo_01_mk1";
                        public const string Mk2 = "weapon_gen_m_torpedo_01_mk2";
                    }
                }

                public static class Small
                {
                    public static class Beam
                    {
                        public const string Mk1 = "weapon_gen_s_beam_01_mk1";
                        public const string Mk2 = "weapon_gen_s_beam_01_mk2";
                    }

                    public static class Burst
                    {
                        public const string Mk1 = "weapon_gen_s_burst_01_mk1";
                        public const string Mk2 = "weapon_gen_s_burst_01_mk2";
                    }

                    public static class Cannon
                    {
                        public const string Mk1 = "weapon_gen_s_cannon_01_mk1";
                        public const string Mk2 = "weapon_gen_s_cannon_01_mk2";
                    }

                    public static class Dumbfire
                    {
                        public const string Mk1 = "weapon_gen_s_dumbfire_01_mk1";
                        public const string Mk2 = "weapon_gen_s_dumbfire_01_mk2";
                    }

                    public static class Gatling
                    {
                        public const string Mk1 = "weapon_gen_s_gatling_01_mk1";
                        public const string Mk2 = "weapon_gen_s_gatling_01_mk2";
                    }

                    public static class Guided
                    {
                        public const string Mk1 = "weapon_gen_s_guided_01_mk1";
                        public const string Mk2 = "weapon_gen_s_guided_01_mk2";
                    }

                    public static class Laser
                    {
                        public const string Mk1 = "weapon_gen_s_laser_01_mk1";
                        public const string Mk2 = "weapon_gen_s_laser_01_mk2";
                    }

                    public static class Mining
                    {
                        public const string Mk1 = "weapon_gen_s_mining_01_mk1";
                        public const string Mk2 = "weapon_gen_s_mining_01_mk2";
                    }

                    public static class Plasma
                    {
                        public const string Mk1 = "weapon_gen_s_plasma_01_mk1";
                        public const string Mk2 = "weapon_gen_s_plasma_01_mk2";
                    }

                    public static class Shotgun
                    {
                        public const string Mk1 = "weapon_gen_s_shotgun_01_mk1";
                        public const string Mk2 = "weapon_gen_s_shotgun_01_mk2";
                    }

                    public static class Torpedo
                    {
                        public const string Mk1 = "weapon_gen_s_torpedo_01_mk1";
                        public const string Mk2 = "weapon_gen_s_torpedo_01_mk2";
                    }
                }
            }

            public static class Khak
            {
                public static class Medium
                {
                    public static class Laser
                    {
                        public const string Mk1 = "weapon_kha_m_laser_01_mk1";
                    }
                }

                public static class Small
                {
                    public static class Laser
                    {
                        public const string Mk1 = "weapon_kha_s_laser_01_mk1";
                    }
                }
            }

            public static class Paranid
            {
                public static class Large
                {
                    public static class Destroyer
                    {
                        public const string Mk1 = "weapon_par_l_destroyer_01_mk1";
                    }
                }

                public static class Medium
                {
                    public static class Railgun
                    {
                        public const string Mk1 = "weapon_par_m_railgun_01_mk1";
                        public const string Mk2 = "weapon_par_m_railgun_01_mk2";
                    }
                }

                public static class Small
                {
                    public static class Railgun
                    {
                        public const string Mk1 = "weapon_par_s_railgun_01_mk1";
                        public const string Mk2 = "weapon_par_s_railgun_01_mk2";
                    }
                }
            }

            public static class Split
            {
                public static class Large
                {
                    public static class Destroyer
                    {
                        public const string Mk1 = "weapon_spl_l_destroyer_01_mk1";
                    }
                }

                public static class Medium
                {
                    public static class Nuetron
                    {
                        public const string Mk1 = "weapon_spl_m_gatling_01_mk1";
                        public const string Mk2 = "weapon_spl_m_gatling_01_mk2";
                    }

                    public static class Boson
                    {
                        public const string Mk1 = "weapon_spl_m_railgun_01_mk1";
                        public const string Mk2 = "weapon_spl_m_railgun_01_mk2";
                    }

                    public static class Tau
                    {
                        public const string Mk1 = "weapon_spl_m_shotgun_01_mk1";
                        public const string Mk2 = "weapon_spl_m_shotgun_01_mk2";
                    }

                    public static class Thermal
                    {
                        public const string Mk1 = "weapon_spl_m_sticky_01_mk1";
                        public const string Mk2 = "weapon_spl_m_sticky_01_mk2";
                    }
                }

                public static class Small
                {
                    public static class Nuetron
                    {
                        public const string Mk1 = "weapon_spl_s_gatling_01_mk1";
                        public const string Mk2 = "weapon_spl_s_gatling_01_mk2";
                    }

                    public static class Boson
                    {
                        public const string Mk1 = "weapon_spl_s_railgun_01_mk1";
                        public const string Mk2 = "weapon_spl_s_railgun_01_mk2";
                    }

                    public static class Tau
                    {
                        public const string Mk1 = "weapon_spl_s_shotgun_01_mk1";
                        public const string Mk2 = "weapon_spl_s_shotgun_01_mk2";
                    }

                    public static class Thermal
                    {
                        public const string Mk1 = "weapon_spl_s_sticky_01_mk1";
                        public const string Mk2 = "weapon_spl_s_sticky_01_mk2";
                    }
                }
            }

            public static class Teladi
            {
                public static class Large
                {
                    public static class Destroyer
                    {
                        public const string Mk1 = "weapon_tel_l_destroyer_01_mk1";
                    }
                }

                public static class Medium
                {
                    public static class Charge
                    {
                        public const string Mk1 = "weapon_tel_m_charge_01_mk1";
                        public const string Mk2 = "weapon_tel_m_charge_01_mk2";
                    }
                }

                public static class Small
                {
                    public static class Charge
                    {
                        public const string Mk1 = "weapon_tel_s_charge_01_mk1";
                        public const string Mk2 = "weapon_tel_s_charge_01_mk2";
                    }
                }
            }

            public static class Xenon
            {
                public static class Medium
                {
                    public static class Laser
                    {
                        public const string Mk1 = "weapon_xen_m_laser_01_mk1";
                    }

                    public static class Mining
                    {
                        public const string Mk1 = "weapon_xen_m_mining_01_mk1";
                    }
                }

                public static class Small
                {
                    public static class Laser
                    {
                        public const string Mk1 = "weapon_xen_s_laser_01_mk1";
                    }
                }
            }

            public static class Terran
            {
                public static class Small
                {
                    public static class Pulse
                    {
                        public const string Mk1 = "weapon_ter_s_laser_01_mk1";
                        public const string Mk2 = "weapon_ter_s_laser_01_mk2";
                    }

                    public static class Gatling
                    {
                        public const string Mk1 = "weapon_ter_s_gatling_01_mk1";
                        public const string Mk2 = "weapon_ter_s_gatling_01_mk2";
                    }

                    public static class Snarf
                    {
                        public const string Mk1 = "";
                        public const string Mk2 = "";
                    }
                }
            }
        }

        public static class Turrets
        {
            public static class Argon
            {
                public static class Large
                {
                    public static class Beam
                    {
                        public const string Mk1 = "turret_arg_l_beam_01_mk1";
                    }

                    public static class Dumbfire
                    {
                        public const string Mk1 = "turret_arg_l_dumbfire_01_mk1";
                    }

                    public static class Guided
                    {
                        public const string Mk1 = "turret_arg_l_guided_01_mk1";
                    }

                    public static class Laser
                    {
                        public const string Mk1 = "turret_arg_l_laser_01_mk1";
                    }

                    public static class Mining
                    {
                        public const string Mk1 = "turret_arg_l_mining_01_mk1";
                    }

                    public static class Plasma
                    {
                        public const string Mk1 = "turret_arg_l_plasma_01_mk1";
                    }
                }

                public static class Medium
                {
                    public static class Beam
                    {
                        public const string Mk1 = "turret_arg_m_beam_01_mk1";
                        public const string Mk2 = "turret_arg_m_beam_02_mk1";
                    }

                    public static class Dumbfire
                    {
                        public const string Mk1 = "turret_arg_m_dumbfire_01_mk1";
                        public const string Mk2 = "turret_arg_m_dumbfire_02_mk1";
                    }

                    public static class Flak
                    {
                        public const string Mk1 = "turret_arg_m_flak_01_mk1";
                        public const string Mk2 = "turret_arg_m_flak_02_mk1";
                    }

                    public static class Gatling
                    {
                        public const string Mk1 = "turret_arg_m_gatling_01_mk1";
                        public const string Mk2 = "turret_arg_m_gatling_02_mk1";
                    }

                    public static class Guided
                    {
                        public const string Mk1 = "turret_arg_m_guided_01_mk1";
                        public const string Mk2 = "turret_arg_m_guided_02_mk1";
                    }

                    public static class Laser
                    {
                        public const string Mk1 = "turret_arg_m_laser_01_mk1";
                        public const string Mk2 = "turret_arg_m_laser_02_mk1";
                    }

                    public static class Mining
                    {
                        public const string Mk1 = "turret_arg_m_mining_01_mk1";
                        public const string Mk2 = "turret_arg_m_mining_02_mk1";
                    }

                    public static class Plasma
                    {
                        public const string Mk1 = "turret_arg_m_plasma_01_mk1";
                        public const string Mk2 = "turret_arg_m_plasma_02_mk1";
                    }

                    public static class Shotgun
                    {
                        public const string Mk1 = "turret_arg_m_shotgun_01_mk1";
                        public const string Mk2 = "turret_arg_m_shotgun_02_mk1";
                    }
                }
            }

            public static class Khak
            {
                public static class Medium
                {
                    public static class Beam
                    {
                        public const string Mk1 = "turret_kha_m_beam_01_mk1";
                    }
                }
            }

            public static class Paranid
            {
                public static class Large
                {
                    public static class Beam
                    {
                        public const string Mk1 = "turret_par_l_beam_01_mk1";
                    }

                    public static class Dumbfire
                    {
                        public const string Mk1 = "turret_par_l_dumbfire_01_mk1";
                    }

                    public static class Guided
                    {
                        public const string Mk1 = "turret_par_l_guided_01_mk1";
                    }

                    public static class Laser
                    {
                        public const string Mk1 = "turret_par_l_laser_01_mk1";
                    }

                    public static class Mining
                    {
                        public const string Mk1 = "turret_par_l_mining_01_mk1";
                    }

                    public static class Plasma
                    {
                        public const string Mk1 = "turret_par_l_plasma_01_mk1";
                    }
                }

                public static class Medium
                {
                    public static class Beam
                    {
                        public const string Mk1 = "turret_par_m_beam_01_mk1";
                        public const string Mk2 = "turret_par_m_beam_02_mk1";
                    }

                    public static class Dumbfire
                    {
                        public const string Mk1 = "turret_par_m_dumbfire_01_mk1";
                        public const string Mk2 = "turret_par_m_dumbfire_02_mk1";
                    }

                    public static class Gatling
                    {
                        public const string Mk1 = "turret_par_m_gatling_01_mk1";
                        public const string Mk2 = "turret_par_m_gatling_02_mk1";
                    }

                    public static class Guided
                    {
                        public const string Mk1 = "turret_par_m_guided_01_mk1";
                        public const string Mk2 = "turret_par_m_guided_02_mk1";
                    }

                    public static class Laser
                    {
                        public const string Mk1 = "turret_par_m_laser_01_mk1";
                        public const string Mk2 = "turret_par_m_laser_02_mk1";
                    }

                    public static class Mining
                    {
                        public const string Mk1 = "turret_par_m_mining_01_mk1";
                        public const string Mk2 = "turret_par_m_mining_02_mk1";
                    }

                    public static class Plasma
                    {
                        public const string Mk1 = "turret_par_m_plasma_01_mk1";
                        public const string Mk2 = "turret_par_m_plasma_02_mk1";
                    }

                    public static class Shotgun
                    {
                        public const string Mk1 = "turret_par_m_shotgun_01_mk1";
                        public const string Mk2 = "turret_par_m_shotgun_02_mk1";
                    }
                }
            }

            public static class Split
            {
                public static class Large
                {
                    public static class Beam
                    {
                        public const string Mk1 = "turret_spl_l_beam_01_mk1";
                    }

                    public static class Dumbfire
                    {
                        public const string Mk1 = "turret_spl_l_dumbfire_01_mk1";
                    }

                    public static class Guided
                    {
                        public const string Mk1 = "turret_spl_l_guided_01_mk1";
                    }

                    public static class Laser
                    {
                        public const string Mk1 = "turret_spl_l_laser_01_mk1";
                    }

                    public static class Mining
                    {
                        public const string Mk1 = "turret_spl_l_mining_01_mk1";
                    }

                    public static class Plasma
                    {
                        public const string Mk1 = "turret_spl_l_plasma_01_mk1";
                    }
                }

                public static class Medium
                {
                    public static class Beam
                    {
                        public const string Mk1 = "turret_spl_m_beam_01_mk1";
                        public const string Mk2 = "turret_spl_m_beam_02_mk1";
                    }

                    public static class Dumbfire
                    {
                        public const string Mk1 = "turret_spl_m_dumbfire_01_mk1";
                        public const string Mk2 = "turret_spl_m_dumbfire_02_mk1";
                    }

                    public static class Flak
                    {
                        public const string Mk1 = "turret_spl_m_flak_01_mk1";
                        public const string Mk2 = "turret_spl_m_flak_02_mk1";
                    }

                    public static class Gatling
                    {
                        public const string Mk1 = "turret_spl_m_gatling_01_mk1";
                        public const string Mk2 = "turret_spl_m_gatling_02_mk1";
                    }

                    public static class Guided
                    {
                        public const string Mk1 = "turret_spl_m_guided_01_mk1";
                        public const string Mk2 = "turret_spl_m_guided_02_mk1";
                    }

                    public static class Laser
                    {
                        public const string Mk1 = "turret_spl_m_laser_01_mk1";
                        public const string Mk2 = "turret_spl_m_laser_02_mk1";
                    }

                    public static class Mining
                    {
                        public const string Mk1 = "turret_spl_m_mining_01_mk1";
                        public const string Mk2 = "turret_spl_m_mining_02_mk1";
                    }

                    public static class Plasma
                    {
                        public const string Mk1 = "turret_spl_m_plasma_01_mk1";
                        public const string Mk2 = "turret_spl_m_plasma_02_mk1";
                    }

                    public static class Shotgun
                    {
                        public const string Mk1 = "turret_spl_m_shotgun_01_mk1";
                        public const string Mk2 = "turret_spl_m_shotgun_02_mk1";
                    }
                }
            }

            public static class Teladi
            {
                public static class Large
                {
                    public static class Beam
                    {
                        public const string Mk1 = "turret_tel_l_beam_01_mk1";
                    }

                    public static class Dumbfire
                    {
                        public const string Mk1 = "turret_tel_l_dumbfire_01_mk1";
                    }

                    public static class Guided
                    {
                        public const string Mk1 = "turret_tel_l_guided_01_mk1";
                    }

                    public static class Laser
                    {
                        public const string Mk1 = "turret_tel_l_laser_01_mk1";
                    }

                    public static class Mining
                    {
                        public const string Mk1 = "turret_tel_l_mining_01_mk1";
                    }

                    public static class Plasma
                    {
                        public const string Mk1 = "turret_tel_l_plasma_01_mk1";
                    }
                }

                public static class Medium
                {
                    public static class Beam
                    {
                        public const string Mk1 = "turret_tel_m_beam_01_mk1";
                        public const string Mk2 = "turret_tel_m_beam_02_mk1";
                    }

                    public static class Dumbfire
                    {
                        public const string Mk1 = "turret_tel_m_dumbfire_01_mk1";
                        public const string Mk2 = "turret_tel_m_dumbfire_02_mk1";
                    }

                    public static class Gatling
                    {
                        public const string Mk1 = "turret_tel_m_gatling_01_mk1";
                        public const string Mk2 = "turret_tel_m_gatling_02_mk1";
                    }

                    public static class Guided
                    {
                        public const string Mk1 = "turret_tel_m_guided_01_mk1";
                        public const string Mk2 = "turret_tel_m_guided_02_mk1";
                    }

                    public static class Laser
                    {
                        public const string Mk1 = "turret_tel_m_laser_01_mk1";
                        public const string Mk2 = "turret_tel_m_laser_02_mk1";
                    }

                    public static class Mining
                    {
                        public const string Mk1 = "turret_tel_m_mining_01_mk1";
                        public const string Mk2 = "turret_tel_m_mining_02_mk1";
                    }

                    public static class Plasma
                    {
                        public const string Mk1 = "turret_tel_m_plasma_01_mk1";
                        public const string Mk2 = "turret_tel_m_plasma_02_mk1";
                    }

                    public static class Shotgun
                    {
                        public const string Mk1 = "turret_tel_m_shotgun_01_mk1";
                        public const string Mk2 = "turret_tel_m_shotgun_02_mk1";
                    }
                }
            }

            public static class Xenon
            {
                public static class Large
                {
                    public static class Laser
                    {
                        public const string Mk1 = "turret_xen_l_laser_01_mk1";
                    }
                }

                public static class Medium
                {
                    public static class Beam
                    {
                        public const string Mk2 = "turret_xen_m_beam_02_mk1";
                    }

                    public static class Laser
                    {
                        public const string Mk1 = "turret_xen_m_laser_01_mk1";
                        public const string Mk2 = "turret_xen_m_laser_02_mk1";
                    }
                }
            }
        }
    }
}
