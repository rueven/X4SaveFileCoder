﻿namespace X4.Constants
{
    public static class Ships
    {
        public static class Argon
        {
            public static class Nova
            {
                public const string Sentinel = "ship_arg_s_fighter_01_b_macro";
            }

            public static class Eclipse
            {
                public const string Vanguard = "ship_arg_s_heavyfighter_02_a_macro";
            }

            public static class Quasar
            {
                public const string Vanguard = "ship_arg_s_fighter_04_a_macro";
            }

            public static class Minotaur
            {
                public const string Raider = "ship_arg_m_bomber_02_a_macro";
                public const string Vanguard = "ship_arg_m_bomber_01_a_macro";
                public const string Sentinel = "ship_arg_m_bomber_01_b_macro";
            }

            public static class Cerberus
            {
                public const string Vanguard = "ship_arg_m_frigate_01_a_macro";
                public const string Sentinel = "ship_arg_m_frigate_01_b_macro";
            }

            public static class Drill
            {
                public const string Vanguard = "ship_arg_m_miner_solid_01_a_macro";
                public const string Sentinel = "ship_arg_m_miner_solid_01_b_macro";
            }

            public static class Callisto
            {
                public const string Vanguard = "ship_arg_s_trans_container_02_a_macro";
                public const string Sentinel = "ship_arg_s_trans_container_02_b_macro";
            }

            public static class Courier
            {
                public const string Mineral = "ship_arg_s_miner_solid_01_a_macro";
                public const string Vanguard = "ship_arg_s_trans_container_01_a_macro";
                public const string Sentinel = "ship_arg_s_trans_container_01_b_macro";
            }

            public static class Discoverer
            {
                public const string Vanguard = "ship_arg_s_scout_01_a_macro";
                public const string Sentinel = "ship_arg_s_scout_01_b_macro";
            }

            public static class Elite
            {
                public const string Vanguard = "ship_arg_s_fighter_02_a_macro";
                public const string Sentinel = "ship_arg_s_fighter_02_b_macro";
            }

            public static class Pulsar
            {
                public const string Vanguard = "ship_arg_s_fighter_03_a_macro";
            }

            // From mod
            public static class Baku
            {
                public const string Default = "baku_macro";
            }
        }

        public static class Terran
        {
            public static class Small
            {
                public static string Kukri = "ship_ter_s_fighter_01_a_macro";
                public static string Kalis = "ship_ter_s_fighter_02_a_macro";
                public static string Takoba = "ship_ter_s_fighter_03_a_macro";
                public static string Gladius = "ship_ter_s_heavyfighter_01_a_macro";
                public static string Nimcha = "";
                public static string Rapier = "";
            }

            public static class Medium
            {
                public static string Katana = "ship_ter_m_corvette_01_a_macro";
                public static string Falx = "ship_ter_m_frigate_01_a_macro";
                public static string Jian = "ship_ter_m_gunboat_01_a_macro";
            }
        }

        public static class Pirate
        {
            public static class Small
            {
                public const string Kyd = "ship_pir_s_fighter_01_a_macro";
                public const string Witherborn = "ship_pir_s_fighter_lc4_01_macro";
                public const string WitherbornVanguard = "ship_pir_s_fighter_lc4_01_b_macro";
                public const string Raleigh = "ship_pir_s_trans_container_01_a_macro";
                public const string Skyte = "ship_pir_s_heavyfighter_lc4_01_macro";
                public const string Lux = "ship_pir_s_fighter_02_a_macro";
            }

            public static class Medium
            {
                public const string Manticore = "ship_gen_m_tugboat_01_a_macro";
                public const string Prometheus = "ship_par_m_trans_container_03_a_macro";
            }

            public static class Large
            {
                public const string Tueta = "ship_pir_l_scrapper_01_macro";
                public const string Barbarosa = "ship_pir_l_scavenger_01_a_macro";
            }
        }

        public static class Teladi
        {
            public static string Cormorant = "ship_tel_m_trans_container_03_a_macro";
        }
    }
}
