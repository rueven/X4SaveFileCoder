﻿namespace X4.Constants
{
    public enum CharacterTraitValue
    {
        Recruit = 1,
        Veteran = 8,
        Elite = 15
    }
}
