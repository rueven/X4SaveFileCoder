﻿namespace X4.Constants
{
    public enum Make
    {
        Mk1,
        Mk2,
        Mk3,
        Mk4
    }
}
