﻿namespace X4.Constants
{
    public enum ThrusterType
    {
        AllRound,
        Combat
    }
}