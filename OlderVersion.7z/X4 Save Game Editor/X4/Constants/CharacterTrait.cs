﻿namespace X4.Constants
{
    public enum CharacterTrait
    {
        Boarding,
        Engineering,
        Management,
        Morale,
        Piloting
    }
}
