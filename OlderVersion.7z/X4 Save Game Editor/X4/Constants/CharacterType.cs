﻿namespace X4.Constants
{
    public enum CharacterType
    {
        Marine,
        Service,
        Pilot,
        Manager,
        ShipTrader
    }
}
