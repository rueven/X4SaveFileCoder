﻿namespace X4.Constants
{
    public enum ShipSize
    {
        Small,
        Medium,
        Large,
        ExtraLarge
    }
}
