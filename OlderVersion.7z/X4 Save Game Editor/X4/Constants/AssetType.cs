﻿namespace X4.Constants
{
    public enum AssetType
    {
        Weapon,
        Turret,
        Module,
        Engine,
        Shield,
        Ship,
        Mod,
        Missile,
        Inventory,
        Thruster,
        ModPart
    }
}
