﻿namespace X4.Constants
{
    public enum GunType
    {
        Destroyer,
        Ion,
        Beam,
        Dumbfire,
        Gatling,
        Guided,
        Laser,
        Mining,
        Plasma,
        Shotgun,
        Torpedo,
        Mine,
        Burst,
        Cannon,
        Railgun,
        Sticky,
        Charge,
        Flak
    }
}