﻿namespace X4.Constants
{
    public enum EngineType
    {
        AllRound,
        Combat,
        Travel
    }
}
