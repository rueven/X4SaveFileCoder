﻿using Power.Utilities;
using System.Collections.Generic;
using X4.Constants;
using X4.Objects.Interfaces;
using X4.Services.Interfaces;

namespace X4.Services.Implementations
{
    public abstract class GameSetupService
        : IGameSetupService
    {
        #region Constructor
        protected GameSetupService(string paintJob, IReadOnlyList<IShipCoder> shipCoders, ICharacterLibraryYielder serviceUniformYielder = null, ICharacterLibraryYielder pilotUniformYielder = null, ICharacterLibraryYielder marineUniformYielder = null)
        {
            this.ShipCoders = shipCoders;
            this.ServiceUniformYielder = serviceUniformYielder;
            this.MarineUniformYielder = marineUniformYielder;
            this.PilotUniformYielder = pilotUniformYielder;
        }
        #endregion

        #region Properties
        protected ICharacterLibraryYielder ServiceUniformYielder { get; }
        protected ICharacterLibraryYielder PilotUniformYielder { get; }
        protected ICharacterLibraryYielder MarineUniformYielder { get; }
        protected IShipCoderService ShipCoderService { get; }
        protected IReadOnlyList<IShipCoder> ShipCoders { get; }
        #endregion

        public static class Paints
        {
            public const string UnknownOriginPaint = "paintmod_0008";
            public const string FoundationPaint = "paintmod_0019";
            public const string ArgonPaint = "paintmod_0002";
            public const string AntigonePaint = "paintmod_0003";
        }

        public virtual void Setup(ISaveFile file)
        {
            file.ForEachPlayerShip(ship =>
            {
                this.OnBeforeHandleShip(ship);
                
                #region Encode ships
                this.ShipCoders
                    .Iterate(x => x.Encode(ship));
                #endregion

                #region Assign uniforms to crew
                if (!this.SkipCrewYielding(ship))
                {
                    ship.ForEachPassenger(passenger =>
                        {
                            switch (passenger.Type)
                            {
                                case CharacterType.Marine:
                                    this.MarineUniformYielder
                                        ?.AssignUniform(passenger);
                                    break;
                                case CharacterType.Service:
                                    this.ServiceUniformYielder
                                        ?.AssignUniform(passenger);
                                    break;
                            }
                        })
                        .Pilot(pilot =>
                        {
                            this.PilotUniformYielder
                                ?.AssignUniform(pilot);
                        });
                }
                #endregion

                this.OnAfterHandleShip(ship);
            });
        }

        protected virtual void OnBeforeHandleShip(IShip ship) { }
        protected virtual void OnAfterHandleShip(IShip ship) { }
        protected virtual bool SkipCrewYielding(IShip ship) => false;
    }
}
