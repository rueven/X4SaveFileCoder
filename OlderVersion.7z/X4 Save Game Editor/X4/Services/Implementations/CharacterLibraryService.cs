﻿using System.Collections.Generic;
using X4.Models.Interfaces;
using X4.Objects.Implementations;
using X4.Objects.Interfaces;
using X4.Services.Interfaces;

namespace X4.Services.Implementations
{
    public abstract class CharacterLibraryService
        : ICharacterLibraryService
    {
        protected CharacterLibraryService(string name) { this.Name = name; }

        public string Name { get; }
        protected abstract IReadOnlyList<IReadOnlyCharacterBluePrint> List { get; }

        public ICharacterLibraryYielder CreateYielder(ISaveFile file) => new CharacterLibraryYielder(this, file);

        public IReadOnlyList<IReadOnlyCharacterBluePrint> Fetch() => this.List;
    }
}
