﻿using Power.Utilities;
using System.Collections.Generic;
using X4.Constants;
using X4.Extensions;
using X4.Objects.Interfaces;
using X4.Services.Interfaces;

namespace X4.Services.Implementations.GameSetupServices
{
    public class ArgonGameSetupService
        : GameSetupService
    {
        public ArgonGameSetupService(ISaveFile file)
            : this(file, new ShipCodeService())
        { }

        public ArgonGameSetupService(ISaveFile file, IShipCoderService shipCoderService)
            : base
        (
            Paints.UnknownOriginPaint,
            new List<IShipCoder>()
            {
                // War Ships
                shipCoderService
                    .CreateShipCoder(ship => ship.IsWarship() && ship.Size == ShipSize.ExtraLarge, "WAR")
                    .With(x => x.Initialize(file)),
                shipCoderService
                    .CreateShipCoder(ship => ship.IsWarship() && ship.Size == ShipSize.Large, "WAR", 100)
                    .With(x => x.Initialize(file)),
                shipCoderService
                    .CreateShipCoder(ship => ship.IsWarship() && ship.Size == ShipSize.Medium, "WAR", 500)
                    .With(x => x.Initialize(file)),
                shipCoderService
                    .CreateShipCoder(ship => ship.IsWarship() && ship.Size == ShipSize.Small, "GUN")
                    .With(x => x.Initialize(file)),

                // Mining Ships
                shipCoderService
                    .CreateShipCoder(ship => ship.IsResourceShip() && ship.Size == ShipSize.Large, "ORE")
                    .With(x => x.Initialize(file)),
                shipCoderService
                    .CreateShipCoder(ship => ship.IsResourceShip() && ship.Size == ShipSize.Medium, "ORE", 100)
                    .With(x => x.Initialize(file)),
                shipCoderService
                    .CreateShipCoder(ship => ship.IsResourceShip() && ship.Size == ShipSize.Small, "ORE", 500)
                    .With(x => x.Initialize(file)),

                // Trade Ships
                shipCoderService
                    .CreateShipCoder(ship => ship.IsTradeship() && ship.Size == ShipSize.Large, "BOX")
                    .With(x => x.Initialize(file)),
                shipCoderService
                    .CreateShipCoder(ship => ship.IsTradeship() && ship.Size == ShipSize.Medium, "BOX", 100)
                    .With(x => x.Initialize(file)),
                shipCoderService
                    .CreateShipCoder(ship => ship.IsTradeship() && ship.Size == ShipSize.Small, "BOX", 500)
                    .With(x => x.Initialize(file)),
            },

            serviceUniformYielder: new CharacterLibraryServices
                  .BlackYellowPilotUniformService()
                  .CreateYielder(file),

            marineUniformYielder: new CharacterLibraryServices
                  .StormTrooperUniformService()
                  .CreateYielder(file)
        ) { }
        
        protected override void OnAfterHandleShip(IShip ship)
        {
            if (ship.IsWarship())
            {
                switch (ship.Size)
                {
                    case ShipSize.ExtraLarge:
                        ship.WithStreamlinedHullChassisModification()
                            .WithEngineModification()
                            .WithShieldsModification(4, .1, 4);
                        break;
                    case ShipSize.Large:
                        ship.WithStreamlinedHullChassisModification()
                            .WithEngineModification()
                            .WithShieldsModification(4, .1, 4);
                        break;
                    case ShipSize.Medium:
                        ship.WithStreamlinedHullChassisModification()
                            .WithEngineModification()
                            .WithShieldsModification();
                        break;
                    case ShipSize.Small:
                        ship.WithStreamlinedHullChassisModification()
                            .WithEngineModification()
                            .WithShieldsModification(2, .1, 2)
                            .WithWeaponsType()
                            .WithWeaponModifications(reload: .1);
                        break;
                }
            }
        }

        //protected override bool SkipCrewYielding(IShip ship)
        //{
        //    return this
        //        .ShipNames
        //        .Contains(ship.Name);
        //}
    }
}