﻿using System;
using System.IO;
using System.IO.Compression;
using System.Xml;
using X4.Objects.Implementations;
using X4.Objects.Interfaces;
using X4.Services.Interfaces;

namespace X4.Services.Implementations
{
    public class SaveFileService
        : ISaveFileService
    {
        public ISaveFile LoadFromGZipSlot(int slot)
        {
            var filePath = $@"c:\users\{Environment.UserName}\documents\egosoft\x4\44625032\save\save_{slot.ToString("D3")}.xml.gz";
            using (var stream = new FileStream(filePath, FileMode.Open, FileAccess.Read))
            using (var zipper = new GZipStream(stream, CompressionMode.Decompress))
            using (var memoryStream = new MemoryStream())
            {
                zipper.CopyTo(memoryStream);
                memoryStream.Position = 0;
                var document = new XmlDocument();
                document.Load(memoryStream);
                return new SaveFile(document, filePath, true);
            }
        }

        public ISaveFile LoadFromSlot(int slot)
        {
            var filePath = $@"c:\users\{Environment.UserName}\documents\egosoft\x4\44625032\save\save_{slot.ToString("D3")}.xml";
            var document = new XmlDocument();
            document.Load(filePath);
            return new SaveFile(document, filePath, false);
        }

        public void Save(ISaveFile saveFile)
        {
            var value = saveFile as SaveFile;
            if (value == null)
            {
                throw new Exception("Unable to save");
            }
            if (value.IsCompressed)
            {
                File.Delete(value.FilePath);
                using (var stream = new FileStream(value.FilePath, FileMode.CreateNew))
                using (var zipper = new GZipStream(stream, CompressionLevel.Optimal))
                {
                    value.Document.Save(zipper);
                }
            }
            else
            {
                value.Document
                    .Save(value.FilePath);
            }
        }
    }
}
