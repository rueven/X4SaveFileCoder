﻿using System.Text.RegularExpressions;
using System.Xml;

namespace X4.Services.Implementations
{
    public class NameLookupService
    {
        public NameLookupService(string filePath = @"c:\users\admin\desktop\x4 thing\extracted\t\0001-l044.xml")
        {
            this.Document = new XmlDocument();
            this.Document.Load(filePath);
        }

        protected XmlDocument Document { get; }
        protected static Regex Pattern { get; } = new Regex(@"\{(?<page>[0-9]+),(?<id>[0-9]+)\}", RegexOptions.Compiled);

        private string Evaluate(Match match)
        {
            var page = match.Groups["page"].Value;
            var id = match.Groups["id"].Value;
            var nameValue = this
                .Document
                .SelectSingleNode($"language/page[@id={page}]/t[@id={id}]")
                ?.InnerText;
            return nameValue;
        }
        public string TranslateName(string name)
        {
            if (!name.Contains("{"))
            {
                return name;
            }
            var output = NameLookupService
                .Pattern
                .Replace(name, this.Evaluate);
            return this.TranslateName(output);
        }
    }
}
