﻿using System.Collections.Generic;
using System.Linq;
using X4.Models.Implementations;
using X4.Models.Interfaces;

namespace X4.Services.Implementations.CharacterLibraryServices
{
    public class StormTrooperUniformService
        : CharacterLibraryService
    {
        public StormTrooperUniformService()
            : base("Black Uniforms with Yellow Highlights")
        { }

        public static List<IReadOnlyCharacterBluePrint> GetBluePrints() => StormTrooperUniformService
            .BluePrints
            .Cast<IReadOnlyCharacterBluePrint>()
            .ToList();
        
        private static CharacterBluePrintList BluePrints { get; }= new CharacterBluePrintList()
        {
            { 2550927855, "character_argon_male_marine_helmet_01_macro" },
            { 1014766921, "character_argon_male_marine_helmet_01_macro" },
            { 3955870944, "character_argon_male_marine_helmet_01_macro" },
            { 2019042304, "character_argon_male_marine_helmet_01_macro" },
            { 767992209, "character_argon_male_marine_helmet_01_macro" },
            { 3981203206, "character_argon_male_marine_helmet_01_macro" },
            { 3417603433, "character_argon_male_marine_helmet_01_macro" },
            { 1735189330, "character_argon_male_marine_helmet_01_macro" },
            { 4263521985, "character_argon_male_marine_helmet_01_macro" },
            { 931594762, "character_argon_male_marine_helmet_01_macro" },
            { 2612142790, "character_argon_male_marine_helmet_01_macro" },
            { 2544692453, "character_argon_male_marine_helmet_01_macro" },
            { 2065377431, "character_argon_male_marine_helmet_01_macro" },
            { 302436403, "character_argon_male_marine_helmet_01_macro" },
            { 3619699971, "character_argon_male_marine_helmet_01_macro" },
            { 1165831138, "character_argon_male_marine_helmet_01_macro" },
            { 2500729091, "character_argon_male_marine_helmet_01_macro" },
            { 700077449, "character_argon_male_marine_helmet_01_macro" },
            { 2896430111, "character_gram_ar_f_marine_02_macro" },
            { 830074232, "character_gram_argon_marine_m_casco_rifle_macro" },
            { 2883838221, "character_gram_player_scenario_advanced_argon_macro" },
            { 1354508598, "character_gram_ar_f_marine_02_macro" },
            { 242708617, "character_gram_ar_m_marine_macro" },
            { 931804342, "character_gram_ar_f_marine_02_macro" },
            { 2090742873, "character_gram_player_scenario_advanced_argon_macro" },
            { 2110262765, "character_gram_split_m_marine_macro" },
            { 654849645, "character_gram_argon_marine_m_casco_rifle_macro" },
            { 2178415417, "character_gram_split_f_marine_macro" },
            { 1336946645, "character_gram_ar_m_marine_macro" },
            { 1675280857, "character_gram_player_scenario_advanced_argon_macro" },
            { 2827357284, "character_gram_ar_m_marine_macro" },
            { 1753382200, "character_gram_split_f_marine_macro" },
            { 576338965, "character_gram_split_f_marine_macro" },
            { 2448674830, "character_gram_ar_f_marine_02_macro" },
            { 3343727072, "character_gram_player_scenario_advanced_argon_macro" },
            { 1068831968, "character_gram_ar_f_marine_02_macro" },
            { 3273201038, "character_gram_player_scenario_advanced_argon_macro" },
            { 2595966216, "character_gram_player_scenario_advanced_argon_macro" },
            { 1816582758, "character_argon_male_marine_helmet_01_macro" },
            { 3058551247, "character_gram_ar_f_marine_02_macro" },
            { 1702550046, "character_gram_ar_f_marine_02_macro" },
            { 66332411, "character_gram_argon_marine_m_casco_rifle_macro" },
            { 660479899, "character_gram_argon_marine_m_casco_rifle_macro" },
            { 1803838754, "character_gram_split_f_marine_macro" },
            { 386115948, "character_argon_male_marine_helmet_01_macro" },
            { 3849035961, "character_gram_player_scenario_advanced_argon_macro" },
            { 2876864562, "character_gram_ar_f_marine_02_macro" },
            { 3458821136, "character_gram_split_f_marine_macro" },
            { 3207616009, "character_gram_player_scenario_advanced_argon_macro" },
            { 2222625733, "character_gram_ar_m_marine_macro" },
            { 3122336832, "character_gram_ar_m_marine_macro" },
            { 3441431840, "character_gram_ar_f_marine_02_macro" },
            { 1405016207, "character_gram_argon_marine_m_casco_rifle_macro" },
            { 2536555711, "character_gram_player_scenario_advanced_argon_macro" },
            { 1430937516, "character_gram_ar_m_marine_macro" },
            { 624060722, "character_gram_argon_marine_m_casco_rifle_macro" },
            { 601398119, "character_argon_male_marine_helmet_01_macro" },
            { 2897882123, "character_gram_argon_marine_m_casco_rifle_macro" },
            { 1828394947, "character_argon_male_marine_helmet_01_macro" },
            { 2960664276, "character_gram_ar_m_marine_macro" },
            { 885726165, "character_gram_ar_f_marine_02_macro" },
            { 1051030770, "character_gram_player_scenario_advanced_argon_macro" },
            { 1315131165, "character_gram_argon_marine_m_casco_rifle_macro" },
            { 2305361688, "character_gram_ar_m_marine_macro" },
            { 3800648530, "character_gram_ar_m_marine_macro" },
            { 661950337, "character_gram_ar_f_marine_02_macro" },
            { 966097408, "character_gram_ar_f_marine_02_macro" },
            { 2477171084, "character_argon_male_marine_helmet_01_macro" },
            { 1999623303, "character_gram_ar_f_marine_02_macro" },
            { 2762563206, "character_gram_ar_f_marine_02_macro" },
            { 3700511110, "character_argon_male_marine_helmet_01_macro" },
            { 137418089, "character_gram_split_m_marine_macro" },
            { 3392599737, "character_gram_split_m_marine_macro" },
            { 3525288957, "character_argon_male_marine_helmet_01_macro" },
            { 4093822198, "character_gram_split_f_marine_macro" },
            { 3351452595, "character_gram_ar_f_marine_02_macro" },
            { 74429976, "character_gram_ar_f_marine_02_macro" },
            { 3052707000, "character_gram_ar_f_marine_02_macro" },
            { 4023999475, "character_argon_male_marine_helmet_01_macro" },
            { 3064903741, "character_gram_ar_f_marine_02_macro" },
            { 3097394104, "character_argon_male_marine_helmet_01_macro" },
            { 3016802102, "character_gram_split_f_marine_macro" },
            { 1830004186, "character_gram_ar_m_marine_macro" },
            { 3535015409, "character_gram_ar_f_marine_02_macro" },
            { 2457481301, "character_gram_ar_m_marine_macro" },
            { 195560811, "character_gram_ar_m_marine_macro" },
            { 582571816, "character_gram_ar_f_marine_02_macro" },
            { 3929084905, "character_argon_male_marine_helmet_01_macro" },
            { 338697106, "character_gram_ar_f_marine_02_macro" },
            { 1337067222, "character_argon_male_marine_helmet_01_macro" },
            { 3742869402, "character_gram_ar_m_marine_macro" },
            { 4251544911, "character_argon_male_marine_helmet_01_macro" },
            { 983651203, "character_argon_male_marine_helmet_01_macro" },
            { 3751789889, "character_argon_male_marine_helmet_01_macro" },
            { 2871986668, "character_gram_ar_f_marine_02_macro" },
            { 3647493998, "character_gram_split_f_marine_macro" },
            { 3611223404, "character_gram_ar_f_marine_02_macro" },
            { 4091027443, "character_gram_ar_m_marine_macro" },
            { 96145005, "character_argon_male_marine_helmet_01_macro" },
            { 637793958, "character_gram_ar_f_marine_02_macro" },
            { 890532178, "character_gram_ar_f_marine_02_macro" },
        };

        protected override IReadOnlyList<IReadOnlyCharacterBluePrint> List { get; } = GetBluePrints();
    }
}
