﻿using Power.Utilities;
using System.Collections.Generic;
using System.Linq;
using X4.Models.Implementations;
using X4.Models.Interfaces;

namespace X4.Services.Implementations.CharacterLibraryServices
{
    public class MilitaryJumperUniformService : CharacterLibraryService
    {
        public MilitaryJumperUniformService(bool includeSpecialCharacters)
            : base("Military Jumper Uniforms")
        {
            this.List = GetBluePrints(includeSpecialCharacters);
        }

        protected bool IncludeSpecialCharacters { get; }
        protected override IReadOnlyList<IReadOnlyCharacterBluePrint> List { get; }

        public static List<string> UniqueMacros { get; } = new List<string>()
        {
            "character_argon_female_dyn_overall_crew_01_macro",
            "character_argon_male_dyn_overall_crew_01_macro",
            "character_argon_male_marine_helmet_01_macro",
            "character_argon_male_pilot_01_macro",
            "character_argon_male_pilot_08_macro",
            "character_gram_ar_f_service_macro",
            "character_gram_player_discover_macro",
            "character_scenario_combat_arg_captain_macro",
            "character_scenario_combat_arg_gunner_macro",
            "character_scenario_combat_arg_helm_macro",
            "character_scenario_combat_arg_marine_macro",
            "character_scenario_combat_arg_navigation_macro"
        };

        public static List<IReadOnlyCharacterBluePrint> GetBluePrints(bool includeSpecialCharacters) => MilitaryJumperUniformService
            .BluePrints
            .Cast<IReadOnlyCharacterBluePrint>()
            .ToList()
            .With(list =>
            {
                if (!includeSpecialCharacters)
                {
                    return;
                }
                list.Insert(0, MilitaryJumperUniformService.Officers.DavenSelek);
                list.Insert(0, MilitaryJumperUniformService.Officers.ElisterDelsen);
                list.Insert(0, MilitaryJumperUniformService.Officers.FlotYatar);
                list.Insert(0, MilitaryJumperUniformService.Officers.JanitDelson);
                list.Insert(0, MilitaryJumperUniformService.Officers.DalSmitt);
                list.Insert(0, MilitaryJumperUniformService.Officers.DavenWeamond);
                list.Insert(0, MilitaryJumperUniformService.Officers.GabreelKult);
                list.Insert(0, MilitaryJumperUniformService.Officers.AronMotoli);
                list.Insert(0, MilitaryJumperUniformService.Officers.AdsenRaner);
                list.Insert(0, MilitaryJumperUniformService.Officers.AdsenYatar);
                list.Insert(0, MilitaryJumperUniformService.HanesCherum);
                list.Insert(0, MilitaryJumperUniformService.JanitMortell);
                list.Insert(0, MilitaryJumperUniformService.NaschaMortell);
                list.Insert(0, MilitaryJumperUniformService.SamanBarnard);
                list.Insert(0, MilitaryJumperUniformService.SayreenCornell);
                list.Insert(0, MilitaryJumperUniformService.TaylaSeldon);
                list.Insert(0, MilitaryJumperUniformService.UgoNedley);
                list.Insert(0, MilitaryJumperUniformService.VanaRolen);
            });

        public static CharacterBluePrintList BluePrints { get; } = new CharacterBluePrintList()
        {
            { 3445276290, "character_scenario_combat_arg_marine_macro" },
            { 2610857905, "character_gram_ar_f_marine_macro" },
            { 2912447143, "character_scenario_combat_arg_gunner_macro" },
            { 2468829034, "character_scenario_combat_arg_gunner_macro" },
            { 2165184147, "character_scenario_combat_arg_marine_macro" },
            { 2789401761, "character_gram_ar_f_marine_macro" },
            { 3913769039, "character_scenario_combat_arg_navigation_macro" },
            { 1026900403, "character_argon_male_dyn_overall_crew_01_macro" },
            { 1123718103, "character_scenario_combat_arg_marine_macro" },
            { 464776478, "character_scenario_combat_arg_gunner_macro" },
            { 1405647939, "character_gram_ar_f_service_macro" },
            { 814018632, "character_gram_player_discover_macro" },
            { 4180827965, "character_scenario_combat_arg_captain_macro" },
            { 3785625235, "character_gram_player_scenario_combat_argon_macro" },
            { 869624223, "character_scenario_combat_arg_gunner_macro" },
            { 3800648530, "character_gram_ar_m_marine_macro" },
            { 661950337, "character_gram_ar_f_marine_02_macro" },
            { 966097408, "character_gram_ar_f_marine_02_macro" },
            { 2477171084, "character_argon_male_marine_helmet_01_macro" },
            { 1253447195, "character_gram_ar_f_service_macro" },
            { 2766356849, "character_scenario_combat_arg_gunner_macro" },
            { 4156706213, "character_argon_female_dyn_jacket_fighterpilot_01_macro" },
            { 2732487252, "character_argon_female_dyn_overall_crew_01_macro" },
            { 2832645082, "character_argon_male_pilot_08_macro" },
            { 204351622, "character_argon_female_dyn_overall_crew_01_macro" },
            { 688663956, "character_scenario_combat_arg_helm_macro" },
            { 633415737, "character_scenario_combat_arg_marine_macro" },
            { 2231393842, "character_scenario_combat_arg_marine_macro" },
            { 1578363950, "character_scenario_combat_arg_helm_macro" },
            { 622028542, "character_argon_male_dyn_overall_crew_01_macro" },
            { 251723862, "character_argon_male_pilot_08_macro" },
            { 1314417817, "character_gram_ar_f_service_macro" },
            { 2118596857, "character_scenario_combat_arg_marine_macro" },
            { 3399219336, "character_scenario_combat_arg_helm_macro" },
            { 161671091, "character_scenario_combat_arg_helm_macro" },
            { 1697716111, "character_scenario_combat_arg_gunner_macro" },
            { 1079087665, "character_argon_male_dyn_overall_crew_01_macro" },
            { 3924040035, "character_gram_player_tutorial_macro" },
            { 1016098350, "character_gram_ar_f_service_macro" },
            { 3343131761, "character_argon_male_pilot_08_macro" },
            { 3823083145, "character_gram_player_tutorial_macro" },
            { 3603739124, "character_argon_male_dyn_overall_crew_01_macro" },
            { 1807713903, "character_scenario_combat_arg_marine_macro" },
            { 3565352223, "character_scenario_combat_arg_marine_macro" },
            { 4025118465, "character_scenario_combat_arg_gunner_macro" },
            { 1410418455, "character_argon_male_dyn_overall_crew_01_macro" },
            { 2850184348, "character_scenario_combat_arg_gunner_macro" },
            { 796855833, "character_scenario_combat_arg_gunner_macro" },
            { 1333442313, "character_argon_male_dyn_overall_crew_01_macro" },
            { 2853162901, "character_argon_male_pilot_08_macro" },
            { 1316283095, "character_scenario_combat_arg_gunner_macro" },
            { 2571458986, "character_argon_male_dyn_overall_crew_01_macro" },
            { 2386376590, "character_scenario_combat_arg_navigation_macro" },
            { 3860521785, "character_gram_ar_f_service_macro" },
            { 2717498360, "character_argon_female_dyn_overall_crew_01_macro" },
            { 851651504, "character_scenario_combat_arg_gunner_macro" },
            { 919515513, "character_argon_male_dyn_overall_crew_01_macro" },
            { 1765538152, "character_scenario_combat_arg_gunner_macro" },
            { 589544501, "character_scenario_combat_arg_navigation_macro" },
            { 229357995, "character_scenario_combat_arg_captain_macro" },
            { 811175605, "character_argon_male_dyn_overall_crew_01_macro" },
            { 4014875333, "character_scenario_combat_arg_navigation_macro" },
            { 3431837864, "character_scenario_combat_arg_captain_macro" },
            { 3050453749, "character_scenario_combat_arg_navigation_macro" },
            { 1574906060, "character_scenario_combat_arg_navigation_macro" },
            { 1541171902, "character_scenario_combat_arg_helm_macro" },
            { 1530128342, "character_gram_split_f_service_macro" },
            { 1999623303, "character_gram_ar_f_marine_02_macro" },
            { 3025707364, "character_scenario_combat_arg_gunner_macro" },
            { 2762563206, "character_gram_ar_f_marine_02_macro" },
            { 2254341530, "character_scenario_combat_arg_captain_macro" },
            { 4000092767, "character_scenario_combat_arg_navigation_macro" },
            { 624321109, "character_argon_female_dyn_overall_crew_01_macro" },
            { 3700511110, "character_argon_male_marine_helmet_01_macro" },
            { 2724852973, "character_argon_female_dyn_overall_crew_01_macro" },
            { 137418089, "character_gram_split_m_marine_macro" },
            { 4135861749, "character_scenario_combat_arg_navigation_macro" },
            { 2441307996, "character_scenario_combat_arg_gunner_macro" },
            { 1661838395, "character_gram_player_tutorial_macro" },
            { 420894093, "character_gram_split_f_service_macro" },
            { 3802018252, "character_scenario_combat_arg_navigation_macro" },
            { 192245266, "character_scenario_combat_arg_gunner_macro" },
            { 418084583, "character_gram_player_tutorial_macro" },
            { 3963049462, "character_gram_ar_f_commander_macro" },
            { 2928406581, "character_scenario_combat_arg_helm_macro" },
            { 2871009888, "character_gram_player_tutorial_macro" },
            { 3903313848, "character_scenario_combat_arg_captain_macro" },
            { 1358156205, "character_scenario_combat_arg_marine_macro" },
            { 4230322520, "character_scenario_combat_arg_helm_macro" },
            { 483030940, "character_argon_female_dyn_jacket_fighterpilot_01_macro" },
            { 3945569336, "character_scenario_combat_arg_captain_macro" },
            { 1322571680, "character_gram_player_scenario_combat_argon_macro" },
            { 2456732788, "character_scenario_combat_arg_helm_macro" },
            { 4254755911, "character_argon_female_dyn_overall_crew_01_macro" },
            { 995015171, "character_gram_player_discover_macro" },
            { 3221820463, "character_argon_male_dyn_overall_crew_01_macro" },
            { 1461882915, "character_gram_player_discover_macro" },
            { 3750859316, "character_scenario_combat_arg_navigation_macro" },
            { 4031383422, "character_argon_male_dyn_overall_crew_01_macro" },
            { 3714460146, "character_argon_female_dyn_overall_crew_01_macro" },
            { 1770075775, "character_argon_female_dyn_overall_crew_01_macro" },
            { 999029522, "character_argon_female_dyn_overall_crew_01_macro" },
            { 2397752606, "character_argon_female_dyn_overall_crew_01_macro" },
            { 293470624, "character_gram_ar_f_service_macro" },
            { 2394224969, "character_argon_male_dyn_overall_crew_01_macro" },
            { 172161144, "character_argon_female_dyn_overall_crew_01_macro" },
            { 3283781781, "character_gram_ar_f_service_macro" },
            { 260055239, "character_scenario_combat_arg_navigation_macro" },
            { 1411120298, "character_scenario_combat_arg_navigation_macro" },
            { 1636653961, "character_argon_female_dyn_overall_crew_01_macro" },
            { 59171938, "character_scenario_combat_arg_gunner_macro" },
            { 1563753547, "character_scenario_combat_arg_navigation_macro" },
            { 1414172692, "character_scenario_combat_arg_navigation_macro" },
            { 1794155071, "character_scenario_combat_arg_gunner_macro" },
            { 757618053, "character_scenario_combat_arg_gunner_macro" },
            { 579717789, "character_scenario_combat_arg_navigation_macro" },
            { 847516351, "character_scenario_combat_arg_gunner_macro" },
            { 2106949056, "character_scenario_combat_arg_navigation_macro" },
            { 2361620637, "character_scenario_combat_arg_helm_macro" },
            { 1120932551, "character_scenario_combat_arg_marine_macro" },
            { 3344187128, "character_argon_male_pilot_08_macro" },
            { 1140115093, "character_scenario_combat_arg_helm_macro" },
            { 2085588342, "character_argon_female_dyn_overall_crew_01_macro" },
            { 1540399655, "character_argon_male_dyn_overall_crew_01_macro" },
            { 479181727, "character_argon_female_dyn_overall_crew_01_macro" },
            { 781692872, "character_gram_split_f_service_macro" },
            { 1666573858, "character_scenario_combat_arg_navigation_macro" },
            { 1116809842, "character_argon_male_dyn_overall_crew_01_macro" },
            { 1517698877, "character_scenario_combat_arg_gunner_macro" },
            { 1011484427, "character_gram_player_discover_macro" },
            { 3709042280, "character_gram_split_f_service_macro" },
            { 261218328, "character_argon_male_dyn_overall_crew_01_macro" },
            { 1307405582, "character_scenario_combat_arg_helm_macro" },
            { 1833237802, "character_argon_female_dyn_overall_crew_01_macro" },
            { 559192976, "character_scenario_combat_arg_marine_macro" },
            { 462305562, "character_scenario_combat_arg_helm_macro" },
            { 2836931582, "character_scenario_combat_arg_gunner_macro" },
            { 3392599737, "character_gram_split_m_marine_macro" },
            { 3525288957, "character_argon_male_marine_helmet_01_macro" },
            { 4093822198, "character_gram_split_f_marine_macro" },
            { 2225807128, "character_scenario_combat_arg_navigation_macro" },
            { 1137899911, "character_argon_male_dyn_overall_crew_01_macro" },
            { 3391778031, "character_scenario_combat_arg_gunner_macro" },
            { 2065585666, "character_scenario_combat_arg_navigation_macro" },
            { 568612473, "character_scenario_combat_arg_navigation_macro" },
            { 281438744, "character_argon_male_dyn_overall_crew_01_macro" },
            { 1311915008, "character_scenario_combat_arg_navigation_macro" },
            { 3748753572, "character_gram_ar_f_service_macro" },
            { 754541064, "character_scenario_combat_arg_gunner_macro" },
            { 1178244799, "character_scenario_combat_arg_navigation_macro" },
            { 3077652218, "character_argon_male_dyn_overall_crew_01_macro" },
            { 2573376561, "character_argon_female_dyn_overall_crew_01_macro" },
            { 927013505, "character_argon_female_dyn_overall_crew_01_macro" },
            { 3197549754, "character_argon_female_dyn_overall_crew_01_macro" },
            { 2020048407, "character_gram_ar_f_service_macro" },
            { 2335628564, "character_scenario_combat_arg_gunner_macro" },
            { 3593607200, "character_scenario_combat_arg_gunner_macro" },
            { 4253625365, "character_argon_female_dyn_overall_crew_01_macro" },
            { 2867991676, "character_argon_female_dyn_overall_crew_01_macro" },
            { 3708809195, "character_scenario_combat_arg_gunner_macro" },
            { 2018795027, "character_gram_split_f_service_macro" },
            { 1661853207, "character_gram_ar_f_service_macro" },
            { 3018726402, "character_scenario_combat_arg_gunner_macro" },
            { 1807201399, "character_scenario_combat_arg_navigation_macro" },
            { 2863830583, "character_scenario_combat_arg_navigation_macro" },
            { 3707306378, "character_argon_male_dyn_overall_crew_01_macro" },
            { 1670805902, "character_argon_male_dyn_overall_crew_01_macro" },
            { 3556517388, "character_argon_male_engineer_06_macro" },
            { 1871914460, "character_argon_female_engineer_04_macro" },
            { 4252791048, "character_scenario_combat_arg_gunner_macro" },
            { 3445425953, "character_scenario_combat_arg_navigation_macro" },
            { 2785577278, "character_argon_male_dyn_overall_crew_01_macro" },
            { 88347807, "character_argon_female_dyn_overall_crew_01_macro" },
            { 3883304748, "character_argon_female_engineer_02_macro" },
            { 1542921096, "character_argon_female_dyn_overall_crew_01_macro" },
            { 3422158342, "character_argon_male_engineer_04_macro" },
            { 4092101249, "character_gram_ar_f_service_macro" },
            { 107490487, "character_scenario_combat_arg_gunner_macro" },
            { 1816766118, "character_scenario_combat_arg_gunner_macro" },
            { 2082757491, "character_scenario_combat_arg_gunner_macro" },
            { 4162703856, "character_argon_male_dyn_overall_crew_01_macro" },
            { 2793600580, "character_scenario_combat_arg_gunner_macro" },
            { 2120893218, "character_argon_female_dyn_overall_crew_01_macro" },
            { 2269923132, "character_gram_ar_f_service_macro" },
            { 1256364776, "character_scenario_combat_arg_gunner_macro" },
            { 2861656068, "character_gram_ar_f_service_macro" },
            { 1069524477, "character_scenario_combat_arg_helm_macro" },
            { 3057100730, "character_scenario_combat_arg_navigation_macro" },
            { 3103775740, "character_argon_female_dyn_overall_crew_01_macro" },
            { 3299431400, "character_gram_ar_f_marine_macro" },
            { 3028308665, "character_argon_female_dyn_overall_crew_01_macro" },
            { 4096498527, "character_gram_ar_f_marine_macro" },
            { 3694901142, "character_argon_male_dyn_overall_crew_01_macro" },
            { 804609531, "character_argon_male_dyn_overall_crew_01_macro" },
            { 3417449873, "character_scenario_combat_arg_marine_macro" },
            { 1448561817, "character_scenario_combat_arg_helm_macro" },
            { 1649131191, "character_gram_ar_f_marine_macro" },
            { 3399317708, "character_gram_ar_f_service_macro" },
            { 4252726022, "character_gram_split_f_service_macro" },
            { 2413082219, "character_gram_player_discover_macro" },
            { 2065289077, "character_scenario_combat_arg_navigation_macro" },
            { 1641623618, "character_argon_male_dyn_overall_crew_01_macro" },
            { 3235440560, "character_scenario_combat_arg_gunner_macro" },
            { 2594941812, "character_scenario_combat_arg_navigation_macro" },
            { 4124746483, "character_scenario_combat_arg_gunner_macro" },
            { 2570076791, "character_scenario_combat_arg_helm_macro" },
            { 3803706623, "character_scenario_combat_arg_helm_macro" },
            { 1330448502, "character_argon_male_dyn_overall_crew_01_macro" },
            { 2414011995, "character_scenario_combat_arg_marine_macro" },
            { 3877748245, "character_argon_male_dyn_overall_crew_01_macro" },
            { 2048299068, "character_argon_female_dyn_overall_crew_01_macro" },
            { 3783873663, "character_argon_female_dyn_overall_crew_01_macro" },
            { 2734450928, "character_scenario_combat_arg_marine_macro" },
            { 1687354065, "character_argon_male_dyn_overall_crew_01_macro" },
            { 3071028235, "character_scenario_combat_arg_helm_macro" },
            { 726667568, "character_scenario_combat_arg_marine_macro" },
            { 4064124546, "character_scenario_combat_arg_navigation_macro" },
            { 3209662687, "character_scenario_combat_arg_navigation_macro" },
            { 4055674065, "character_scenario_combat_arg_helm_macro" },
            { 3637987842, "character_scenario_combat_arg_navigation_macro" },
            { 1643964160, "character_gram_ar_f_marine_macro" },
            { 2519645630, "character_argon_female_dyn_overall_crew_01_macro" },
            { 4223050934, "character_argon_male_dyn_overall_crew_01_macro" },
            { 2266502599, "character_argon_male_dyn_overall_crew_01_macro" },
            { 3371422554, "character_gram_ar_f_service_macro" },
            { 1389932428, "character_gram_ar_f_service_macro" },
            { 2614113418, "character_scenario_combat_arg_navigation_macro" },
            { 1770656694, "character_gram_split_f_service_macro" },
            { 1281107893, "character_argon_female_dyn_overall_crew_01_macro" }
        };

        /// <summary>
        /// Pilot with Goggles
        /// </summary>
        public static IReadOnlyCharacterBluePrint UgoNedley => new CharacterBluePrint() { Model = "character_scenario_combat_arg_helm_macro", Seed = 1432977127 };

        /// <summary>
        /// Pilot with Darker Goggles
        /// </summary>
        public static IReadOnlyCharacterBluePrint JanitMortell => new CharacterBluePrint() { Model = "character_scenario_combat_arg_helm_macro", Seed = 3473745825 };

        /// <summary>
        /// Pilot with Shades
        /// </summary>
        public static IReadOnlyCharacterBluePrint HanesCherum => new CharacterBluePrint() { Model = "character_scenario_combat_arg_helm_macro", Seed = 539772566 };

        /// <summary>
        /// Pretty Female Pilot
        /// </summary>
        public static IReadOnlyCharacterBluePrint TaylaSeldon => new CharacterBluePrint() { Model = "character_scenario_combat_arg_captain_macro", Seed = 1895929364 };

        /// <summary>
        /// Service woman with dark straight hair
        /// </summary>
        public static IReadOnlyCharacterBluePrint NaschaMortell => new CharacterBluePrint() { Model = "character_scenario_combat_arg_navigation_macro", Seed = 3749315395 };

        /// <summary>
        /// Plain looking service woman with pinned up hair
        /// </summary>
        public static IReadOnlyCharacterBluePrint SayreenCornell => new CharacterBluePrint() { Model = "character_argon_female_dyn_overall_crew_01_macro", Seed = 517290273 };

        /// <summary>
        /// Plain looking service woman with pinned up hair
        /// </summary>
        public static IReadOnlyCharacterBluePrint VanaRolen => new CharacterBluePrint() { Model = "character_argon_female_dyn_overall_crew_01_macro", Seed = 3163392084 };

        /// <summary>
        /// Plain looking service man
        /// </summary>
        public static IReadOnlyCharacterBluePrint SamanBarnard => new CharacterBluePrint() { Model = "character_argon_male_dyn_overall_crew_01_macro", Seed = 4215589115 };

        public static class Officers
        {
            public static IReadOnlyList<string> UniqueMacros { get; } = new List<string>()
            {
                "character_argon_male_marine_mk1_01_macro",
                "character_argon_male_marine_mk2_01_macro",
                "character_argon_male_marine_mk3_01_macro",
            };

            /// <summary>
            /// Officer with Dark Pants
            /// </summary>
            public static IReadOnlyCharacterBluePrint DavenSelek => new CharacterBluePrint() { Model = "character_argon_male_generic_01_macro", Seed = 1217498717 };

            /// <summary>
            /// Officer with gray pants and shades
            /// </summary>
            public static IReadOnlyCharacterBluePrint ElisterDelsen => new CharacterBluePrint() { Model = "character_argon_male_marine_mk1_01_macro", Seed = 3095298694 };

            /// <summary>
            /// Officer with gray pants
            /// </summary>
            public static IReadOnlyCharacterBluePrint FlotYatar => new CharacterBluePrint() { Model = "character_argon_male_marine_mk2_01_macro", Seed = 1937961240 };

            /// <summary>
            /// Officer with gray pants
            /// </summary>
            public static IReadOnlyCharacterBluePrint JanitDelson => new CharacterBluePrint() { Model = "character_argon_male_marine_mk3_01_macro", Seed = 1512323585 };

            /// <summary>
            /// Officer with dark pants and hat
            /// </summary>
            public static IReadOnlyCharacterBluePrint DalSmitt => new CharacterBluePrint() { Model = "character_argon_male_marine_mk1_01_macro", Seed = 1202669053 };

            /// <summary>
            /// Officer with gray pants and shades
            /// </summary>
            public static IReadOnlyCharacterBluePrint DavenWeamond => new CharacterBluePrint() { Model = "character_argon_male_marine_mk3_01_macro", Seed = 1395785203 };

            /// <summary>
            /// Officer with black pants
            /// </summary>
            public static IReadOnlyCharacterBluePrint GabreelKult => new CharacterBluePrint() { Model = "character_argon_male_marine_mk3_01_macro", Seed = 1771895992 };

            /// <summary>
            /// Officer with dark pants and nice shoes
            /// </summary>
            public static IReadOnlyCharacterBluePrint AronMotoli => new CharacterBluePrint() { Model = "character_argon_male_marine_mk3_01_macro", Seed = 61722316 };

            /// <summary>
            /// Officer with dark pants and nice shoes
            /// </summary>
            public static IReadOnlyCharacterBluePrint AdsenRaner => new CharacterBluePrint() { Model = "character_argon_male_marine_mk1_01_macro", Seed = 1164459476 };

            /// <summary>
            /// Officer with gray pants and hat
            /// </summary>
            public static IReadOnlyCharacterBluePrint AdsenYatar => new CharacterBluePrint() { Model = "character_argon_male_civilian_08_macro", Seed = 712998717 };
        }
    }
}