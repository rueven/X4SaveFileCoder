﻿using System.Collections.Generic;
using X4.Models.Implementations;
using X4.Models.Interfaces;

namespace X4.Services.Implementations.CharacterLibraryServices
{
    public class MarineClonesUniformService
        : CharacterLibraryService
    {
        public MarineClonesUniformService()
            : base("Armored Marine Clones")
        { }

        protected override IReadOnlyList<IReadOnlyCharacterBluePrint> List { get; } = new CharacterBluePrintList()
        {
            { 3503075733, "character_argon_male_pilot_01_macro" },
            { 3503085910, "character_argon_male_pilot_01_macro" },
            { 3503095726, "character_argon_male_pilot_01_macro" },
            { 3503105964, "character_argon_male_pilot_01_macro" },
            { 3503115960, "character_argon_male_pilot_01_macro" },
            { 3503126338, "character_argon_male_pilot_01_macro" },
            { 3503136143, "character_argon_male_pilot_01_macro" },
            { 3503146104, "character_argon_male_pilot_01_macro" },
            { 3503075447, "character_argon_male_pilot_01_macro" },
            { 3503085447, "character_argon_male_pilot_01_macro" },
            { 3503095447, "character_argon_male_pilot_01_macro" },
            { 3503105447, "character_argon_male_pilot_01_macro" },
            { 3503115447, "character_argon_male_pilot_01_macro" },
            { 3503125447, "character_argon_male_pilot_01_macro" },
            { 3503135447, "character_argon_male_pilot_01_macro" },
            { 3503145447, "character_argon_male_pilot_01_macro" },
            { 3503155447, "character_argon_male_pilot_01_macro" },
            { 3503165447, "character_argon_male_pilot_01_macro" },
            { 3503175447, "character_argon_male_pilot_01_macro" },
            { 3503185447, "character_argon_male_pilot_01_macro" },
            { 3503195447, "character_argon_male_pilot_01_macro" },
            { 3503205447, "character_argon_male_pilot_01_macro" },
            { 3503215447, "character_argon_male_pilot_01_macro" },
            { 3503225447, "character_argon_male_pilot_01_macro" },
            { 3503235447, "character_argon_male_pilot_01_macro" },
            { 3503245447, "character_argon_male_pilot_01_macro" },
            { 3503255447, "character_argon_male_pilot_01_macro" },
            { 3503265447, "character_argon_male_pilot_01_macro" },
            { 3503275447, "character_argon_male_pilot_01_macro" },
            { 3503285447, "character_argon_male_pilot_01_macro" },
            { 3503295447, "character_argon_male_pilot_01_macro" },
            { 3503305447, "character_argon_male_pilot_01_macro" },
            { 3503315447, "character_argon_male_pilot_01_macro" },
        };

        /// <summary>
        /// A marine wearing armor and helmet
        /// </summary>
        public static IReadOnlyCharacterBluePrint DenBraks => new CharacterBluePrint() { Model = "character_argon_male_pilot_01_macro", Seed = 3503065447 };
    }
}
