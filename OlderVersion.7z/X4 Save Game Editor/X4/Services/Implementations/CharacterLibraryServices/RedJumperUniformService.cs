﻿using System.Collections.Generic;
using X4.Models.Implementations;
using X4.Models.Interfaces;

namespace X4.Services.Implementations.CharacterLibraryServices
{
    public class RedJumperUniformService
        : CharacterLibraryService
    {
        public RedJumperUniformService()
            : base("Red Skin-Tight Jumper")
        { }

        protected override IReadOnlyList<IReadOnlyCharacterBluePrint> List { get; } = new CharacterBluePrintList()
        {
            { 2203244736, "character_argon_male_civilian_03_macro" },
            { 882824760, "character_argon_female_civilian_03_macro" },
            { 1447431566, "character_gram_ar_f_simona_01_macro" },
        };
    }
}
