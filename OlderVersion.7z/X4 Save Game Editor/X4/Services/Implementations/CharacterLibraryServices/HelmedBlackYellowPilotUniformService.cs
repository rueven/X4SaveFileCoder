﻿using System.Collections.Generic;
using X4.Models.Implementations;
using X4.Models.Interfaces;

namespace X4.Services.Implementations.CharacterLibraryServices
{
    public class HelmedBlackYellowPilotUniformService
        : CharacterLibraryService
    {
        public HelmedBlackYellowPilotUniformService()
            : base("Helmed Black Uniforms with Yellow Highlights")
        { }

        protected override IReadOnlyList<IReadOnlyCharacterBluePrint> List { get; } = new CharacterBluePrintList()
        {
            { 2365199643, "character_argon_male_pilot_04_macro" },
            { 1293552967, "character_argon_female_pilot_03_macro" },
            { 1883180772, "character_argon_female_pilot_05_macro" },
            { 1294533822, "character_argon_female_pilot_04_macro" },
            { 4202667443, "character_argon_female_pilot_04_macro" },
            { 3805409340, "character_argon_female_pilot_03_macro" },
            { 3574111853, "character_argon_female_pilot_03_macro" },
            { 1279115266, "character_argon_female_pilot_03_macro" },
            { 2183259395, "character_argon_female_pilot_04_macro" },
            { 1864832497, "character_argon_female_pilot_03_macro" },
            { 3748492292, "character_argon_female_pilot_03_macr" },
            { 3156978049, "character_argon_male_pilot_05_macro" },
            { 1613870234, "character_argon_male_pilot_03_macro" },
            { 1118902976, "character_argon_female_pilot_04_macro" },
            { 1333963714, "character_argon_male_pilot_05_macro" },
            { 817376957, "character_argon_female_pilot_05_macro" },
            { 274818736, "character_argon_female_pilot_04_macro" },
            { 661087660, "character_argon_male_pilot_05_macro" },
            { 835117084, "character_argon_male_pilot_04_macro" },
            { 2777342901, "character_argon_male_pilot_05_macro" },
            { 2162690375, "character_argon_female_pilot_05_macro" },
            { 1335547849, "character_argon_male_pilot_03_macro" },
            { 3960504871, "character_argon_female_pilot_04_macro" },
            { 1905538855, "character_argon_female_pilot_03_macro" },
            { 3781398256, "character_argon_female_pilot_03_macro" },
            { 3732241396, "character_argon_female_pilot_03_macro" },
            { 3614987211, "character_argon_female_pilot_03_macro" },
            { 132853694, "character_argon_female_pilot_05_macro" },
            { 2555081081, "character_argon_female_pilot_04_macro" },
            { 1066380415, "character_argon_female_pilot_05_macro" },
            { 171585360, "character_argon_male_pilot_07_macro" },
            { 773303277, "character_argon_female_pilot_05_macro" },
            { 2252030041, "character_argon_female_pilot_05_macro" },
            { 3498136763, "character_argon_female_pilot_04_macro" },
            { 3475527939, "character_argon_female_pilot_04_macro" },
            { 2462060428, "character_argon_female_pilot_04_macro" }
        };
    }
}
