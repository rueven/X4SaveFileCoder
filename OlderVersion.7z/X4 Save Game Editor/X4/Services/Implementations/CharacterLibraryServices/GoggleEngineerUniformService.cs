﻿using System.Collections.Generic;
using X4.Models.Implementations;
using X4.Models.Interfaces;

namespace X4.Services.Implementations.CharacterLibraryServices
{
    public class GoggleEngineerUniformService
        : CharacterLibraryService
    {
        public GoggleEngineerUniformService()
            : base("Engineers in Jumpsuits and goggles")
        { }

        protected override IReadOnlyList<IReadOnlyCharacterBluePrint> List { get; } = new CharacterBluePrintList()
        {
            { 506639805, "character_argon_male_engineer_01_macro" },
            { 3105558105, "character_argon_female_engineer_01_macro" },
            { 2394299807, "character_argon_male_engineer_01_macro" },
            { 1538509831, "character_argon_male_engineer_01_macro" },
            { 2077794476, "character_argon_female_engineer_01_macro" },
            { 511477008, "character_argon_female_engineer_01_macro" },
            { 3778169407, "character_argon_female_engineer_01_macro" },
            { 3465267167, "character_argon_male_engineer_01_macro" },
            { 4173743402, "character_argon_male_engineer_02_macro" },
            { 38818629, "character_argon_female_engineer_01_macro" },
            { 3662128356, "character_argon_male_engineer_03_macro" },
            { 2785674270, "character_argon_male_engineer_03_macro" },
        };
    }
}
