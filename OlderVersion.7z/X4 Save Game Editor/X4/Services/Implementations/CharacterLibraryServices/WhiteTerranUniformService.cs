﻿using X4.Extensions;
using X4.Models.Implementations;
using X4.Models.Interfaces;
using X4.Objects.Interfaces;

namespace X4.Services.Implementations.CharacterLibraryServices
{
    class WhiteTerranUniformService
    {
        //Bald guy
        public static IReadOnlyCharacterBluePrint RobinLong => new CharacterBluePrint() { Model = "character_terran_male_asi_manager_01_macro", Seed = 3932120800 };
        /// <summary>
        /// Original Haile Shinamon
        /// </summary>
        public static IReadOnlyCharacterBluePrint HaileShinamon => new CharacterBluePrint() { Model = "character_terran_male_plot_wingmate_macro", Seed = 2942070012 };
        public static void OverwriteAsHaileShinamon(IPilot pilot)
        {
            /*
             Supposed to be...
               Piloting 5
               Morale 4
               Engineering 2
               Boarding 1
               Management 0
            */
            pilot
                .SetModel(HaileShinamon.Model)
                .SetSeed(HaileShinamon.Seed)
                .TrainCharacter(Constants.CharacterTraitValue.Elite);
        }
    }
}
