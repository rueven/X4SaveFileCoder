﻿using System.Collections.Generic;
using X4.Models.Implementations;
using X4.Models.Interfaces;

namespace X4.Services.Implementations.CharacterLibraryServices
{
    public class RedWhitePilotUniformService
        : CharacterLibraryService
    {
        public RedWhitePilotUniformService()
            : base("Red & White Pilot Uniform")
        { }

        protected override IReadOnlyList<IReadOnlyCharacterBluePrint> List { get; } = new CharacterBluePrintList()
        {
            { 351121423, "character_argon_male_pilot_04_macro" },
            { 3359633700, "character_argon_male_pilot_06_macro" },
            { 2655156346, "character_argon_male_pilot_07_macro" },
            { 2922140169, "character_argon_male_pilot_01_macro" },
            { 950770281, "character_argon_male_pilot_04_macro" },
            { 2552959224, "character_argon_male_pilot_01_macro" },
            { 981412188, "character_argon_male_pilot_04_macro" },
            { 109469425, "character_argon_male_pilot_05_macro" },
            { 1688204479, "character_argon_male_pilot_01_macro" },
            { 3881158810, "character_argon_male_pilot_03_macro" },
            { 3294411444, "character_argon_male_pilot_01_macro" },
            { 4021314394, "character_argon_male_pilot_03_macro" },
            { 982491980, "character_argon_male_pilot_03_macro" },
            { 2977590853, "character_argon_male_pilot_07_macro" },
            { 3576051102, "character_argon_male_pilot_06_macro" },
            { 1772654036, "character_argon_male_pilot_06_macro" }
        };

        /// <summary>
        /// Cool Female Terran Blond Pilot
        /// </summary>
        public static IReadOnlyCharacterBluePrint TsuzuneKapoor => new CharacterBluePrint() { Model = "character_terran_female_cau_pilot_01_macro", Seed = 3800032027 };
    }
}
