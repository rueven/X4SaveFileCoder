﻿using System.Collections.Generic;
using X4.Models.Implementations;
using X4.Models.Interfaces;

namespace X4.Services.Implementations.CharacterLibraryServices
{
    public class BlackYellowPilotUniformService
        : CharacterLibraryService
    {
        public BlackYellowPilotUniformService()
            : base("Black Uniforms with Yellow Highlights")
        { }

        protected override IReadOnlyList<IReadOnlyCharacterBluePrint> List { get; } = new CharacterBluePrintList()
        {
            { 3332839592, "character_argon_male_pilot_03_macro" },
            { 3891523687, "character_argon_male_pilot_06_macro" },
            { 1563517974, "character_argon_male_pilot_06_macro" },
            { 2604977362, "character_argon_male_pilot_07_macro" },
            { 1957805725, "character_argon_male_pilot_07_macro" },
            { 1162716575, "character_argon_male_pilot_06_macro" },
            { 1377706774, "character_argon_male_pilot_07_macro" },
            { 1156530731, "character_argon_male_pilot_06_macro" },
            { 171585360, "character_argon_male_pilot_07_macro" },
            { 1686285261, "character_argon_male_pilot_06_macro" },
            { 3359840396, "character_argon_male_pilot_05_macro" },
            { 3830084746, "character_argon_male_pilot_07_macro" },
            { 1791895253, "character_argon_female_pilot_03_macro" },
            { 1733703377, "character_argon_female_pilot_03_macro" },
            { 3380906906, "character_argon_female_pilot_03_macro" },
            { 3427025881, "character_argon_female_pilot_05_macro" },
            { 1339250542, "character_argon_female_pilot_03_macro" },
            { 940024996, "character_argon_female_pilot_04_macro" },
            { 2958297215, "character_argon_female_pilot_04_macro" },
            { 2774930222, "character_argon_female_pilot_04_macro" },
            { 1118928226, "character_argon_female_pilot_03_macro" },
            { 2814254205, "character_argon_female_pilot_04_macro" },
            { 3475527939, "character_argon_female_pilot_04_macro" },
            { 4071205766, "character_argon_female_pilot_03_macro" },
            { 2462060428, "character_argon_female_pilot_04_macro" },
            { 773303277, "character_argon_female_pilot_05_macro" },
            { 3498136763, "character_argon_female_pilot_04_macro" },
            { 2252030041, "character_argon_female_pilot_05_macro" },
            { 1320107966, "character_argon_female_pilot_03_macro" },
            { 65186885, "character_argon_female_pilot_05_macro" },
            { 2469958554, "character_argon_female_pilot_04_macro" }
        };
    }
}
