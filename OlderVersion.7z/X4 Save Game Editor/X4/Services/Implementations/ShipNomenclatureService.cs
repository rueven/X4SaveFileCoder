﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Xml;
using X4.Extensions;
using X4.Objects.Interfaces;

namespace X4.Services.Implementations
{
    public class ShipNomenclatureService
    {
        private List<Registry<IShip>> ShipCodes { get; } = new List<Registry<IShip>>();
        private List<Registry<IStation>> StationCodes { get; } = new List<Registry<IStation>>();
        private List<IBlackListItem> BlackList { get; } = new List<IBlackListItem>();
        private List<Qualifier<IShip>> ShipQualifiers { get; } = new List<Qualifier<IShip>>();
        private List<Qualifier<IStation>> StationQualifiers { get; } = new List<Qualifier<IStation>>();

        public void RegisterShip(IShip ship)
        {
            var registry = new Registry<IShip>()
            {
                Item = ship.Clone()
            };
            this.ShipCodes.Add(registry);
        }

        public void RegisterStation(IStation station)
        {
            var registry = new Registry<IStation>()
            {
                Item = station.Clone()
            };
            this.StationCodes.Add(registry);
        }

        public ShipNomenclatureService AddBlackListedShipCode(string prefix, int id)
        {
            this.BlackList.Add(new FullMatchBlackListItem()
            {
                Prefix = prefix,
                Id = id
            });
            return this;
        }

        public ShipNomenclatureService AddBlackListedShipCode(string prefix)
        {
            this.BlackList.Add(new PrefixMatchBlackListItem()
            {
                Prefix = prefix
            });
            return this;
        }

        public ShipNomenclatureService RegisterShipSkip(Func<IShip, bool> qualifier)
        {
            this.ShipQualifiers.Add(new Qualifier<IShip>()
            {
                Execute = qualifier,
                QualifierSeed = QualifierSeed.Skip
            });
            return this;
        }

        public ShipNomenclatureService RegisterShipPrefixWithBackfill(string prefix, Func<IShip, bool> qualifier, bool reEvaluateQualifiers = false)
        {
            this.ShipQualifiers.Add(new Qualifier<IShip>()
            {
                Execute = qualifier,
                Prefix = prefix,
                ReEvaluateQualifiers = reEvaluateQualifiers,
                QualifierSeed = QualifierSeed.Backfill
            });
            return this;
        }

        public ShipNomenclatureService RegisterShipPrefixWithIncrementationFromCurrentHighestValue(string prefix, Func<IShip, bool> qualifier, bool reEvaluateQualifiers = false)
        {
            this.ShipQualifiers.Add(new Qualifier<IShip>()
            {
                Execute = qualifier,
                Prefix = prefix,
                ReEvaluateQualifiers = reEvaluateQualifiers,
                QualifierSeed = QualifierSeed.IncrementalFromHighest
            });
            return this;
        }

        public ShipNomenclatureService RegisterShipPrefixStartingFromValue(string prefix, int value, Func<IShip, bool> qualifier, bool reEvaluateQualifiers = false)
        {
            this.ShipQualifiers.Add(new QualifierWithStartValue<IShip>()
            {
                Execute = qualifier,
                Prefix = prefix,
                ReEvaluateQualifiers = reEvaluateQualifiers,
                QualifierSeed = QualifierSeed.StartAtValue,
                StartValue = value,
                CurrentValue = value
            });
            return this;
        }

        public ShipNomenclatureService RegisterStationPrefixWithBackfill(string prefix, Func<IStation, bool> qualifier, bool reEvaluateQualifiers = false)
        {
            this.StationQualifiers.Add(new Qualifier<IStation>()
            {
                Execute = qualifier,
                Prefix = prefix,
                QualifierSeed = QualifierSeed.Backfill,
                ReEvaluateQualifiers = reEvaluateQualifiers
            });
            return this;
        }

        public ShipNomenclatureService RegisterStationPrefixWithIncrementationFromCurrentHighestValue(string prefix, Func<IStation, bool> qualifier, bool reEvaluateQualifiers = false)
        {
            this.StationQualifiers.Add(new Qualifier<IStation>()
            {
                Execute = qualifier,
                Prefix = prefix,
                ReEvaluateQualifiers = reEvaluateQualifiers,
                QualifierSeed = QualifierSeed.IncrementalFromHighest
            });
            return this;
        }

        public ShipNomenclatureService RegisterStationPrefixStartingFromValue(string prefix, int value, Func<IStation, bool> qualifier, bool reEvaluateQualifiers = false)
        {
            this.StationQualifiers.Add(new QualifierWithStartValue<IStation>()
            {
                Execute = qualifier,
                Prefix = prefix,
                ReEvaluateQualifiers = reEvaluateQualifiers,
                QualifierSeed = QualifierSeed.StartAtValue,
                StartValue = value,
                CurrentValue = value
            });
            return this;
        }

        public object Execute(ISaveFile file)
        {
            var ships = this
                .Execute(file.ForEachPlayerShip, this.ShipCodes, this.ShipQualifiers);
            var stations = this
                .Execute(file.ForEachPlayerStation, this.StationCodes, this.StationQualifiers);
            return new
            {
                Ships = ships,
                Stations = stations
            };
        }

        private object Execute<T>(Func<Action<T>, ISaveFile> iterationMethod, IReadOnlyList<Registry<T>> registry, IReadOnlyList<Qualifier<T>> qualifiers)
            where T : class, IComponent<T>
        {
            var skipped = new List<object>();
            var recoded = new List<object>();
            var reEvaluated = new List<object>();
            iterationMethod(item =>
            {
                var wasReEvaluated = false;

                #region Check Blacklist
                var isBlackListed = this
                    .BlackList
                    .Any(x => x.IsMatch(item.Code));
                if (isBlackListed)
                {
                    skipped.Add(new
                    {
                        Item = item.Clone(),
                        Reason = "Blacklist match"
                    });
                    return;
                }
                #endregion

                #region  Check pre-existing naming convention compliance
                var prefix = item
                    .Code
                    .Substring(0, 3);
                var qualifier = qualifiers
                    .FirstOrDefault(x => x.Prefix == prefix);
                if (qualifier != null)
                {
                    if (qualifier.ReEvaluateQualifiers)
                    {
                        wasReEvaluated = true;
                    }
                    else
                    {
                        skipped.Add(new
                        {
                            Item = item.Clone(),
                            Reason = $"Already matched {qualifier.Prefix}"
                        });
                        return;
                    }
                }
                #endregion

                var id = 0;

                #region Find and execute qualifier
                qualifier = qualifiers
                    .FirstOrDefault(x => x.Execute(item));
                if (qualifier == null)
                {
                    skipped.Add(new
                    {
                        Item = item.Clone(),
                        Reason = $"No matching qualifier"
                    });
                    return;
                }
                switch (qualifier.QualifierSeed)
                {
                    case QualifierSeed.Skip:
                        skipped.Add(new
                        {
                            Item = item.Clone(),
                            Reason = $"Qualifier type 'Skip'"
                        });
                        return;
                    case QualifierSeed.Backfill:
                        id = this.GetLowestIdentifierForPrefix(registry, qualifier.Prefix);
                        break;
                    case QualifierSeed.IncrementalFromHighest:
                        id = this.GetNextIncrementalIdentifierForPrefix(registry, qualifier.Prefix);
                        break;
                    case QualifierSeed.StartAtValue:
                        id = ((QualifierWithStartValue<T>)qualifier).CurrentValue++;
                        break;
                    default:
                        throw new Exception("No qualifier seed");
                }
                #endregion

                recoded.Add(new
                {
                    OldCode = item.Code,
                    NewCode = $"{qualifier.Prefix}-{id.ToString("D3")}",
                    WasReEvaluated = wasReEvaluated,
                    Item = item.Clone()
                });
                item.SetCode($"{qualifier.Prefix}-{id.ToString("D3")}");
            });
            return new
            {
                Skipped = skipped,
                Recodes = recoded
            };
        }

        private int GetLowestIdentifierForPrefix<T>(IReadOnlyList<Registry<T>> registry, string prefix)
            where T: class, IComponent<T>
        {
            var ships = registry
                .Where(x => x.Prefix == prefix)
                .OrderBy(x => x.Id)
                .ToList();
            var predicted = 0;
            foreach (var ship in ships)
            {
                if (ship.Id != predicted)
                {
                    break;
                }
                predicted++;
            }
            return predicted;
        }

        private int GetNextIncrementalIdentifierForPrefix<T>(IReadOnlyList<Registry<T>> registry, string prefix)
            where T: class, IComponent<T>
        {
            var matches = registry
                .Where(x => x.Prefix == prefix);
            if (matches.Any())
            {
                return matches
                    .Max(x => x.Id) + 1;
            }
            return 0;
        }

        public enum QualifierSeed
        {
            Skip,
            Backfill,
            IncrementalFromHighest,
            StartAtValue
        }

        private class Qualifier<T>
            where T : class, IComponent<T>
        {
            public QualifierSeed QualifierSeed { get; set; }
            public Func<T, bool> Execute { get; set; }
            public string Prefix { get; set; }
            public bool ReEvaluateQualifiers { get; set; }
        }

        private class QualifierWithStartValue<T> : Qualifier<T>
            where T : class, IComponent<T>
        {
            public int StartValue { get; set; }
            public int CurrentValue { get; set; }
        }

        private interface IBlackListItem
        {
            bool IsMatch(string code);
        }

        private class PrefixMatchBlackListItem : IBlackListItem
        {
            public string Prefix { get; set; }
            public bool IsMatch(string code) => code.StartsWith(this.Prefix);
        }

        private class FullMatchBlackListItem : IBlackListItem
        {
            public string Prefix { get; set; }
            public int Id { get; set; }
            public bool IsMatch(string code) => code.StartsWith(this.Prefix) && code.EndsWith(this.Id.ToString("D3"));
        }

        private class Registry<T>
            where T : class, IComponent<T>
        {
            public string Prefix { get => this.Item.Code.Split('-')[0]; }
            public int Id { get => Convert.ToInt32(this.Item.Code.Split('-')[1]); }
            public T Item { get; set; }
        }
    }
}
