﻿using System;
using X4.Objects.Implementations;
using X4.Objects.Interfaces;
using X4.Services.Interfaces;

namespace X4.Services.Implementations
{
    public class ShipCodeService
        : IShipCoderService
    {
        public IShipCoder CreateShipCoder(Func<IShip, bool> selector, string prefix, int seed = 0)
        {
            return new ShipCoder(prefix, selector, seed);
        }
    }
}
