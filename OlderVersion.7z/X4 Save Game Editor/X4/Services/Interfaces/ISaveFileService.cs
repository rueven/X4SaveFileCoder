﻿using X4.Objects.Interfaces;

namespace X4.Services.Interfaces
{
    public interface ISaveFileService
    {
        ISaveFile LoadFromGZipSlot(int slot);
        ISaveFile LoadFromSlot(int slot);
        void Save(ISaveFile saveFile);
    }
}
