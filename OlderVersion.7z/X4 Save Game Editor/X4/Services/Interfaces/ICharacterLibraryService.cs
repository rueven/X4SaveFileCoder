﻿using System.Collections.Generic;
using X4.Models.Interfaces;
using X4.Objects.Interfaces;

namespace X4.Services.Interfaces
{
    public interface ICharacterLibraryService
    {
        string Name { get; }
        IReadOnlyList<IReadOnlyCharacterBluePrint> Fetch();
        ICharacterLibraryYielder CreateYielder(ISaveFile file = null);
    }
}
