﻿using X4.Objects.Interfaces;

namespace X4.Services.Interfaces
{
    public interface IGameSetupService
    {
        void Setup(ISaveFile file);
    }
}
