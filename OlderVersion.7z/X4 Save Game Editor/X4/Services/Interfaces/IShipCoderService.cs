﻿using System;
using X4.Objects.Interfaces;

namespace X4.Services.Interfaces
{
    public interface IShipCoderService
    {
        IShipCoder CreateShipCoder(Func<IShip, bool> selector, string prefix, int seed = 0);
    }
}
