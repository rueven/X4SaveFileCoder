﻿using Power.Utilities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Xml;
using X4.Constants;
using X4.Extensions;
using X4.Services.Implementations;

namespace X4.Helpers
{
    public static class CodeGeneration
    {
        public static void WithNamedClass(string name, StringBuilder target, Action action)
        {
            target
                .AppendLine($"public static class {name}")
                .AppendLine("{");
            action();
            target
                .AppendLine()
                .AppendLine("}");
        }

        public static void WithNamedClass<T, TKey>(IEnumerable<T> values, Func<T, TKey> selector, StringBuilder target, Action<IGrouping<TKey, T>> action)
        {
            var groupings = values
                .GroupBy(selector);
            foreach (var grouping in groupings)
            {
                WithNamedClass(grouping.Key.ToString(), target, () =>
                {
                    action(grouping);
                });
            }
        }

        private static IEnumerable<T> SelectCombinedRacialSet<T>(IEnumerable<IGrouping<Race?, T>> groupings, IGrouping<Race?, T> grouping)
        {
            if (!grouping.Key.HasValue || !grouping.Key.Value.IsPlayableRace()) { return new List<T>(); }
            return groupings
                .FirstOrDefault(x => x.Key == Race.Generic)
                ?.Union(grouping) ?? grouping;
        }

        public static string GenerateBluePrintConstants(IList<string> wareList)
        {
            var builder = new StringBuilder();
            var waresByAssetType = wareList
                .Where(x => !string.IsNullOrWhiteSpace(x))
                .Select(x => new
                {
                    Code = x,
                    AssetType = ItemCodeHelper.GetAssetType(x)
                })
                .Where(x => x.AssetType.HasValue)
                .ToList();
            CodeGeneration
                .WithNamedClass("BluePrints", builder, () =>
                {
                    CodeGeneration.WithNamedClass("Thrusters", builder, () =>
                    {
                        var thrusters = waresByAssetType
                            .Where(x => x.AssetType == AssetType.Thruster);
                        DrillDownClassTreeNodeHelper
                            .Create<string, ShipSize?>(builder, x => ItemCodeHelper.GetSize(x))
                            .AddNextNode(x => ItemCodeHelper.GetThrusterType(x))
                            .Execute
                            (
                                thrusters.Select(x => x.Code),
                                code => builder.AppendLine($"public const string {ItemCodeHelper.GetMake(code)} = \"{code}\";")
                            );
                    });
                    CodeGeneration.WithNamedClass("Engines", builder, () =>
                    {
                        var engines = waresByAssetType
                            .Where(x => x.AssetType == AssetType.Engine);
                        DrillDownClassTreeNodeHelper
                            .Create<string, Race?>(builder, x => ItemCodeHelper.GetRace(x))
                            .AddNextNode(x => ItemCodeHelper.GetSize(x))
                            .AddNextNode(x => ItemCodeHelper.GetEngineType(x))
                            .Execute
                            (
                                engines.Select(x => x.Code),
                                code => builder.AppendLine($"public const string {ItemCodeHelper.GetMake(code)} = \"{code}\";")
                            );
                    });
                    CodeGeneration.WithNamedClass("Shields", builder, () =>
                    {
                        var shields = waresByAssetType
                            .Where(x => x.AssetType == AssetType.Shield)
                            .Where(x => !x.Code.EndsWith("_m_standard_01_mk1") && !x.Code.EndsWith("_m_standard_01_mk2"));
                        DrillDownClassTreeNodeHelper
                            .Create<string, Race?>(builder, x => ItemCodeHelper.GetRace(x))
                            .AddNextNode(x => ItemCodeHelper.GetSize(x))
                            .Execute
                            (
                                shields.Select(x => x.Code),
                                code => builder.AppendLine($"public const string {ItemCodeHelper.GetMake(code)} = \"{code}\";")
                            );
                    });
                    CodeGeneration.WithNamedClass("Weapons", builder, () =>
                    {
                        var weapons = waresByAssetType
                            .Where(x => x.AssetType == AssetType.Weapon && ItemCodeHelper.GetGunType(x.Code) != GunType.Mine);
                        DrillDownClassTreeNodeHelper
                            .Create<string, Race?>(builder, x => ItemCodeHelper.GetRace(x))
                            .AddNextNode(x => ItemCodeHelper.GetSize(x))
                            .AddNextNode(x => ItemCodeHelper.GetGunType(x))
                            .Execute
                            (
                                weapons.Select(x => x.Code),
                                code => builder.AppendLine($"public const string {ItemCodeHelper.GetMake(code)} = \"{code}\";")
                            );
                    });
                    CodeGeneration.WithNamedClass("Turrets", builder, () =>
                    {
                        var turrets = waresByAssetType
                            .Where(x => x.AssetType == AssetType.Turret);
                        DrillDownClassTreeNodeHelper
                            .Create<string, Race?>(builder, x => ItemCodeHelper.GetRace(x))
                            .AddNextNode(x => ItemCodeHelper.GetSize(x))
                            .AddNextNode(x => ItemCodeHelper.GetGunType(x))
                            .Execute
                            (
                                turrets.Select(x => x.Code),
                                code => builder.AppendLine($"public const string {ItemCodeHelper.GetMake(code)} = \"{code}\";")
                            );
                    });
                });
            var output = builder
                .Replace("\r\n\r\n", "\r\n")
                .Replace("}\r\npublic", "}\r\n\r\npublic")
                .ToString();
            return output;
        }

        public static XmlDocument OpenDocument(string filepath)
        {
            var document = new XmlDocument();
            document.Load(filepath);
            return document;
        }

        /// <summary>
        /// This is here only so wont have to type from scratch later
        /// </summary>
        public static void SniffWares()
        {
            var nameLookupService = new NameLookupService();
            var wares = OpenDocument(@"c:\users\admin\desktop\x4 thing\extracted\libraries\wares.xml")
                .WithSelect(document =>
                {
                    return document
                        .SelectNodes(@"wares/ware[@tags='inventory paintmod']")
                        .Select(x => new
                        {
                            Id = x.Attributes["id"].Value,
                            Name = x.Attributes["name"].Value
                        }).ToList();
                });

            var namedWares = wares
                .Select(ware => new
                {
                    Id = ware.Id,
                    Name = nameLookupService.TranslateName(ware.Name)
                })
                .Select(ware => new
                {
                    Id = ware.Id,
                    Name = ware.Name.Replace(" ", string.Empty).Trim()
                }).ToList();

            var constants = namedWares
                .Select(x => $@"public const string {x.Name} = ""{x.Id}"";")
                .ToList()
                .Aggregate((x, y) => $"{x}\r\n{y}");
        }
    }
}
