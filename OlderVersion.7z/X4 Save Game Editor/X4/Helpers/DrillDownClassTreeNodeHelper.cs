﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace X4.Helpers
{
    public interface IDrillDownClassTreeNode<T>
    {
        IDrillDownClassTreeNode<T> AddNextNode<TNewKey>(Func<T, TNewKey> keySelector);
        IDrillDownClassTreeNode<T> AddNextNode<TNewKey>(Func<T, TNewKey> keySelector, Func<IEnumerable<IGrouping<TNewKey, T>>, IGrouping<TNewKey, T>, IEnumerable<T>> selectItems);
        void Execute(IEnumerable<T> values, Action<T> iterate);
        void Execute(IEnumerable<T> values, Action<T> iterate, bool findParent);
    }

    public static class DrillDownClassTreeNodeHelper
    {
        private static IEnumerable<T> SelectDefaultGrouping<TKey, T>(IEnumerable<IGrouping<TKey, T>> groupings, IGrouping<TKey, T> grouping) => grouping;

        public static IDrillDownClassTreeNode<T> Create<T, TKey>(StringBuilder builder, Func<T, TKey> keySelector) => DrillDownClassTreeNodeHelper.Create(builder, keySelector, DrillDownClassTreeNodeHelper.SelectDefaultGrouping);
        public static IDrillDownClassTreeNode<T> Create<T, TKey>(StringBuilder builder, Func<T, TKey> keySelector, Func<IEnumerable<IGrouping<TKey, T>>, IGrouping<TKey, T>, IEnumerable<T>> selectItems)
        {
            return new DrillDownClassTreeNode<TKey, T>()
            {
                Builder = builder,
                ParentNode = null,
                KeySelector = keySelector,
                SelectItems = selectItems
            };
        }

        class DrillDownClassTreeNode<TKey, T> : IDrillDownClassTreeNode<T>
        {
            public StringBuilder Builder { get; set; }
            public Func<T, TKey> KeySelector { get; set; }
            public Func<IEnumerable<IGrouping<TKey, T>>, IGrouping<TKey, T>, IEnumerable<T>> SelectItems { get; set; }
            public IDrillDownClassTreeNode<T> ParentNode { get; set; }
            public IDrillDownClassTreeNode<T> NextNode { get; set; }

            public IDrillDownClassTreeNode<T> AddNextNode<TNewKey>(Func<T, TNewKey> keySelector) => this.AddNextNode(keySelector, DrillDownClassTreeNodeHelper.SelectDefaultGrouping);
            public IDrillDownClassTreeNode<T> AddNextNode<TNewKey>(Func<T, TNewKey> keySelector, Func<IEnumerable<IGrouping<TNewKey, T>>, IGrouping<TNewKey, T>, IEnumerable<T>> selectItems)
            {
                this.NextNode = new DrillDownClassTreeNode<TNewKey, T>()
                {
                    Builder = this.Builder,
                    ParentNode = this,
                    KeySelector = keySelector,
                    SelectItems = selectItems
                };
                return this
                    .NextNode;
            }

            public void Execute(IEnumerable<T> values, Action<T> iterate) => this.Execute(values, iterate, true);

            public void Execute(IEnumerable<T> values, Action<T> iterate, bool findParent)
            {
                if (findParent)
                {
                    if (this.ParentNode == null)
                    {
                        this.Filter(values, iterate);
                        return;
                    }
                    else
                    {
                        this.ParentNode
                            .Execute(values, iterate, true);
                        return;
                    }
                }
                this.Filter(values, iterate);
            }

            public void Filter(IEnumerable<T> values, Action<T> iterate)
            {
                var groupings = values
                    .GroupBy(this.KeySelector);
                foreach (var grouping in groupings)
                {
                    var nextValues = this
                        .SelectItems(groupings, grouping);
                    if (nextValues?.Any() == true)
                    {
                        CodeGeneration
                            .WithNamedClass(grouping.Key.ToString(), this.Builder, () =>
                            {
                                if (this.NextNode == null)
                                {
                                    foreach (var value in nextValues)
                                    {
                                        iterate(value);
                                    }
                                }
                                else
                                {
                                    this.NextNode
                                        .Execute(nextValues, iterate, false);
                                }
                            });
                    }
                }
                
            }
        }
    }
}
