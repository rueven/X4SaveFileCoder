﻿using System;
using X4.Constants;

namespace X4.Helpers
{
    public static class ItemCodeHelper
    {
        public static string GetConstantName(string code, string name)
        {
            var output = name
                .Split(')')[0]
                .TrimStart('(')
                .Trim();
            if (output.Contains("1M6S"))
            {
                output = output
                    .Replace("1M6S", "Small");
            }
            else if (output.Contains("8M"))
            {
                output = output
                    .Replace("1M6S", "Medium");
            }
            else
            {
                var size = ItemCodeHelper
                    .GetSize(code);
                if (size.HasValue)
                {
                    output = $"{size.Value}{output}";
                }
                output = output
                    .Replace("LLiquid", "Liquid")
                    .Replace("LSolid", "Solid")
                    .Replace("LContainer", "Container")
                    .Replace("MLiquid", "Liquid")
                    .Replace("MSolid", "Solid")
                    .Replace("MContainer", "Container")
                    .Replace("SLiquid", "Liquid")
                    .Replace("SSolid", "Solid")
                    .Replace("SContainer", "Container");
            }
            return output
                .Replace(" ", string.Empty)
                .Replace("-", string.Empty)
                .Trim();
        }

        public static Race? GetRace(string code)
        {
            if (string.IsNullOrWhiteSpace(code))
            {
                throw new ArgumentNullException(nameof(code));
            }
            var source = code
                .ToLower();
            var output =
                source.Contains("_gen_") ? Race.Generic :
                source.Contains("_spl_") ? Race.Split :
                source.Contains("_arg_") ? Race.Argon :
                source.Contains("_tel_") ? Race.Teladi :
                source.Contains("_par_") ? Race.Paranid :
                source.Contains("_kha_") ? Race.Khak :
                source.Contains("_xen_") ? Race.Xenon : (Race?)null;
            return output;
        }

        public static ShipSize? GetSize(string code)
        {
            if (string.IsNullOrWhiteSpace(code))
            {
                throw new ArgumentNullException(nameof(code));
            }
            var source = code
                .ToLower();
            var output =
                source.Contains("_xl_") ? ShipSize.ExtraLarge :
                source.Contains("_l_") ? ShipSize.Large :
                source.Contains("_m_") ? ShipSize.Medium :
                source.Contains("_s_") ? ShipSize.Small : (ShipSize?)null;
            return output;
        }

        public static Make? GetMake(string code)
        {
            if (string.IsNullOrWhiteSpace(code))
            {
                throw new ArgumentNullException(nameof(code));
            }
            var source = code
                .ToLower();
            var output =
                (source.Contains("shield") && source.Contains("_standard_02_mk1")) ? Make.Mk1 :
                (source.Contains("shield") && source.Contains("_standard_02_mk2")) ? Make.Mk2 :
                source.Contains("01_mk1") ? Make.Mk1 :
                source.Contains("02_mk1") ? Make.Mk2 :
                source.Contains("03_mk1") ? Make.Mk3 :
                source.Contains("mk1") ? Make.Mk1 :
                source.Contains("mk2") ? Make.Mk2 :
                source.Contains("mk3") ? Make.Mk3 :
                source.Contains("mk4") ? Make.Mk4 : (Make?)null;
            return output;
        }

        public static AssetType? GetAssetType(string code)
        {
            if (string.IsNullOrWhiteSpace(code))
            {
                throw new ArgumentNullException(nameof(code));
            }
            var source = code
                .ToLower();
            var output =
                source.Contains("modpart_") ? AssetType.ModPart :
                source.Contains("mod_") ? AssetType.Mod :
                source.Contains("engine_") ? AssetType.Engine :
                source.Contains("inventory_") ? AssetType.Inventory :
                source.Contains("missile_") ? AssetType.Missile :
                source.Contains("module_") ? AssetType.Module :
                source.Contains("shield_") ? AssetType.Shield :
                source.Contains("ship_") ? AssetType.Ship :
                source.Contains("thruster_") ? AssetType.Thruster :
                source.Contains("turret_") ? AssetType.Turret :
                source.Contains("weapon_") ? AssetType.Weapon : (AssetType?)null;
            return output;
        }

        public static GunType? GetGunType(string code)
        {
            if (string.IsNullOrWhiteSpace(code))
            {
                throw new ArgumentNullException(nameof(code));
            }
            var source = code
                .ToLower();
            var output =
                source.Contains("_beam_") ? GunType.Beam :
                source.Contains("_burst_") ? GunType.Burst :
                source.Contains("_cannon_") ? GunType.Cannon :
                source.Contains("_charge_") ? GunType.Charge :
                source.Contains("_destroyer_") ? GunType.Destroyer :
                source.Contains("_dumbfire_") ? GunType.Dumbfire :
                source.Contains("_flak_") ? GunType.Flak :
                source.Contains("_gatling_") ? GunType.Gatling :
                source.Contains("_guided_") ? GunType.Guided :
                source.Contains("_ion_") ? GunType.Ion :
                source.Contains("_laser_") ? GunType.Laser :
                source.Contains("_mine_") ? GunType.Mine :
                source.Contains("_mining_") ? GunType.Mining :
                source.Contains("_plasma_") ? GunType.Plasma :
                source.Contains("_railgun_") ? GunType.Railgun :
                source.Contains("_shotgun_") ? GunType.Shotgun :
                source.Contains("_sticky_") ? GunType.Sticky :
                source.Contains("_torpedo_") ? GunType.Torpedo : (GunType?)null;
            return output;
        }

        public static ThrusterType? GetThrusterType(string code)
        {
            if (string.IsNullOrWhiteSpace(code))
            {
                throw new ArgumentNullException(nameof(code));
            }
            var source = code
                .ToLower();
            var output =
                source.Contains("allround") ? ThrusterType.AllRound :
                source.Contains("combat") ? ThrusterType.Combat : (ThrusterType?)null;
            return output;
        }

        public static EngineType? GetEngineType(string code)
        {
            if (string.IsNullOrWhiteSpace(code))
            {
                throw new ArgumentNullException(nameof(code));
            }
            var source = code
                .ToLower();
            var output =
                source.Contains("allround") ? EngineType.AllRound :
                source.Contains("combat") ? EngineType.Combat :
                source.Contains("travel") ? EngineType.Travel : (EngineType?)null;
            return output;
        }
    }
}