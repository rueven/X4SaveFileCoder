﻿using System.Linq;
using X4.Objects.Interfaces;

namespace X4.Extensions
{
    public static class StationExtensions
    {
        public static bool IsPlayerOwned(this IStation station) => station.Owner == "player";

        public static bool HasManager(this IStation station)
        {
            var output = false;
            station.Manager(x => output = true);
            return output;
        }

        public static bool HasInventoryTrader(this IStation station)
        {
            var output = false;
            station.InventoryTraders(x => output = true);
            return output;
        }

        public static bool HasShipTrader(this IStation station)
        {
            var output = false;
            station.ShipTrader(x => output = true);
            return output;
        }

        public static bool HasDefensiveClaim(this IStation station) => station
            .GetListOfStationModules()
            .Any(x => x.Contains("_claim_"));

        public static bool IsPlayerHeadQuarters(this IStation station) => station
            .GetListOfStationModules()
            .Any(x => x == "landmarks_player_hq_01_research_macro");

        public static bool HasProductionModules(this IStation station) => station
            .GetListOfStationModules()
            .Any(x => x.StartsWith("prod_"));

        public static bool HasBuildModules(this IStation station) => station
            .GetListOfStationModules()
            .Any(x => x.StartsWith("buildmod_"));

        public static bool HasConstructionDock(this IStation station) => station
            .GetListOfStationModules()
            .Any(x => x.StartsWith("_ships_"));

        public static bool HasEquipmentDock(this IStation station) => station
            .GetListOfStationModules()
            .Any(x => x.Contains("_equip_"));
    }
}
