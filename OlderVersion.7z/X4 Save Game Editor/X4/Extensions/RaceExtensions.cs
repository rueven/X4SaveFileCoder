﻿using X4.Constants;

namespace X4.Extensions
{
    public static class RaceExtensions
    {
        public static bool IsGenericRace(this Race race) => race == Race.Generic;
        public static bool IsPlayableRace(this Race race) => race == Race.Argon || race == Race.Paranid || race == Race.Split || race == Race.Teladi;
    }
}
