﻿using System.Collections.Generic;
using System.Text;
using X4.Constants;
using X4.Models.Implementations;
using X4.Models.Interfaces;
using X4.Objects.Interfaces;

namespace X4.Extensions
{
    public static class CharacterExtensions
    {
        public static IPilot TrainPilotForRole(this IPilot pilot, CharacterTraitValue value = CharacterTraitValue.Elite) => pilot
            .SetTraitValue(CharacterTrait.Piloting, value)
            .SetTraitValue(CharacterTrait.Morale, value);

        public static T TrainCharacter<T>(this ICharacter<T> character, CharacterTraitValue value = CharacterTraitValue.Elite)
            where T : class, ICharacter<T> => character
            .SetTraitValue(CharacterTrait.Boarding, value)
            .SetTraitValue(CharacterTrait.Engineering, value)
            .SetTraitValue(CharacterTrait.Management, value)
            .SetTraitValue(CharacterTrait.Morale, value)
            .SetTraitValue(CharacterTrait.Piloting, value);

        public static string AsCharacterBluePrintList(this IReadOnlyList<ICharacter> passengers)
        {
            var output = new StringBuilder();
            foreach (var passenger in passengers)
            {
                output
                    .Append("{ ")
                    .Append(passenger.Seed)
                    .Append(", \"")
                    .Append(passenger.Model)
                    .AppendLine("\" },");
            }
            return output
                .ToString();
        }

        public static IReadOnlyCharacterBluePrint AsCharacterBluePrint(this ICharacter character)
        {
            return new CharacterBluePrint()
            {
                Model = character.Model,
                Seed = character.Seed
            };
        }

        public static IPassenger TrainPassengerForRole(this IPassenger passenger, CharacterTraitValue value = CharacterTraitValue.Elite)
        {
            switch (passenger.Type)
            {
                case CharacterType.Marine:
                    return passenger
                        .SetTraitValue(CharacterTrait.Boarding, value)
                        .SetTraitValue(CharacterTrait.Morale, value);
                case CharacterType.Pilot:
                    return passenger
                        .SetTraitValue(CharacterTrait.Piloting, value)
                        .SetTraitValue(CharacterTrait.Morale, value);
                case CharacterType.Service:
                    return passenger
                        .SetTraitValue(CharacterTrait.Engineering, value)
                        .SetTraitValue(CharacterTrait.Morale, value);
                default:
                    return passenger;
            }
        }

        public static bool IsMatch(this ICharacter a, ICharacter b) => a.Model == b.Model && a.Seed == b.Seed;
    }
}