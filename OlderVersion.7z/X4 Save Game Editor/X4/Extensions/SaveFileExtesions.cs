﻿using System;
using System.Collections.Generic;
using System.Linq;
using X4.Constants;
using X4.Models.Implementations;
using X4.Models.Interfaces;
using X4.Objects.Interfaces;

namespace X4.Extensions
{
    public static class SaveFileExtesions
    {
        public static ISaveFile RenameShips(this ISaveFile file, List<ShipRenameDirective> shipRenameDirectives, Action<IShip> method)
        {
            foreach (var renamer in shipRenameDirectives)
            {
                file.FindShipByCode(renamer.Old, ship =>
                {
                    ship.SetCode(renamer.New);
                    method(ship);
                });
            }
            return file;
        }

        public static ISaveFile FindShipsByCode(this ISaveFile file, Action<IShip> method, params string[] codes)
        {
            foreach (var code in codes)
            {
                file.FindShipByCode(code, method);
            }
            return file;
        }

        public static ISaveFile TrainAllEmployees(this ISaveFile file, CharacterTraitValue value = CharacterTraitValue.Elite) => file
            .ForEachPlayerShip(ship => ship.TrainAllEmployees(value));

        public static IReadOnlyList<IReadOnlyCharacterBluePrint> ExtractAllPlayerCharacters(this ISaveFile file, params CharacterType[] characterTypes)
        {
            var output = new List<IReadOnlyCharacterBluePrint>();
            file.ForEachPlayerCharacter((type, character) =>
            {
                if (characterTypes.Contains(type))
                {
                    output.Add(new CharacterBluePrint()
                    {
                        Model = character.Model,
                        Seed = character.Seed
                    });
                }
            });
            return output;
        }
    }
}
