﻿using System;
using System.Xml;
using X4.Objects.Interfaces;

namespace X4.Extensions
{
    public static class ComponentExtensions
    {
        public static IComponent<T> WithXmlNode<T>(this IComponent<T> item, Action<XmlNode> action)
            where T : class
        {
            var node = item
                .GetType()
                .GetProperty("Node")
                ?.GetValue(item) as XmlNode;
            if (node != null)
            {
                action(node);
            }
            return item;
        }
    }
}
