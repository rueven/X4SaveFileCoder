﻿using X4.Constants;
using X4.Objects.Interfaces;

namespace X4.Extensions
{
    public static class ShipPresetExtensions
    {
        public static IShip PresetQuasarIonAndDisintegrator(this IShip ship) => ship
            .WithEngineType(BluePrints.Engines.Split.Small.Combat.Mk4 + "_macro")
            .WithEngineModification(1.5, 3)
            .WithStreamlinedHullChassisModification()
            .WithShieldsModification(10, .2, 3)
            .WithWeaponTypeInSlot(1, weapon: BluePrints.Weapons.Argon.Small.Ion.Mk2 + "_macro")
            .WithWeaponModificationInSlot(1, 2, rotationSpeed: 2)
            .WithWeaponTypeInSlot(6, weapon: BluePrints.Weapons.Split.Small.Thermal.Mk2 + "_macro")
            .WithWeaponModificationInSlot(6, 4, speed: 3, rotationSpeed: 2)
            .WithWeaponTypeInSlot(5, weapon: BluePrints.Weapons.Split.Small.Thermal.Mk2 + "_macro")
            .WithWeaponModificationInSlot(5, 4, speed: 3, rotationSpeed: 2)
            .WithWeaponTypeInSlot(2, weapon: BluePrints.Weapons.Argon.Small.Ion.Mk2 + "_macro")
            .WithWeaponModificationInSlot(2, 2, rotationSpeed: 2);

        public static IShip PresetImprovedQuasarIonAndDisintegrator(this IShip ship) => ship
            .WithThrusterType(BluePrints.Thrusters.Small.Combat.Mk3 + "_macro")
            .WithShieldType(BluePrints.Shields.Split.Small.Mk3 + "_macro")
            .WithShieldsModification(4, .2, 3)
            .WithEngineType(BluePrints.Engines.Split.Small.Combat.Mk4 + "_macro")
            .WithEngineModification(1, 3, 1, 2, 1, 1, 1, 1)
            .WithStreamlinedHullChassisModification()
            .WithSmallModdedThermalInSlot(1)
            .WithSmallModdedThermalInSlot(2)
            .WithSmallModdedThermalInSlot(3)
            .WithSmallModdedThermalInSlot(4)
            .WithSmallModdedIonInSlot(5)
            .WithSmallModdedIonInSlot(6);

        private static IShip WithSmallModdedThermalInSlot(this IShip ship, int slot) => ship
            .WithWeaponTypeInSlot(slot, weapon: BluePrints.Weapons.Split.Small.Thermal.Mk2 + "_macro")
            .WithWeaponModificationInSlot(slot, 2, speed: 3, rotationSpeed: 2);

        private static IShip WithSmallModdedIonInSlot(this IShip ship, int slot) => ship
            .WithWeaponTypeInSlot(slot, weapon: BluePrints.Weapons.Argon.Small.Ion.Mk2 + "_macro")
            .WithWeaponModificationInSlot(slot, 2, rotationSpeed: 2);

        public static IShip PresetBalaur(this IShip ship) => ship
            .WithShieldType(BluePrints.Shields.Terran.Small.Mk3 + "_macro")
            .WithEngineType(BluePrints.Engines.Split.Small.Combat.Mk4 + "_macro")
            .WithShieldsModification()
            .WithStreamlinedHullChassisModification()
            .WithEngineRotationModification(1.3, 1.5, 1.5)
            .WithWeaponModifications()
            .WithWeaponsType(BluePrints.Weapons.Split.Small.Nuetron.Mk2 + "_macro")
            // Outer guns
            .WithWeaponTypeInSlot(1, BluePrints.Weapons.Generic.Small.Cannon.Mk2 + "_macro")
            .WithWeaponTypeInSlot(2, BluePrints.Weapons.Generic.Small.Cannon.Mk2 + "_macro");

        public static IShip PresetPulsar(this IShip ship) => ship
            .WithStreamlinedHullChassisModification()
            .WithShieldType(BluePrints.Shields.Argon.Small.Mk3 + "_macro")
            .WithShieldsModification(10, .2, 3)
            .WithEngineType(BluePrints.Engines.Split.Small.Combat.Mk4 + "_macro")
            .WithEngineModification(1.5, 3)
            .WithWeaponModifications()
            .PresetPulsarWeaponSlots
            (
                BluePrints.Weapons.Split.Small.Thermal.Mk2 + "_macro",
                BluePrints.Weapons.Argon.Small.Ion.Mk2 + "_macro",
                BluePrints.Weapons.Generic.Small.Torpedo.Mk2 + "_macro"
            );

        public static IShip PresetPulsarWeaponSlots(this IShip ship, string bottomWeapon, string topWeapon, string innerWeapon) => ship
            .WithWeaponTypeInSlot(1, topWeapon)
            .WithWeaponTypeInSlot(2, topWeapon)
            .WithWeaponTypeInSlot(3, bottomWeapon)
            .WithWeaponTypeInSlot(4, bottomWeapon)
            .WithWeaponTypeInSlot(5, innerWeapon)
            .WithWeaponTypeInSlot(6, innerWeapon);
    }
}
