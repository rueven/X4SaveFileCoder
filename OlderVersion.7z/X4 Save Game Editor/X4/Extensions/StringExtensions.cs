﻿namespace X4.Extensions
{
    public static class StringExtensions
    {
        public static string AsMacro(this string value) => value.EndsWith("_macro") ? value : value + "_macro";
    }
}
