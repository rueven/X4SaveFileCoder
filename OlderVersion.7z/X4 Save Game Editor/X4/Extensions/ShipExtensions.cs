﻿using System.CodeDom;
using System.Text;
using X4.Constants;
using X4.Objects.Interfaces;

namespace X4.Extensions
{
    public static class ShipExtensions
    {
        public static bool IsVigorSyndicateFighter(this IShip ship) =>
            ship.Model == Ships.Pirate.Small.Skyte
            || ship.Model == Ships.Pirate.Small.WitherbornVanguard
            || ship.Model == Ships.Pirate.Small.Witherborn;

        public static bool IsModelPartialMatch(this IShip ship, params string[] models)
        {
            foreach (var model in models)
            {
                if (ship.Model.Contains(model))
                {
                    return true;
                }
            }
            return false;
        }

        public static bool IsYacht(this IShip ship) => ship.Model == "ship_gen_m_yacht_01_a_macro";
        public static bool IsPlayerOwned(this IShip ship) => ship.Owner == "player";
        public static bool IsBattleship(this IShip ship) => ship.Model.Contains("battleship");
        public static bool IsCarrier(this IShip ship) => ship.Model.Contains("carrier");
        public static bool IsAuxillery(this IShip ship) => ship.Model.Contains("resupplier");
        public static bool IsDestroyer(this IShip ship) => ship.Model.Contains("destroyer");
        public static bool IsFrigate(this IShip ship) => ship.Model.Contains("frigate");
        public static bool IsCorvette(this IShip ship) => ship.Model.Contains("corvette");
        public static bool IsFighter(this IShip ship) => ship.Model.Contains("fighter");
        public static bool IsScout(this IShip ship) => ship.Model.Contains("scout");
        public static bool IsBuilder(this IShip ship) => ship.Model.Contains("builder");
        public static bool IsTug(this IShip ship) => ship.Model.Contains("tugboat");
        public static bool IsScrapper(this IShip ship) => ship.Model.Contains("scrapper"); //ship_pir_l_scrapper_01_macro
        public static bool IsDrone(this IShip ship) => ship.Model.Contains("drone");
        public static bool IsFighterDrone(this IShip ship) => ship.Model.Contains("fightingdrone");
        public static bool IsWarship(this IShip ship) => ship.IsBattleship() || ship.IsCarrier() || ship.IsAuxillery() || ship.IsDestroyer() || ship.IsFrigate() || ship.IsCorvette() || ship.IsScout() || ship.IsFighter() || ship.IsBomber();
        public static bool IsTradeship(this IShip ship) => ship.Model.Contains("container");
        public static bool IsBomber(this IShip ship) => ship.Model.Contains("bomber");
        public static bool IsResourceShip(this IShip ship) => ship.Model.Contains("miner");
        public static bool IsOreShip(this IShip ship) => ship.IsResourceShip() && ship.Model.Contains("solid");
        public static bool IsGasShip(this IShip ship) => ship.IsResourceShip() && ship.Model.Contains("liquid");
        public static bool IsEconomyShip(this IShip ship) => ship.IsResourceShip() || ship.IsTradeship();

        public static string ExtractNpcBluePrintsFromShip(this IShip ship, CharacterType type, bool pullPilot = false)
        {
            var output = new StringBuilder();
            if (pullPilot)
            {
                ship.Pilot(pilot =>
                {
                    output
                        .Append("captain: { ")
                        .Append(pilot.Seed)
                        .Append(", \"")
                        .Append(pilot.Model)
                        .AppendLine("\" }");
                });
            }
            ship.ForEachPassenger(passenger =>
            {
                if (passenger.Type == type)
                {
                    output
                        .Append("{ ")
                        .Append(passenger.Seed)
                        .Append(", \"")
                        .Append(passenger.Model)
                        .AppendLine("\" }");
                }
            });
            return output
                .ToString();
        }

        public static IShip TrainAllEmployees(this IShip ship, CharacterTraitValue value = CharacterTraitValue.Elite) => ship
            .Pilot(pilot => pilot.TrainCharacter(value))
            .ForEachPassenger(passenger => passenger.TrainCharacter(value));
    }
}