﻿using System;
using System.Collections.Generic;
using System.Xml;

namespace X4.Extensions
{
    public static class XmlNodeExtensions
    {
        public static IEnumerable<T> Select<T>(this XmlNodeList list, Func<XmlNode, T> selector)
        {
            var output = new List<T>();
            foreach (XmlNode node in list)
            {
                output.Add(selector(node));
            }
            return output;
        }
    }
}
