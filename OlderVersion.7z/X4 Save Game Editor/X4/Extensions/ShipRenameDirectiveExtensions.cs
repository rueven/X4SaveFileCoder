﻿using System.Collections.Generic;
using X4.Models.Implementations;

namespace X4.Extensions
{
    public static class ShipRenameDirectiveExtensions
    {
        public static List<ShipRenameDirective> Add(this List<ShipRenameDirective> target, string oldValue, string newValue)
        {
            target.Add(new ShipRenameDirective()
            {
                Old = oldValue,
                New = newValue
            });
            return target;
        }
    }
}