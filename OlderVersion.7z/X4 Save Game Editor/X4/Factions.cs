﻿namespace X4
{
    public static class Factions
    {
        public const string Argon = "argon";
        public const string Antigone = "antigone";
    }
}
