﻿using X4.Objects.Interfaces;

namespace X4.Models.Interfaces
{
    public interface IReadOnlyCharacterBluePrint : ICharacter
    {
    }
}
