﻿namespace X4.Models.Implementations
{
    public class ShipRenameDirective
    {
        public string Old { get; set; }
        public string New { get; set; }
    }
}