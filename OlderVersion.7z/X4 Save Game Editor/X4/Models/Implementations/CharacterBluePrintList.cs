﻿using System.Collections.Generic;
using X4.Models.Interfaces;

namespace X4.Models.Implementations
{
    public class CharacterBluePrintList : List<IReadOnlyCharacterBluePrint>
    {
        public void Add(long seed, string model)
        {
            this.Add(new CharacterBluePrint()
            {
                Seed = seed,
                Model = model
            });
        }
    }
}
