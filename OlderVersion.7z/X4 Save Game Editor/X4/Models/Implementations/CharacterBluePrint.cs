﻿using X4.Models.Interfaces;

namespace X4.Models.Implementations
{
    public class CharacterBluePrint
        : IReadOnlyCharacterBluePrint
    {
        public long Seed { get; set; }
        public string Model { get; set; }
    }
}
