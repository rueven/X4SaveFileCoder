﻿namespace Power.Types
{
    public interface IFetchByIdDataService<TItem, TPrimaryKey> : IBasicDataService<TItem, TPrimaryKey>
        where TPrimaryKey : struct
    {
        TItem FetchById(TPrimaryKey value);
    }
}
