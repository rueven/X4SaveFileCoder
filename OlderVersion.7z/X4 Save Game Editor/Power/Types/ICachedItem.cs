﻿using System;

namespace Power.Types
{
    public interface ICachedItem
    {
        TimeSpan TimeSinceLastAccessed(DateTime value);
        bool IsExpired(DateTime value);
        object GetValue();
        void SetValue(object value);
        void ResetExpiration(Action<TimeSpan> handler);
    }
}
