﻿using System;

namespace Power.Types
{
    public interface ICacheService : ISimpleCacheService
    {
        /// <summary>
        /// Stores value in cache under provided key
        /// </summary>
        /// <typeparam name="T">The type of value being persisted</typeparam>
        /// <param name="key">The key that the value is stored under</param>
        /// <param name="value">The value filed under the key in the cache</param>
        /// <param name="expiration">The time at which the inserted object expires and is removed from the cache. 
        /// To avoid possible issues with local time such as changes from standard time to daylight time, use UtcNow rather 
        /// than Now for this parameter value.</param>
        void SetValue<T>(string key, T value, DateTime expiration);

        /// <summary>
        /// Stores value in cache under provided key
        /// </summary>
        /// <typeparam name="T">The type of value being persisted</typeparam>
        /// <param name="key">The key that the value is stored under</param>
        /// <param name="value">The value filed under the key in the cache</param>
        /// <param name="expiration">The interval between the time the inserted object was last accessed and the 
        /// time at which that object expires. If this value is the equivalent of 20 minutes, the object will expire and be 
        /// removed from the cache 20 minutes after it was last accessed.</param>
        void SetValue<T>(string key, T value, TimeSpan expiration);
    }
}
