﻿using System;

namespace Power.Types
{
    public abstract class CacheServiceBase
    {
        protected abstract ICachedItem GetRawValue(string key);
        protected abstract void SetRawValue(string key, DecoratedCacheItem value);
        protected abstract void SetRawValue(string key, SlidingExpirationCacheItem value);
        protected abstract void SetRawValue(string key, AbsoluateExpirationCacheItem value);
        protected abstract void RemoveRawValue(string key);
        protected abstract bool ContainsRawValue(string key);

        public T GetValue<T>(string key)
        {
            var timestamp = DateTime.Now;
            var output = this.GetRawValue(key);
            if (output == null) { return default(T); }
            if (output.IsExpired(timestamp))
            {
                this.RemoveRawValue(key);
                return default(T);
            }
            return (T)output.GetValue();
        }

        public void SetValue<T>(string key, T value)
        {
            var timestamp = DateTime.Now;
            var output = this.GetRawValue(key);
            if (output == null || output.IsExpired(timestamp))
            {
                this.SetRawValue(key, new DecoratedCacheItem(key, value));
                return;
            }
            output.SetValue(value);
        }

        public void SetValue<T>(string key, T value, DateTime expiration)
        {
            var timestamp = DateTime.Now;
            var output = this.GetRawValue(key);
            if (output == null || output.IsExpired(timestamp))
            {
                this.SetRawValue(key, new AbsoluateExpirationCacheItem(key, value, expiration));
                return;
            }
            output.SetValue(value);
        }

        public void SetValue<T>(string key, T value, TimeSpan expiration)
        {
            var timestamp = DateTime.Now;
            var output = this.GetRawValue(key);
            if (output == null || output.IsExpired(timestamp))
            {
                this.SetRawValue(key, new SlidingExpirationCacheItem(key, value, expiration));
                return;
            }
            output.SetValue(value);
        }

        public void RemoveValue<T>(string key)
        {
            this.RemoveRawValue(key);
        }

        public bool ContainsValue<T>(string key)
        {
            var timestamp = DateTime.Now;
            var output = this.GetRawValue(key);
            if (output == null)
            {
                //Is it null on purpose?
                return this.ContainsRawValue(key);
            }
            return !output.IsExpired(timestamp);
        }
    }
}
