﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Power.Types
{
    internal class FtpDirectory : IFtpDirectory
    {
        public FtpDirectory(string uri, string username, string password)
            : this(uri)
        {
            this.Username = username;
            this.Password = password;
        }
        public FtpDirectory(string uri)
        {
            this.Uri = new System.Uri(uri);
        }

        public Uri Uri { get; private set; }
        public string Username { get; private set; }
        public string Password { get; private set; }
        public bool UsePassive { get; private set; }
        public bool KeepAlive { get; private set; }
        public bool HasCredentials { get { return string.IsNullOrEmpty(this.Username).Equals(false) || string.IsNullOrEmpty(this.Password).Equals(false); } }

        private static System.Text.RegularExpressions.Regex DefaultRegex = new System.Text.RegularExpressions.Regex
        (
            @"^(?<dir>[\-ld])(?<permission>[\-rwx]{9})\s+(?<filecode>\d+)\s+(?<owner>\w+)\s+(?<group>\w+)\s+(?<size>\d+)\s+(?<month>\w{3})\s+(?<day>\d{1,2})\s+(?<timeyear>[\d:]{4,5})\s+(?<filename>(.*))$",
             System.Text.RegularExpressions.RegexOptions.Compiled
        );

        public static bool DefaultParser(string rawline, FtpFile hydrationtarget)
        {
            var result = FtpDirectory.DefaultRegex.Match(rawline);
            if (result.Success.Equals(false)) { return false; }
            hydrationtarget.Filename = result.Groups["filename"].Value;
            hydrationtarget.Size = Convert.ToInt32(result.Groups["size"].Value);
            var month = DateTime.ParseExact(result.Groups["month"].Value, "MMM", System.Globalization.CultureInfo.CurrentCulture).Month;
            var day = Convert.ToInt32(result.Groups["day"].Value);
            var year = result.Groups["timeyear"].Value.Contains(":") ? (int?)null : Convert.ToInt32(result.Groups["timeyear"].Value);
            if (year.HasValue)
            {
                hydrationtarget.Timestamp = new DateTime(year.Value, month, day);
                return true;
            }
            var parts = result.Groups["timeyear"].Value.Split(new string[] { ":" }, StringSplitOptions.RemoveEmptyEntries);
            if (parts.Count() == 2)
            {
                var hour = Convert.ToInt32(parts[0]);
                var minute = Convert.ToInt32(parts[1]);
                hydrationtarget.Timestamp = new DateTime(DateTime.Today.Year, month, day, hour, minute, 0);
                return true;
            }
            hydrationtarget.Timestamp = new DateTime(DateTime.Today.Year, month, day);
            return true;
        }
    }
}
