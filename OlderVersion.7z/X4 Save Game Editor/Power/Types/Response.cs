﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Power.Types
{
    public class Response
    {
        public static Response CreateSuccess()
        {
            return new Response()
            {
                Exception = null,
                Success = true,
                Message = "Success"
            };
        }

        public static Response CreateFail(Exception e)
        {
            return Response.CreateFail(e.Message, e);
        }

        public static Response CreateFail(string message, Exception e = null)
        {
            return new Response()
            {
                Exception = e,
                Success = false,
                Message = message
            };
        }

        public Exception Exception { get; set; }
        public bool Success { get; set; }
        public string Message { get; set; }
    }

    public class Response<T> : Response
    {
        public static Response<T> CreateSuccess(T body)
        {
            return new Response<T>()
            {
                Body = body,
                Exception = null,
                Message = "Success",
                Success = true
            };
        }

        public static Response<T> CreateFail(T body, string message)
        {
            return new Response<T>()
            {
                Exception = null,
                Message = message,
                Success = false,
                Body = body
            };
        }

        public static new Response<T> CreateFail(Exception e)
        {
            return new Response<T>()
            {
                Exception = e,
                Message = e.Message,
                Success = false
            };
        }

        public T Body { get; set; }
    }
}
