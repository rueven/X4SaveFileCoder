﻿namespace Power.Types
{
    public interface ISimpleCacheService
    {
        /// <summary>
        /// Retrieves value from cache based on key
        /// </summary>
        /// <typeparam name="T">The type of value being retrieved</typeparam>
        /// <param name="key">The key that the value is stored under</param>
        /// <returns>The value filed under the key in the cache</returns>
        T GetValue<T>(string key);

        /// <summary>
        /// Stores value in cache under provided key
        /// </summary>
        /// <typeparam name="T">The type of value being persisted</typeparam>
        /// <param name="key">The key that the value is stored under</param>
        /// <param name="value">The value filed under the key in the cache</param>
        void SetValue<T>(string key, T value);

        /// <summary>
        /// Permanently deletes item from cache
        /// </summary>
        /// <param name="key">The key that the value is stored under</param>
        void RemoveValue<T>(string key);

        /// <summary>
        /// Checks to see if item exists within cache
        /// </summary>
        /// <param name="key">The key that the value is stored under</param>
        /// <returns>Whether or not the key is contained within the cache</returns>
        bool ContainsValue<T>(string key);

        /// <summary>
        /// Clears the cache of all values
        /// </summary>
        void Clear();
    }
}
