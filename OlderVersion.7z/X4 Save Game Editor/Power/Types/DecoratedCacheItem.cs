﻿using System;

namespace Power.Types
{
    [Serializable]
    public class DecoratedCacheItem : ICachedItem
    {
        public DecoratedCacheItem(string key, object value)
        {
            this.Key = key;
            this.Value = value;
            this.LastAccessed = DateTime.Now;
        }

        public string Key { get; private set; }
        public DateTime LastAccessed { get; private set; }
        private object Value { get; set; }

        public virtual bool IsExpired(DateTime value)
        {
            return false;
        }

        public object GetValue()
        {
            if (this.IsExpired(DateTime.Now)) { return null; }
            this.LastAccessed = DateTime.Now;
            return this.Value;
        }

        public void SetValue(object value)
        {
            this.LastAccessed = DateTime.Now;
            this.Value = value;
        }

        public TimeSpan TimeSinceLastAccessed(DateTime value)
        {
            return value.Subtract(this.LastAccessed);
        }

        public virtual void ResetExpiration(Action<TimeSpan> handler) { }
    }
}
