﻿using System.Collections.Generic;

namespace Power.Types
{
    public interface IFetchAllDataService<TItem, TPrimaryKey> : IBasicDataService<TItem, TPrimaryKey>
        where TPrimaryKey : struct
    {
        IReadOnlyList<TItem> FetchAll();
    }
}
