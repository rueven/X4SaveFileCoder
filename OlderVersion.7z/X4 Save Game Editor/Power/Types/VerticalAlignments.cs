﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Power.Types
{
    internal enum VerticalAlignments
    {
        Top,
        Middle,
        Bottom,
        Fill
    }
}
