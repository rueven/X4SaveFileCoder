﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Text.RegularExpressions;
using Power.Utilities;

namespace Power.Types
{
    internal class ParsedPhone : IParsedPhone
    {
        private const string Pattern = @"[\(]?(?<AreaCode>\d{3})?[\)]?[\s+]?[-\.]?[\s+]?(?<NumberPrefix>\d{3})[\s+]?[-\.]?[\s+]?(?<NumberSuffix>\d{4})[\s+]?(extension|ext|x)?[\.]?[:]?[\s+]?(?<Extension>\d+)?";
        private static readonly Regex PhoneNumberParser = new Regex(ParsedPhone.Pattern, RegexOptions.IgnoreCase | RegexOptions.Compiled);

        public static ParsedPhone Parse(string value)
        {
            if (string.IsNullOrEmpty(value)) { return null; }
            var match = ParsedPhone.PhoneNumberParser.Match(value);
            if (match.Success)
            {
                return new ParsedPhone()
                {
                    AreaCode = match.Groups["AreaCode"].WithSelect(x => x.Success ? x.Value : null),
                    Extension = match.Groups["Extension"].WithSelect(x => x.Success ? x.Value : null),
                    Prefix = match.Groups["NumberPrefix"].WithSelect(x => x.Success ? x.Value : null),
                    Suffix = match.Groups["NumberSuffix"].WithSelect(x => x.Success ? x.Value : null)
                };
            }
            return null;
        }

        public string AreaCode { get; set; }
        public string Extension { get; set; }
        public string Prefix { get; set; }
        public string Suffix { get; set; }
        public string Number
        {
            get
            {
                if (string.IsNullOrEmpty(this.Prefix) || string.IsNullOrEmpty(this.Suffix)) { return null; }
                return this.Prefix + "-" + this.Suffix;
            }
        }
    }
}
