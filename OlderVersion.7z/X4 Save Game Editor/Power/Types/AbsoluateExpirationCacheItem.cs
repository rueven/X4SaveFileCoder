﻿using System;

namespace Power.Types
{
    [Serializable]
    public class AbsoluateExpirationCacheItem : DecoratedCacheItem
    {
        public AbsoluateExpirationCacheItem(string key, object value, DateTime expires)
            : base(key, value)
        {
            this.Expires = expires;
        }

        public DateTime Expires { get; private set; }

        public override bool IsExpired(DateTime value)
        {
            return value >= this.Expires;
        }
    }
}
