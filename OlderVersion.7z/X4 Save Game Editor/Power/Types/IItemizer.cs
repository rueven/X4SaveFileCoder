﻿using System;
using System.Collections.Generic;

namespace Power.Types
{
    public interface IItemizer<T>
    {
        IItemizer<T> Add(string name, Func<T, object> reader);

        IItemizer<T> ForEachSubItem<TItem>(Func<T, IEnumerable<TItem>> selector, Func<TItem, string> getname, Func<TItem, object> getvalue);

        List<ItemizerItem> Execute();
    }
}
