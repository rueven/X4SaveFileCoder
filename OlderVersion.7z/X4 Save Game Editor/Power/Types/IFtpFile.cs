﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Power.Types
{
    public interface IFtpFile
    {
        Uri Directory { get; set; }
        string Filename { get; set; }
        long Size { get; set; }
        DateTime? Timestamp { get; set; }
    }
}
