﻿namespace Power.Types
{
    public interface IBasicDataService<TItem, TPrimaryKey>
        where TPrimaryKey : struct
    {
        bool HasValidPrimaryKey(TItem value);
        TPrimaryKey GetPrimaryKeyValue(TItem value);
        TPrimaryKey? ConvertToPrimaryKey(string value);
    }
}
