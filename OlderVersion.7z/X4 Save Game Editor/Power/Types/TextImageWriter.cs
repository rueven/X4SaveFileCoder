﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Image = System.Drawing.Image;

namespace Power.Types
{
    internal class TextImageWriter : IDisposable
    {
        public int Padding { get; set; }
        public System.Drawing.Pen TextOutlinePen { get; set; }
        public System.Drawing.Pen TextPen { get; set; }
        public System.Drawing.Font Font { get; set; }
        public VerticalAlignments VerticalAlignment { get; set; }
        public HorizontalAlignments HorizontalAlignment { get; set; }

        public Image WriteTextOnImage(Image image, string text, bool outline)
        {
            if (outline)
            {
                using (var path = new System.Drawing.Drawing2D.GraphicsPath())
                {
                    using (var graphic = System.Drawing.Graphics.FromImage(image))
                    {
                        graphic.TextRenderingHint = System.Drawing.Text.TextRenderingHint.AntiAlias;
                        graphic.SmoothingMode = System.Drawing.Drawing2D.SmoothingMode.AntiAlias;
                        graphic.PageUnit = System.Drawing.GraphicsUnit.Pixel;
                        if (this.HorizontalAlignment == HorizontalAlignments.Center)
                        {
                            using (var format = new System.Drawing.StringFormat() { Alignment = System.Drawing.StringAlignment.Center })
                            {
                                path.AddString
                                (
                                    text,
                                    this.Font.FontFamily,
                                    0,
                                    this.Font.Size,
                                    this.GetStartingLocation(graphic, graphic.MeasureString(text, this.Font)),
                                    this.HorizontalAlignment == HorizontalAlignments.Center ? format : System.Drawing.StringFormat.GenericTypographic
                                );
                            }
                        }
                        graphic.FillPath(this.TextPen.Brush, path);
                    }
                }
            }
            return image;
        }

        private System.Drawing.Point GetStartingLocation(System.Drawing.Graphics Graphic, System.Drawing.SizeF ObjectToCenter)
        {
            var x = 0;
            var y = 0;
            switch (this.HorizontalAlignment)
            {
                case HorizontalAlignments.Right:
                    x = (int)(Graphic.VisibleClipBounds.Width - (ObjectToCenter.Width + this.Padding));
                    break;
                case HorizontalAlignments.Center:
                    x = (int)(Graphic.VisibleClipBounds.Width / 2);
                    break;
                case HorizontalAlignments.Left:
                default:
                    x = 0 + this.Padding;
                    break;
            }
            switch (this.VerticalAlignment)
            {
                case VerticalAlignments.Middle:
                    y = (int)((Graphic.VisibleClipBounds.Height / 2) - (this.Font.Height / 2));
                    break;
                case VerticalAlignments.Bottom:
                    y = (int)(Graphic.VisibleClipBounds.Height - (this.Font.Height + this.Padding));
                    break;
                case VerticalAlignments.Top:
                case VerticalAlignments.Fill:
                default:
                    y = 0 + this.Padding;
                    break;
            }
            return new System.Drawing.Point(x, y);
        }

        public void Dispose()
        {
            if (this.TextOutlinePen != null)
            {
                this.TextOutlinePen.Dispose();
            }
            this.TextPen.Dispose();
            this.Font.Dispose();
        }
    }
}
