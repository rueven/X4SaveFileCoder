﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Power.Types
{
    internal class TryResult : TryResultBase<TryResult>, ITryResult
    {
        internal TryResult(Exception e = null) : base(e) { }

        public new ITryResult Catch<TException>(Action<TException> handler) where TException : Exception { return this.Catch(handler); }
    }

    internal class TryResult<T> : TryResultBase<TryResult<T>>, ITryResult<T>
    {
        internal TryResult(T value, Exception e = null) : base(e) { this.Value = value; }

        public T Value { get; private set; }

        public T GetValueIfSuccessful() { return this.Success ? this.Value : default(T); }

        public new ITryResult<T> Catch<TException>(Action<TException> handler) where TException : Exception { return this.Catch(handler); }
    }
}
