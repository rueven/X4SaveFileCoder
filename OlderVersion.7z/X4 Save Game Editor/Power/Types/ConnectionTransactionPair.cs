﻿using System;
using System.Data;
using System.Data.SqlClient;

namespace Power.Types
{
    public abstract class ConnectionTransactionPair<TConnection, TCommand> : IDisposable
        where TConnection : IDbConnection
        where TCommand: IDbCommand
    {
        #region Constructor
        protected ConnectionTransactionPair(string connectionString, TConnection connection)
        {
            this.ConnectionString = connectionString;
            this.Connection = connection;
        }
        #endregion

        #region Properties
        public ConnectionState State => this.Connection?.State ?? ConnectionState.Broken;
        public string ConnectionString { get; private set; }
        public TConnection Connection { get; private set; }
        public IDbTransaction Transaction { get; private set; }
        public bool HasTransaction => this.Transaction != null;
        #endregion

        #region Connnection Control
        public ConnectionTransactionPair<TConnection, TCommand> Open()
        {
            this.Connection?.Open();
            return this;
        }
        public ConnectionTransactionPair<TConnection, TCommand> Close()
        {
            this.Connection?.Close();
            return this;
        }
        #endregion

        #region Transaction Control
        public ConnectionTransactionPair<TConnection, TCommand> BeginTransactionn(IsolationLevel isolationLevel)
        {
            this.Transaction = this
                .Connection
                .BeginTransaction(isolationLevel);
            return this;
        }

        public ConnectionTransactionPair<TConnection, TCommand> Commit()
        {
            this.Transaction?.Commit();
            return this;
        }

        public ConnectionTransactionPair<TConnection, TCommand> Rollback()
        {
            this.Transaction?.Rollback();
            return this;
        }
        #endregion

        #region Command Control
        public TCommand CreateCommand(string commandText = null)
        {
            var output = this
                .Connection
                ?.CreateCommand();
            output.CommandText = commandText;
            return (TCommand)output;
        }
        #endregion

        #region IDisposable
        public void Dispose()
        {
            this.Commit();
            this.Transaction?.Dispose();
            this.Connection?.Close();
            this.Connection?.Dispose();
        }
        #endregion
    }

    public class SqlConnectionTransactionPair : ConnectionTransactionPair<SqlConnection, SqlCommand>
    {
        protected SqlConnectionTransactionPair(string connectionString, SqlConnection connection)
            : base(connectionString, connection) { }

        public static ConnectionTransactionPair<SqlConnection, SqlCommand> CreateSqlConnection(string connectionString, bool transactionEnabled = false)
        {
            return new SqlConnectionTransactionPair
            (
                connectionString,
                new SqlConnection(connectionString)
            );
        }
    }
}
