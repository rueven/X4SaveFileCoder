﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Power.Types
{
    public class LocalInProcessCacheService : CacheServiceBase, ICacheService
    {
        public LocalInProcessCacheService()
        {
            this.Items = new System.Collections.Concurrent.ConcurrentDictionary<string, ICachedItem>();
            this.CleanupTimer = new System.Threading.Timer(PerformCleanup);
            this.CleanupTimer.Change(TimeSpan.Zero, TimeSpan.FromMinutes(5));
        }

        public bool CaseSensitive { get; private set; }
        private System.Threading.Timer CleanupTimer { get; set; }
        private System.Collections.Concurrent.ConcurrentDictionary<string, ICachedItem> Items { get; set; }

        protected override ICachedItem GetRawValue(string key)
        {
            var casedkey = this.CaseSensitive ? key : key.ToLower();
            return this.Items.ContainsKey(casedkey) ? this.Items[casedkey] : null;
        }

        protected override void RemoveRawValue(string key)
        {
            var casedkey = this.CaseSensitive ? key : key.ToLower();
            var output = (ICachedItem)null;
            this.Items.TryRemove(casedkey, out output);
        }

        protected override void SetRawValue(string key, AbsoluateExpirationCacheItem value)
        {
            this.SetRawValue(key, value as ICachedItem);
        }

        protected override void SetRawValue(string key, DecoratedCacheItem value)
        {
            this.SetRawValue(key, value as ICachedItem);
        }

        protected override void SetRawValue(string key, SlidingExpirationCacheItem value)
        {
            this.SetRawValue(key, value as ICachedItem);
        }

        protected void SetRawValue(string key, ICachedItem value)
        {
            var casedkey = this.CaseSensitive ? key : key.ToLower();
            this.Items.AddOrUpdate(casedkey, value, (x, y) => value);
        }

        protected override bool ContainsRawValue(string key)
        {
            return this.Items.ContainsKey(this.CaseSensitive ? key : key.ToLower());
        }

        protected virtual void PerformCleanup(object state)
        {
            var keys = this.Items.Keys.ToList();
            foreach (var key in keys)
            {
                var item = (ICachedItem)null;
                if (this.Items.TryGetValue(key, out item))
                {
                    if (item.IsExpired(DateTime.Now))
                    {
                        this.RemoveRawValue(key);
                    }
                }
            }
        }

        public void Clear()
        {
            this.Items
                .Clear();
        }
    }
}
