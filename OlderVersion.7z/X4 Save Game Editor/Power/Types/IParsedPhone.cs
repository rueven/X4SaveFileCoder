﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Power.Types
{
    public interface IParsedPhone
    {
        string AreaCode { get; }
        string Prefix { get; }
        string Suffix { get; }
        string Extension { get; }
        string Number { get; }
    }
}
