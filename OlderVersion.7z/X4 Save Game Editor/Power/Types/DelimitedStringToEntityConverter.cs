﻿using System;
using System.Collections.Generic;
using System.IO;
using Power.Framework;
using Power.Framework.FieldDefinitionReaders;
using Power.Utilities;

namespace Power.Types
{
    class DelimitedStringToEntityConverter : IDelimitedStringToEntityConverter
    {
        #region Constructor

        public DelimitedStringToEntityConverter(string rowDelimiter = "\r\n", string columnDelimiter = ",", char escape = '"')
        {
            this.RowDelimiter = rowDelimiter;
            this.ColumnDelimiter = columnDelimiter;
            this.Escape = escape;
        }

        #endregion

        #region Properties

        public string RowDelimiter { get; private set; }
        public string ColumnDelimiter { get; private set; }
        public char Escape { get; private set; }

        #endregion

        #region Execute<T>

        public void Execute<T>(string body, Func<T> entityFactory, Action<T> handleEntity, params ElementAtFieldDefinitionReader[] fieldReaders)
            where T : IEntity
        {
            using (var reader = new StringReader(body))
            {
                this.Execute
                    (
                        reader,
                        entityFactory,
                        handleEntity,
                        fieldReaders
                    );
            }
        }

        public void Execute<T>(TextReader reader, Func<T> entityFactory, Action<T> handleEntity, params ElementAtFieldDefinitionReader[] fieldReaders)
            where T : IEntity
        {
            DelimitedStringHelper
                .Execute
                (
                    reader,
                    columnValues =>
                    {
                        if (columnValues?.Capacity == 0) { return; }
                        if (string.IsNullOrWhiteSpace(columnValues[0])) { return; }
                        var entity = entityFactory();
                        foreach (var fieldReader in fieldReaders)
                        {
                            var rawValue = fieldReader
                                .GetValue(columnValues);
                            fieldReader
                                .FieldDefinition
                                .SetCoercedValue(entity, rawValue);
                        }
                        handleEntity(entity);
                    },
                    this.RowDelimiter,
                    this.ColumnDelimiter,
                    this.Escape
                );
        }

        #endregion

        #region ReadAll<T>

        public IReadOnlyList<T> ReadAll<T>(TextReader reader, Func<T> entityFactory, params ElementAtFieldDefinitionReader[] fieldReaders)
            where T : IEntity
        {
            var output = new List<T>();
            this.Execute(reader, entityFactory, output.Add, fieldReaders);
            return output;
        }

        public IReadOnlyList<T> ReadAll<T>(string body, Func<T> entityFactory, params ElementAtFieldDefinitionReader[] fieldReaders)
            where T : IEntity
        {
            var output = new List<T>();
            this.Execute(body, entityFactory, output.Add, fieldReaders);
            return output;
        }

        #endregion
    }
}
