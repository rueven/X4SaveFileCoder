﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Power.Types
{
    internal class Itemizer<T> : IItemizer<T>
    {
        #region Constructors
        public Itemizer() { }
        public Itemizer(T value) { this.CurrentSource = value; }
        #endregion

        private T CurrentSource { get; set; }
        private List<IReader> Columns = new List<IReader>();

        public Itemizer<T> Add(string name, Func<T, object> reader)
        {
            this.Columns.Add(new SingleDataReader() { Name = name, GetValue = reader });
            return this;
        }

        public Itemizer<T> ForEach<Item>(IEnumerable<Item> items, Action<Itemizer<T>, Item> action)
        {
            if (items == null || items.Any().Equals(false)) { return this; }
            foreach (var item in items) { action(this, item); }
            return this;
        }

        #region IExtensionPropertizer<T> Members

        IItemizer<T> IItemizer<T>.ForEachSubItem<TItem>(Func<T, IEnumerable<TItem>> selector, Func<TItem, string> getname, Func<TItem, object> getvalue)
        {
            this.Columns.Add(new MultiDataReader<TItem>()
            {
                Selector = selector,
                GetName = getname,
                GetValue = getvalue
            });
            return this;
        }

        IItemizer<T> IItemizer<T>.Add(string name, Func<T, object> reader) { return this.Add(name, reader); }

        List<ItemizerItem> IItemizer<T>.Execute()
        {
            var output = this
                .Columns
                .SelectMany(x => x.Get(this.CurrentSource))
                .ToList();
            return output;
        }

        #endregion

        #region Private Types

        protected class SingleDataReader : IReader
        {
            public string Name { get; set; }
            public Func<T, object> GetValue { get; set; }
            public IEnumerable<ItemizerItem> Get(T source)
            {
                return new List<ItemizerItem>()
                {
                    new ItemizerItem(this.Name, this.GetValue(source))
                };
            }
        }

        protected class MultiDataReader<TItem> : IReader
        {
            public Func<T, IEnumerable<TItem>> Selector { get; set; }
            public Func<TItem, string> GetName { get; set; }
            public Func<TItem, object> GetValue { get; set; }
            public IEnumerable<ItemizerItem> Get(T source)
            {
                var items = this
                    .Selector(source)
                    .Select(x => new ItemizerItem(this.GetName(x), this.GetValue(x)))
                    .ToList();
                return items;
            }
        }

        protected interface IReader
        {
            IEnumerable<ItemizerItem> Get(T source);
        }

        #endregion
    }
}
