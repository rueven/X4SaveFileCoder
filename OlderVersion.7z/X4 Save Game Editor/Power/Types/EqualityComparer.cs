﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Power.Types
{
    internal class EqualityComparer<TObject> : IEqualityComparer<TObject>
    {
        public static EqualityComparer<TObject> Create(Func<TObject, TObject, bool> comparer) { return new EqualityComparer<TObject>(comparer); }
        public EqualityComparer(Func<TObject, TObject, bool> comparer) { this.Comparer = comparer; }
        private Func<TObject, TObject, bool> Comparer { get; set; }
        public bool Equals(TObject x, TObject y) { return this.Comparer(x, y); }
        public int GetHashCode(TObject value) { return value.GetHashCode(); }
    }
}
