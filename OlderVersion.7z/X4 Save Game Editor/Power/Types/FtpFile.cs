﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Power.Types
{
    internal class FtpFile : IFtpFile
    {
        public Uri Directory { get; set; }
        public string Filename { get; set; }
        public long Size { get; set; }
        public DateTime? Timestamp { get; set; }
    }
}
