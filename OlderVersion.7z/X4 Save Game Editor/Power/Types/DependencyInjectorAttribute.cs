﻿using System;

namespace Power.Types
{
    [AttributeUsage(AttributeTargets.Class | AttributeTargets.Interface, AllowMultiple = false)]
    public class DependencyInjectorAttribute : Attribute
    {
        public bool IsAutoRegistered { get; set; }
        public bool IsPropertyInjected { get; set; }

        public static DependencyInjectorAttribute Read(Type type)
        {
            var output = DependencyInjectorAttribute
                .GetCustomAttribute
                (
                    type,
                    typeof(DependencyInjectorAttribute)
                ) as DependencyInjectorAttribute;
            return output;
        }

        public static bool ShouldBeAutoRegistered(Type type)
        {
            var attribute = DependencyInjectorAttribute
                .Read(type);
            return attribute == null ? true : attribute.IsAutoRegistered;
        }

        public static bool ShouldBePropertyInjected(Type type)
        {
            var attribute = DependencyInjectorAttribute
                .Read(type);
            return attribute == null ? false : attribute.IsPropertyInjected;
        }
    }
}
