﻿using System;

namespace Power.Types
{
    public class LocalWebCacheService : ICacheService
    {
        public LocalWebCacheService()
        {
            this.Priority = System.Web.Caching.CacheItemPriority.Default;
            this.RemoveCallback = null;
        }

        public System.Web.Caching.CacheItemPriority Priority { get; set; }
        public System.Web.Caching.CacheItemRemovedCallback RemoveCallback { get; set; }
        protected System.Web.Caching.Cache Cache
        {
            get { return System.Web.HttpRuntime.Cache; }
        }

        public T GetValue<T>(string key)
        {
            if (this.ContainsValue<T>(key))
            {
                var result = this.Cache.Get(key);
                return result is NullCacheValue ? default(T) : (T)result;
            }
            return default(T);
        }

        public void SetValue<T>(string key, T value)
        {
            this.Cache.Insert
            (
                key,
                (object)value ?? new NullCacheValue(),
                null,
                System.Web.Caching.Cache.NoAbsoluteExpiration,
                System.Web.Caching.Cache.NoSlidingExpiration,
                this.Priority,
                this.RemoveCallback
            );
        }

        public void SetValue<T>(string key, T value, DateTime expiration)
        {
            this.Cache.Insert
            (
                key,
                (object)value ?? new NullCacheValue(),
                null,
                expiration,
                System.Web.Caching.Cache.NoSlidingExpiration,
                this.Priority,
                this.RemoveCallback
            );
        }

        public void SetValue<T>(string key, T value, TimeSpan expiration)
        {
            this.Cache.Insert
            (
                key,
                (object)value ?? new NullCacheValue(),
                null,
                System.Web.Caching.Cache.NoAbsoluteExpiration,
                expiration,
                this.Priority,
                this.RemoveCallback
            );
        }

        public void RemoveValue<T>(string key)
        {
            this.Cache.Remove(key);
        }

        public bool ContainsValue<T>(string key)
        {
            return this.Cache[key] != null;
        }

        public void Clear()
        {
            try
            {
                var enumerator = Cache.GetEnumerator();
                while (enumerator.MoveNext())
                {
                    this.Cache.Remove(enumerator.Key?.ToString());
                }
            }
            catch { }
        }

        /// <summary>
        /// object to use when needing to cache a null value since System.Web.Caching.Cache cannot have null  values inserted w/o throwing a System.ArgumentNullException
        /// </summary>
        private class NullCacheValue { }
    }
}
