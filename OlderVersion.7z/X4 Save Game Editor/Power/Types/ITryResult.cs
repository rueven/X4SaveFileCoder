﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Power.Types
{
    public interface ITryResult
    {
        /// <summary>
        /// Whether or not the try was successful
        /// </summary>
        bool Success { get; }

        /// <summary>
        /// The raw exception thrown if the try failed
        /// </summary>
        Exception Exception { get; }

        /// <summary>
        /// Allows one to catch the thrown exception if it matches the type specified.
        /// </summary>
        /// <remarks>The method can be called more than once. Each matching exception type will fire.</remarks>
        /// <typeparam name="TException">The type of exception to check for</typeparam>
        /// <param name="handler">The method that does something witht the exception</param>
        /// <returns>The instance of the original ITryResult</returns>
        ITryResult Catch<TException>(Action<TException> handler) where TException : Exception;
    }

    public interface ITryResult<T>
    {
        /// <summary>
        /// Whether or not the try was successful
        /// </summary>
        bool Success { get; }

        /// <summary>
        /// The raw exception thrown if the try failed
        /// </summary>
        Exception Exception { get; }

        /// <summary>
        /// The value that was selected or default(T)
        /// </summary>
        T Value { get; }

        /// <summary>
        /// Returns the value property if Successful property was true
        /// </summary>
        /// <returns>The value selected or default(T)</returns>
        T GetValueIfSuccessful();

        /// <summary>
        /// Allows one to catch the thrown exception if it matches the type specified.
        /// </summary>
        /// <remarks>The method can be called more than once. Each matching exception type will fire.</remarks>
        /// <typeparam name="TException">The type of exception to check for</typeparam>
        /// <param name="handler">The method that does something witht the exception</param>
        /// <returns>The instance of the original ITryResult</returns>
        ITryResult<T> Catch<TException>(Action<TException> handler) where TException : Exception;
    }
}
