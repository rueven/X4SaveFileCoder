﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Power.Types
{
    public struct DateRange
    {
        #region Constructors
        public static DateRange Create(DateTime rawstart, DateTime rawend)
        {
            return new DateRange()
            {
                RawStart = rawstart,
                RawEnd = rawend,
                TimeSpan = DateRange.GetEnd(rawend, Context.Between).Subtract(DateRange.GetStart(rawstart, Context.Between))
            };
        }
        /// <summary>
        /// Creates a daterange using the seed date passed. Another date is calculated by adding the specified seedmodifier to the seed. The lower value is set to the RawStart, and the higher to the RawEnd.
        /// </summary>
        /// <param name="seed">This value will either be set to RawStart or the RawEnd, depending on whether the timespan (SeedModifier) was a positive or Negative value</param>
        /// <param name="seedmodifier">This value will be added to the seed to determine the second date. If the timespan is positive in nature, then it will be the RawEnd. Otherwise, it will be the start date</param>
        public static DateRange Create(DateTime seed, TimeSpan seedmodifier)
        {
            var derivedvalue = seed.Add(seedmodifier);
            return DateRange.Create(seed >= derivedvalue ? derivedvalue : seed, seed >= derivedvalue ? seed : derivedvalue);
        }
        #endregion

        /// <summary>
        /// The starting date of this object in it's raw format. This format wouldn't be used for display purposes.
        /// </summary>
        public DateTime RawStart { get; private set; }

        /// <summary>
        /// The ending date of this object in it's raw format. This format wouldn't be used for display purposes.
        /// </summary>
        public DateTime RawEnd { get; private set; }

        /// <summary>
        /// The TimeSpan represented by this DateRange
        /// </summary>
        public TimeSpan TimeSpan { get; private set; }

        /// <summary>
        /// Gets the DateTime represented by this object for the given context
        /// </summary>
        /// <param name="context">The context that the DateTime will be used/displayed</param>
        /// <returns>The resulting DateTime</returns>
        public DateTime GetStart(Context context) { return DateRange.GetStart(this.RawStart, context); }
        private static DateTime GetStart(DateTime rawvalue, Context context)
        {
            switch (context)
            {
                case Context.Between:
                case Context.Display:
                default: return rawvalue;
            }
        }

        /// <summary>
        /// Gets the DateTime represented by this object for the given context
        /// </summary>
        /// <param name="context">The context that the DateTime will be used/displayed</param>
        /// <returns>The resulting DateTime</returns>
        public DateTime GetEnd(Context context) { return DateRange.GetEnd(this.RawEnd, context); }
        private static DateTime GetEnd(DateTime rawvalue, Context context)
        {
            switch (context)
            {
                case Context.Between: return rawvalue.AddDays(1);
                case Context.Display:
                default: return rawvalue;
            }
        }

        /// <summary>
        /// Determines whether or not the given date falls in the given DateRange
        /// </summary>
        /// <param name="value">The value to evaluate</param>
        /// <returns>True when the date is in this range</returns>
        public bool Contains(DateTime value) { return this.Contains(value, Context.Between); }
        /// <summary>
        /// Determines whether or not the given date falls in the given DateRange
        /// </summary>
        /// <param name="value">The value to evaluate</param>
        /// <param name="context">The context to evaluate against.</param>
        /// <returns>True when the date is in this range</returns>
        public bool Contains(DateTime value, Context context) { return value >= this.GetStart(context) && value <= this.GetEnd(context); }

        /// <summary>
        /// Gets a value that lets the consumer know whether this object is valid or not
        /// </summary>
        /// <returns>A Boolean Value</returns>
        public bool IsValid() { return this.RawStart >= this.RawEnd; }

        /// <summary>
        /// Shifts both dates in the direction of the specified timespan by the amount that timespan
        /// </summary>
        /// <param name="value">The amount to be added to both component dates</param>
        /// <returns>The resulting DateRange</returns>
        public DateRange Add(TimeSpan value) { return DateRange.Create(this.RawStart.Add(value), this.RawEnd.Add(value)); }

        /// <summary>
        /// Shifts both dates in the direction of the specified amount
        /// </summary>
        /// <param name="value">The amount to be added to both component dates</param>
        /// <returns>The resulting DateRange</returns>
        public DateRange AddDays(double value) { return DateRange.Create(this.RawStart.AddDays(value), this.RawEnd.AddDays(value)); }

        /// <summary>
        /// Shifts both dates in the direction of the specified amount
        /// </summary>
        /// <param name="value">The amount to be added to both component dates</param>
        /// <returns>The resulting DateRange</returns>
        public DateRange AddHours(double value) { return DateRange.Create(this.RawStart.AddHours(value), this.RawEnd.AddHours(value)); }

        /// <summary>
        /// Shifts both dates in the direction of the specified amount
        /// </summary>
        /// <param name="value">The amount to be added to both component dates</param>
        /// <returns>The resulting DateRange</returns>
        public DateRange AddMilliseconds(double value) { return DateRange.Create(this.RawStart.AddMilliseconds(value), this.RawEnd.AddMilliseconds(value)); }

        /// <summary>
        /// Shifts both dates in the direction of the specified amount
        /// </summary>
        /// <param name="value">The amount to be added to both component dates</param>
        /// <returns>The resulting DateRange</returns>
        public DateRange AddMinutes(double value) { return DateRange.Create(this.RawStart.AddMinutes(value), this.RawEnd.AddMinutes(value)); }

        /// <summary>
        /// Shifts both dates in the direction of the specified amount
        /// </summary>
        /// <param name="value">The amount to be added to both component dates</param>
        /// <returns>The resulting DateRange</returns>
        public DateRange AddMonths(int value) { return DateRange.Create(this.RawStart.AddMonths(value), this.RawEnd.AddMonths(value)); }

        /// <summary>
        /// Shifts both dates in the direction of the specified amount
        /// </summary>
        /// <param name="value">The amount to be added to both component dates</param>
        /// <returns>The resulting DateRange</returns>
        public DateRange AddSeconds(double value) { return DateRange.Create(this.RawStart.AddSeconds(value), this.RawEnd.AddSeconds(value)); }

        /// <summary>
        /// Shifts both dates in the direction of the specified amount
        /// </summary>
        /// <param name="value">The amount to be added to both component dates</param>
        /// <returns>The resulting DateRange</returns>
        public DateRange AddTicks(long value) { return DateRange.Create(this.RawStart.AddTicks(value), this.RawEnd.AddTicks(value)); }

        /// <summary>
        /// Shifts both dates in the direction of the specified amount
        /// </summary>
        /// <param name="value">The amount to be added to both component dates</param>
        /// <returns>The resulting DateRange</returns>
        public DateRange AddYears(int value) { return DateRange.Create(this.RawStart.AddYears(value), this.RawEnd.AddYears(value)); }

        /// <summary>
        /// Shifts both dates in the direction of the specified amount
        /// </summary>
        /// <param name="value">The amount to be subtracted to both component dates</param>
        /// <returns>The resulting DateRange</returns>
        public DateRange Subtract(TimeSpan value) { return DateRange.Create(this.RawStart.Subtract(value), this.RawEnd.Subtract(value)); }

        public enum Context
        {
            Display,
            Between
        }
    }
}
