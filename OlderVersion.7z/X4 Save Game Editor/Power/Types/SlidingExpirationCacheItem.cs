﻿using System;

namespace Power.Types
{
    [Serializable]
    public class SlidingExpirationCacheItem : DecoratedCacheItem
    {
        public SlidingExpirationCacheItem(string key, object value, TimeSpan expires)
            : base(key, value)
        {
            this.Expires = expires;
        }

        public TimeSpan Expires { get; private set; }

        public override bool IsExpired(DateTime value)
        {
            return this.TimeSinceLastAccessed(value) > this.Expires;
        }

        public override void ResetExpiration(Action<TimeSpan> handler)
        {
            handler?.Invoke(this.Expires);
        }
    }
}
