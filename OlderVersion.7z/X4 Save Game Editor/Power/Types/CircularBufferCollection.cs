﻿using System;
using System.Collections;
using System.Collections.Generic;

namespace Power.Types
{
    public class CircularBufferCollection<T> : IEnumerable<T>
    {
        #region Constructor
        public CircularBufferCollection(int size)
        {
            this.Size = size;
        }
        #endregion

        #region Properties
        public int Size { get; private set; }
        private Queue<T> Items { get; } = new Queue<T>();
        #endregion

        #region IEnumerable<T> Members

        public IEnumerator<T> GetEnumerator()
        {
            return this
                .Items
                .GetEnumerator();
        }

        IEnumerator IEnumerable.GetEnumerator()
        {
            return GetEnumerator();
        }

        #endregion

        public void Add(T item)
        {
            if (this.Items.Count > this.Size)
            {
                this.Items
                    .Dequeue();
            }
            this.Items
                .Enqueue(item);
        }
    }
}
