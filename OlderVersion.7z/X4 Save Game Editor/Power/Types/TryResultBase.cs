﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Power.Types
{
    internal abstract class TryResultBase<TSelf> where TSelf : TryResultBase<TSelf>
    {
        protected TryResultBase(Exception e = null) { this.Exception = e; }

        public bool Success { get { return this.Exception == null; } }
        public Exception Exception { get; private set; }

        public TSelf Catch<TException>(Action<TException> handler) where TException : Exception
        {
            if (handler == null) { throw new ArgumentNullException("handler"); }
            if (this.Success) { return (TSelf)this; }
            var exception = this.Exception as TException;
            if (exception == null) { return (TSelf)this; }
            handler(exception);
            return (TSelf)this;
        }
    }
}
