﻿using System;
using System.Collections.Generic;
using System.IO;
using Power.Framework;
using Power.Framework.FieldDefinitionReaders;

namespace Power.Types
{
    public interface IDelimitedStringToEntityConverter
    {
        string RowDelimiter { get; }
        string ColumnDelimiter { get; }
        char Escape { get; }
        void Execute<T>(string body, Func<T> entityFactory, Action<T> handleEntity, params ElementAtFieldDefinitionReader[] fieldReaders) where T : IEntity;
        void Execute<T>(TextReader reader, Func<T> entityFactory, Action<T> handleEntity, params ElementAtFieldDefinitionReader[] fieldReaders) where T : IEntity;
        IReadOnlyList<T> ReadAll<T>(TextReader reader, Func<T> entityFactory, params ElementAtFieldDefinitionReader[] fieldReaders) where T : IEntity;
        IReadOnlyList<T> ReadAll<T>(string body, Func<T> entityFactory, params ElementAtFieldDefinitionReader[] fieldReaders) where T : IEntity;
    }
}
