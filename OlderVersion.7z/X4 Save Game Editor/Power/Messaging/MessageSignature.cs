﻿using System;

namespace Power.Messaging
{
    public class MessageSignature
    {
        public string Module { get; set; }
        public Exception Exception { get; set; }
    }
}
