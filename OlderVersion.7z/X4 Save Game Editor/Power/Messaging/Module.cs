﻿using System;

namespace Power.Messaging
{
    public abstract class Module
    {
        public Module(IMessageBroker broker)
        {
            if (broker == null) { throw new ArgumentNullException(); }
            this.Broker = broker;
        }

        protected IMessageBroker Broker { get; private set; }

        protected abstract void RegisterSubscriptions(ISubscriptionProviderHook provider);
        protected abstract void UnregisterSubscriptions(ISubscriptionProviderHook provider);

        internal void OnAddedToEnvironment(ISubscriptionProviderHook provider)
        {
            this.RegisterSubscriptions(provider);
        }

        internal void OnRemovedFromEnvironment(ISubscriptionProviderHook provider)
        {
            this.UnregisterSubscriptions(provider);
        }
    }
}
