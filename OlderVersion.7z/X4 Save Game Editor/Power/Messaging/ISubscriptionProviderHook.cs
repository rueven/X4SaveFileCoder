﻿using System;

namespace Power.Messaging
{
    public interface ISubscriptionProviderHook : IHook
    {
        void Subscribe<T>(HandleIdentifiers.ISubscriber<T> subscriber, Action<T> handlemethod) where T : Message;
        void Subscribe<T>(HandleIdentifiers.ISubscriber<T> subscriber, Action<T> handlemethod, Func<T, bool> issupportedmethod) where T : Message;
        void UnSubscribe<T>(HandleIdentifiers.ISubscriber<T> subscriber, Action<T> method) where T : Message;
    }
}
