﻿namespace Power.Messaging
{
    internal class MessageBrokerInitializer : IMessageBrokerInitializerHook
    {
        public MessageBrokerInitializer(MessageBroker parent) { this.MessageBroker = parent; }

        public MessageBroker MessageBroker { get; private set; }
        IMessageBroker IMessageBrokerInitializerHook.MessageBroker { get { return this.MessageBroker; } }

        public bool IsValid { get { return this.MessageBroker != null; } }

        public Module Add(Module module)
        {
            return this.MessageBroker.Add(module);
        }

        public Module Remove(Module module)
        {
            return this.MessageBroker.Remove(module);
        }

        public void Invalidate()
        {
            this.MessageBroker = null;
        }
    }
}
