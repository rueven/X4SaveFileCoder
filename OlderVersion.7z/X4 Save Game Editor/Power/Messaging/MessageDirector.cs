﻿using System;

namespace Power.Messaging
{
    internal abstract class MessageDirector
    {
        public object Parent { get; protected set; }
        public abstract bool IsSupported(Message message);
        public abstract void Handle(Message message);
    }

    internal sealed class MessageDirector<T> : MessageDirector where T : Message
    {
        private MessageDirector() { }

        public static MessageDirector<T> Create(HandleIdentifiers.ISubscriber<T> parent, Action<T> handlemethod)
        {
            return new MessageDirector<T>()
            {
                Parent = parent,
                HandleMethod = handlemethod
            };
        }

        public static MessageDirector<T> Create(HandleIdentifiers.ISubscriber<T> parent, Action<T> handlemethod, Func<T, bool> issupportedmethod)
        {
            return new MessageDirector<T>()
            {
                Parent = parent,
                HandleMethod = handlemethod,
                IsSupportedMethod = issupportedmethod
            };
        }

        private Action<T> HandleMethod { get; set; }

        private Func<T, bool> IsSupportedMethod { get; set; }

        public override void Handle(Message message)
        {
            var unwrappedmessage = message as T;
            if (unwrappedmessage != null)
            {
                this.HandleMethod(unwrappedmessage);
            }
        }

        public override bool IsSupported(Message message)
        {
            var unwrappedmessage = message as T;
            if (unwrappedmessage == null)
            { return false; }
            if (this.IsSupportedMethod != null)
            {
                return this.IsSupportedMethod(unwrappedmessage);
            }
            return true;
        }

        public override bool Equals(object obj)
        {
            var value = obj as MessageDirector<T>;
            if (value != null)
            {
                return value.HandleMethod == this.HandleMethod && this.Parent == value.Parent;
            }
            return base.Equals(obj);
        }

        public override int GetHashCode() { return base.GetHashCode(); }
    }
}
