﻿using System;
using System.Collections.Generic;

namespace Power.Messaging
{
    public abstract class Message
    {
        public Message() { this.InnerSignatures = new List<MessageSignature>(); }
        private List<MessageSignature> InnerSignatures { get; set; }
        public bool? Success { get; private set; }
        public IReadOnlyList<MessageSignature> Signatures { get { return this.InnerSignatures; } }

        public void Sign(object module, Exception e)
        {
            if (this.InnerSignatures != null)
            {
                this.Success = this.Success.HasValue ? this.Success.Value && e == null : e == null;
                this.InnerSignatures.Add(new MessageSignature()
                {
                    Module = module == null ? null : module is string ? (string)module : module.GetType().FullName,
                    Exception = e
                });
            }
        }
        public void Sign(object module) { this.Sign(module, null); }
    }
}
