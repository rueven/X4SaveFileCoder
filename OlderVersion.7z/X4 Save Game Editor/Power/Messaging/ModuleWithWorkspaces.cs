﻿using System;
using System.Collections.Concurrent;

namespace Power.Messaging
{
    public abstract class ModuleWithWorkspaces<TModule> : Module where TModule : Module
    {
        protected ModuleWithWorkspaces(IMessageBroker broker)
            : base(broker)
        {
            this.WorkspaceRegistry = new ConcurrentDictionary<Message, object>();
        }

        #region Worker tracking

        private ConcurrentDictionary<Message, object> WorkspaceRegistry { get; set; }

        private ModuleWorkspace<TModule, TMessage> GetWorkspaceForMessage<TMessage>(TMessage message) where TMessage : Message
        {
            var value = (object)null;
            if (this.WorkspaceRegistry.TryGetValue(message, out value))
            {
                return value as ModuleWorkspace<TModule, TMessage>;
            }
            return null;
        }

        private void SetWorkspaceForMessage<TMessage>(Message message, ModuleWorkspace<TModule, TMessage> worker) where TMessage : Message
        {
            this.WorkspaceRegistry.AddOrUpdate
            (
                message,
                worker,
                (key, oldValue) => worker
            );
        }

        private bool RemoveWorkspaceForMessage<TMessage, TWorker>(Message message)
            where TMessage : Message
            where TWorker : ModuleWorkspace<TModule, TMessage>
        {
            var worker = (TWorker)null;
            return this.RemoveWorkspaceForMessage<TMessage, TWorker>(message, out worker);
        }

        private bool RemoveWorkspaceForMessage<TMessage, TWorker>(Message message, out TWorker worker)
            where TMessage : Message
            where TWorker : ModuleWorkspace<TModule, TMessage>
        {
            var item = (object)null;
            var output = this.WorkspaceRegistry.TryRemove(message, out item);
            worker = item as TWorker;
            return output;
        }

        #endregion

        private bool ShouldHandle<TMessage, TWorker>(TMessage message, Func<TMessage, TWorker> workerFactory)
            where TMessage : Message
            where TWorker : ModuleWorkspace<TModule, TMessage>
        {
            var worker = workerFactory(message);
            if (worker.ShouldHandle())
            {
                this.SetWorkspaceForMessage(message, worker);
                return true;
            }
            this.RemoveWorkspaceForMessage<TMessage, TWorker>(message);
            return false;
        }

        protected void Handle<TMessage, TWorker>(TMessage message, Func<TMessage, TWorker> workerFactory)
            where TMessage : Message
            where TWorker : ModuleWorkspace<TModule, TMessage>
        {
            if (this.ShouldHandle<TMessage, TWorker>(message, workerFactory))
            {
                var worker = this.GetWorkspaceForMessage(message);
                if (worker == null) { throw new Exception("Worker not found for message"); }
                else { worker.Handle(); }
            }
            this.RemoveWorkspaceForMessage<TMessage, TWorker>(message);
        }
    }
}
