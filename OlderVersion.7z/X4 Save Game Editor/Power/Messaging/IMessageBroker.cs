﻿using System;
using System.Threading.Tasks;

namespace Power.Messaging
{
    public interface IMessageBroker
    {
        void Publish<T>(HandleIdentifiers.IPublisher<T> publisher, T message) where T : Message;
        Task PublishAsync<T>(HandleIdentifiers.IPublisher<T> publisher, T message, Action<T, Exception> callback) where T : Message;
    }
}
