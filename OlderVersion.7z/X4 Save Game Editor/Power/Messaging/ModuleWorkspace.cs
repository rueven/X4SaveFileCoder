﻿namespace Power.Messaging
{
    public abstract class ModuleWorkspace<TModule, TMessage>
        where TModule : Module
        where TMessage : Message
    {
        public ModuleWorkspace(TModule parent, TMessage message)
        {
            this.Parent = parent;
            this.Message = message;
        }

        protected TModule Parent { get; private set; }
        protected TMessage Message { get; private set; }

        public virtual bool ShouldHandle()
        {
            return true;
        }

        public abstract void Handle();
    }
}
