﻿using System;

namespace Power.Messaging
{
    /// <summary>Used only by virtua of the interface. Used to provide subscription API to modules.</summary>
    internal class SubscriptionProvider : ISubscriptionProviderHook
    {
        public SubscriptionProvider(MessageBroker broker) { this.Broker = broker; }

        public MessageBroker Broker { get; private set; }
        public bool IsValid { get { return this.Broker != null; } }

        public void Invalidate()
        {
            this.Broker = null;
        }

        public void Subscribe<T>(HandleIdentifiers.ISubscriber<T> subscriber, Action<T> handlemethod) where T : Message
        {
            var messagehandler = MessageDirector<T>.Create(subscriber, handlemethod);
            this.Broker.Subscribe(typeof(T), messagehandler);
        }

        public void Subscribe<T>(HandleIdentifiers.ISubscriber<T> subscriber, Action<T> handlemethod, Func<T, bool> issupportedmethod) where T : Message
        {
            var messagehandler = MessageDirector<T>.Create(subscriber, handlemethod, issupportedmethod);
            this.Broker.Subscribe(typeof(T), messagehandler);
        }

        public void UnSubscribe<T>(HandleIdentifiers.ISubscriber<T> subscriber, Action<T> method) where T : Message
        {
            var messagehandler = MessageDirector<T>.Create(subscriber, method);
            this.Broker.UnSubscribe(typeof(T), messagehandler);
        }
    }
}
