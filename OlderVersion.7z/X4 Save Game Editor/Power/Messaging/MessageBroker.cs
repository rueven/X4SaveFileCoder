﻿using System;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace Power.Messaging
{
    public class MessageBroker : IMessageBroker
    {
        public MessageBroker()
        {
            this.Modules = new List<Module>();
            this.Subscriptions = new Dictionary<Type, List<MessageDirector>>();
        }

        #region Properties

        private bool IsInitialized { get; set; }
        private List<Module> Modules { get; set; }
        private Dictionary<Type, List<MessageDirector>> Subscriptions { get; set; }

        #endregion
        
        public void Initialize(Action<IMessageBrokerInitializerHook> initializer = null)
        {
            var hook = new MessageBrokerInitializer(this);
            initializer?.Invoke(hook);
            hook.Invalidate();
            this.IsInitialized = initializer != null;
        }

        #region Internal Members

        internal void Subscribe(Type type, MessageDirector handler)
        {
            var list = this.Subscriptions.ContainsKey(type) ? this.Subscriptions[type] : null;
            if (list == null)
            {
                list = new List<MessageDirector>();
                this.Subscriptions.Add(type, list);
            }
            if (list.Contains(handler).Equals(false))
            {
                list.Add(handler);
            }
        }

        internal void UnSubscribe(Type type, MessageDirector handler)
        {
            var list = this.Subscriptions.ContainsKey(type) ? this.Subscriptions[type] : null;
            if (list == null)
            {
                return;
            }
            if (list.Contains(handler))
            {
                list.Remove(handler);
            }
        }

        internal Module Add(Module module)
        {
            if (this.Modules.Contains(module)) { return module; }
            if (IsInitialized) { throw new Exception("The message broker has already been initialized. No modules may be added."); }
            this.Modules.Add(module);
            var provider = new SubscriptionProvider(this);
            module.OnAddedToEnvironment(provider);
            provider.Invalidate();
            return module;
        }

        internal Module Remove(Module module)
        {
            if (this.Modules.Contains(module))
            {
                this.Modules.Remove(module);
                var provider = new SubscriptionProvider(this);
                module.OnRemovedFromEnvironment(provider);
                provider.Invalidate();
            }
            return module;
        }
        #endregion

        void IMessageBroker.Publish<T>(HandleIdentifiers.IPublisher<T> publisher, T message)
        {
            this.Handle(message);
        }

        public async Task PublishAsync<T>(HandleIdentifiers.IPublisher<T> publisher, T message, Action<T, Exception> callback) where T : Message
        {
            await this.HandleAsync(message, callback);
        }

        /// <summary>
        /// Handles a method based on the explicit type of the generic parameter. This method can be be called using the keyword "await".
        /// </summary>
        /// <typeparam name="TMessage">The explicit type to route the message with</typeparam>
        /// <param name="message">The message to route</param>
        /// <param name="callback">The callback that will be fired when the routing is completed</param>
        public async Task HandleAsync<T>(T message, Action<T, Exception> callback) where T : Message
        {
            var exception = (Exception)null;
            await Task.Run(() =>
            {
                try
                {
                    this.Handle(message);
                }
                catch (Exception e)
                {
                    exception = e;
                }
            });
            callback?.Invoke(message, exception);
        }

        /// <summary>
        /// Handles a method based on the explicit type of the generic parameter
        /// </summary>
        /// <typeparam name="T">The explicit type to route the message with</typeparam>
        /// <param name="message">The message to route</param>
        public void Handle<T>(T message) where T : Message
        {
            var type = typeof(T);
            this.Handle(type, message);
        }

        /// <summary>
        /// Handles a method based on the return value of message.GetType()
        /// </summary>
        /// <param name="message">The message to route</param>
        public void HandleAnonymous(Message message)
        {
            var type = message.GetType();
            this.Handle(type, message);
        }

        private void Handle(Type type, Message message)
        {
            var list = this.Subscriptions.ContainsKey(type) ? this.Subscriptions[type] : null;
            if (list != null)
            {
                foreach (var item in list)
                {
                    if (item.IsSupported(message))
                    {
                        try
                        {
                            item.Handle(message);
                            message.Sign(item.Parent);
                        }
                        catch (Exception e)
                        {
                            message.Sign(item.Parent, e);
                        }
                    }
                }
            }
        }
    }
}
