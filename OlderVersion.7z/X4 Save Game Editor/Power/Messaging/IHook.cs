﻿namespace Power.Messaging
{
    public interface IHook
    {
        bool IsValid { get; }
        void Invalidate();
    }
}
