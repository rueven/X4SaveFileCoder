﻿namespace Power.Messaging
{
    public interface IMessageBrokerInitializerHook
    {
        IMessageBroker MessageBroker { get; }
        Module Add(Module module);
        Module Remove(Module module);
    }
}
