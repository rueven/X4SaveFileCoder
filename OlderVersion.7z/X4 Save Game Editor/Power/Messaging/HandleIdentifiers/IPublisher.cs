﻿namespace Power.Messaging.HandleIdentifiers
{
    public interface IPublisher<T>
        where T : Message
    { }
}
