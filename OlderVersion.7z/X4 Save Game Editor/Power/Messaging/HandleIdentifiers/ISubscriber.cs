﻿namespace Power.Messaging.HandleIdentifiers
{
    public interface ISubscriber<T>
        where T : Message
    {
        void Handle(T message);
    }
}
