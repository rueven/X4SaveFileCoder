﻿namespace Power.Messaging.HandleIdentifiers
{
    public interface IHandler<T>
        : ISubscriber<T> where T : Message
    { }
}
