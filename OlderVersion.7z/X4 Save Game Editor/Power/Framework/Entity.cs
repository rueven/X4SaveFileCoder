﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace Power.Framework
{
    public abstract class EntityBase : IEntity
    {
        public EntityBase()
        {
            this.Initialize((key, value) => this.InnerFields.Add(key, value));
        }

        private Dictionary<FieldDefinition, FieldAccessor> InnerFields { get; } = new Dictionary<FieldDefinition, FieldAccessor>();
        protected IReadOnlyDictionary<FieldDefinition, FieldAccessor> Fields { get { return this.InnerFields; } }
        protected virtual object GetReferenceId() { return this.GetHashCode(); }

        protected virtual void Initialize(Action<FieldDefinition, FieldAccessor> addField) { }

        /// <summary>
        /// Resets the given entity to its original state
        /// </summary>
        public virtual void Revert()
        {
            foreach (var field in this.Fields)
            {
                var originalValue = field.Key.GetBoxedValue(this, FieldDefinitionValueTypes.Original);
                field.Key.SetBoxedValue(this, originalValue);
            }
        }

        /// <summary>
        /// Returns a value indicating whether or not this entity has properties that have changed from their original values
        /// </summary>
        /// <returns>True if the entity has values differing from the original values</returns>
        public virtual bool IsChanged()
        {
            return this
                .Fields
                .Any(x => x.Key.IsChanged(this));
        }

        /// <summary>
        /// Forces all orginal field values to be overwritten with current values, making this object appear unchanged
        /// </summary>
        public virtual void MarkAsUnChanged()
        {
            foreach (var field in this.Fields)
            {
                var value = field.Key.GetBoxedValue(this);
                field.Key.SetBoxedValue(this, value, FieldDefinitionValueTypes.Original);
            }
        }

        #region IEntity Members

        IReadOnlyDictionary<FieldDefinition, FieldAccessor> IEntity.Fields { get { return this.Fields; } }
        object IEntity.ReferenceId { get { return this.GetReferenceId(); } }

        #endregion
    }
}
