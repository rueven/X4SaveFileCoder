﻿namespace Power.Framework
{
    public interface IFieldDefinitionReader<T>
    {
        FieldDefinition FieldDefinition { get; }
        string GetValue(T source);
    }
}
