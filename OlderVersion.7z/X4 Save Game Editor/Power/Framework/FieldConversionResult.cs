﻿namespace Power.Framework
{
    public class FieldConversionResult<T>
    {
        public static FieldConversionResult<T> CreateFail() { return new FieldConversionResult<T>(); }
        public static FieldConversionResult<T> CreateSuccess(T value)
        {
            return new FieldConversionResult<T>()
            {
                Value = value,
                Success = true
            };
        }
        public T Value { get; private set; }
        public bool Success { get; private set; }
    }
}
