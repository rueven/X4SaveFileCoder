﻿using System;
using System.Data;
using Power.Utilities;

namespace Power.Framework.FieldDefinitions
{
    #region String

    public class StringFieldDefinition : FieldDefinition<string>
    {
        public StringFieldDefinition(Type entityType, string name, string defaultValue = default(string), int? size = null)
            : base(entityType, name, defaultValue, size) { }

        public override string GetCoercedValue(IEntity entity, FieldDefinitionValueTypes type = FieldDefinitionValueTypes.Current)
        {
            var accessor = this.GetFieldAccessor(entity);
            switch (type)
            {
                case FieldDefinitionValueTypes.Current:
                    return accessor.Value == null ? null : accessor.Value.ToString();
                case FieldDefinitionValueTypes.Original:
                    return accessor.OriginalValue == null ? null : accessor.OriginalValue.ToString();
                case FieldDefinitionValueTypes.Default:
                default:
                    return this.DefaultValue == null ? null : this.DefaultValue.ToString();
            }
        }

        public override void SetCoercedValue(IEntity entity, string value, FieldDefinitionValueTypes type = FieldDefinitionValueTypes.Current)
        {
            var accessor = this.GetFieldAccessor(entity);
            switch (type)
            {
                case FieldDefinitionValueTypes.Current:
                    accessor.Value = DataHelper.ToString(value, this.DefaultValue);
                    break;
                case FieldDefinitionValueTypes.Original:
                    accessor.OriginalValue = DataHelper.ToString(value, this.DefaultValue);
                    break;
                case FieldDefinitionValueTypes.Default:
                    break;
            }
        }

        public override void HydrateFrom(IEntity entity, IDataReader reader, int index)
        {
            this.LoadValue(entity, reader.GetNullableString(index));
        }

        public override SqlDbType GetSqlDbType()
        {
            return SqlDbType.VarChar;
        }

        public override object CoerceValueIntoType(string value)
        {
            return DataHelper.ToString(value, this.DefaultValue);
        }
    }

    #endregion

    #region ByteArray

    public class ByteArrayFieldDefinition : FieldDefinition<byte[]>
    {
        public ByteArrayFieldDefinition(Type entityType, string name, byte[] defaultValue = default(byte[]))
            : base(entityType, name, defaultValue, 16) { }

        public override string GetCoercedValue(IEntity entity, FieldDefinitionValueTypes type = FieldDefinitionValueTypes.Current)
        {
            var accessor = this.GetFieldAccessor(entity);
            switch (type)
            {
                case FieldDefinitionValueTypes.Current:
                    return accessor.Value == null ? null : accessor.Value.ToString();
                case FieldDefinitionValueTypes.Original:
                    return accessor.OriginalValue == null ? null : accessor.OriginalValue.ToString();
                case FieldDefinitionValueTypes.Default:
                default:
                    return this.DefaultValue == null ? null : this.DefaultValue.ToString();
            }
        }

        public override void SetCoercedValue(IEntity entity, string value, FieldDefinitionValueTypes type = FieldDefinitionValueTypes.Current)
        {
            var accessor = this.GetFieldAccessor(entity);
            switch (type)
            {
                case FieldDefinitionValueTypes.Current:
                    accessor.Value = DataHelper.ToByteArray(value, this.DefaultValue);
                    break;
                case FieldDefinitionValueTypes.Original:
                    accessor.OriginalValue = DataHelper.ToByteArray(value, this.DefaultValue);
                    break;
                case FieldDefinitionValueTypes.Default:
                    break;
            }
        }

        public override void HydrateFrom(IEntity entity, IDataReader reader, int index)
        {
            this.LoadValue(entity, reader.GetByteArray(index));
        }

        public override SqlDbType GetSqlDbType()
        {
            return SqlDbType.VarBinary;
        }

        public override object CoerceValueIntoType(string value)
        {
            return DataHelper.ToByteArray(value, this.DefaultValue);
        }
    }

    #endregion

    #region Boolean

    public class BooleanFieldDefinition : FieldDefinition<bool>
    {
        public BooleanFieldDefinition(Type entityType, string name, bool defaultValue = default(bool))
            : base(entityType, name, defaultValue, 1) { }

        public override string GetCoercedValue(IEntity entity, FieldDefinitionValueTypes type = FieldDefinitionValueTypes.Current)
        {
            var accessor = this.GetFieldAccessor(entity);
            switch (type)
            {
                case FieldDefinitionValueTypes.Current:
                    return accessor.Value.ToString();
                case FieldDefinitionValueTypes.Original:
                    return accessor.OriginalValue.ToString();
                case FieldDefinitionValueTypes.Default:
                default:
                    return this.DefaultValue.ToString();
            }
        }

        public override void SetCoercedValue(IEntity entity, string value, FieldDefinitionValueTypes type = FieldDefinitionValueTypes.Current)
        {
            var accessor = this.GetFieldAccessor(entity);
            switch (type)
            {
                case FieldDefinitionValueTypes.Current:
                    accessor.Value = DataHelper.ToBoolean(value, this.DefaultValue);
                    break;
                case FieldDefinitionValueTypes.Original:
                    accessor.OriginalValue = DataHelper.ToBoolean(value, this.DefaultValue);
                    break;
                case FieldDefinitionValueTypes.Default:
                    break;
            }
        }

        public override void HydrateFrom(IEntity entity, IDataReader reader, int index)
        {
            this.LoadValue(entity, reader.GetBoolean(index));
        }

        public override SqlDbType GetSqlDbType()
        {
            return SqlDbType.Bit;
        }

        public override object CoerceValueIntoType(string value)
        {
            return DataHelper.ToBoolean(value, this.DefaultValue);
        }
    }

    #endregion

    #region NullableBoolean

    public class NullableBooleanFieldDefinition : FieldDefinition<bool?>
    {
        public NullableBooleanFieldDefinition(Type entityType, string name, bool? defaultValue = default(bool?))
            : base(entityType, name, defaultValue, 1) { }

        public override string GetCoercedValue(IEntity entity, FieldDefinitionValueTypes type = FieldDefinitionValueTypes.Current)
        {
            var accessor = this.GetFieldAccessor(entity);
            switch (type)
            {
                case FieldDefinitionValueTypes.Current:
                    return accessor.Value.HasValue ? this.ConvertToString(accessor.Value) : this.ConvertToString(this.DefaultValue);
                case FieldDefinitionValueTypes.Original:
                    return accessor.OriginalValue.HasValue ? this.ConvertToString(accessor.OriginalValue) : this.ConvertToString(this.DefaultValue);
                case FieldDefinitionValueTypes.Default:
                default:
                    return this.ConvertToString(this.DefaultValue);
            }
        }

        public override void SetCoercedValue(IEntity entity, string value, FieldDefinitionValueTypes type = FieldDefinitionValueTypes.Current)
        {
            var accessor = this.GetFieldAccessor(entity);
            switch (type)
            {
                case FieldDefinitionValueTypes.Current:
                    accessor.Value = DataHelper.ToNullableBoolean(value);
                    break;
                case FieldDefinitionValueTypes.Original:
                    accessor.OriginalValue = DataHelper.ToNullableBoolean(value);
                    break;
                case FieldDefinitionValueTypes.Default:
                    break;
            }
        }

        public override void HydrateFrom(IEntity entity, IDataReader reader, int index)
        {
            this.LoadValue(entity, reader.GetNullableBoolean(index));
        }

        public override SqlDbType GetSqlDbType()
        {
            return SqlDbType.Bit;
        }

        protected string ConvertToString(bool? value)
        {
            return value.HasValue ? value.Value.ToString() : null;
        }

        public override object CoerceValueIntoType(string value)
        {
            return DataHelper.ToNullableBoolean(value);
        }
    }

    #endregion

    #region Byte

    public class ByteFieldDefinition : FieldDefinition<byte>
    {
        public ByteFieldDefinition(Type entityType, string name, byte defaultValue = default(byte), string format = null)
            : base(entityType, name, defaultValue, 1) { this.Format = format; }

        public string Format { get; private set; }

        public override string GetCoercedValue(IEntity entity, FieldDefinitionValueTypes type = FieldDefinitionValueTypes.Current)
        {
            var accessor = this.GetFieldAccessor(entity);
            switch (type)
            {
                case FieldDefinitionValueTypes.Current:
                    return accessor.Value.ToString(this.Format);
                case FieldDefinitionValueTypes.Original:
                    return accessor.OriginalValue.ToString(this.Format);
                case FieldDefinitionValueTypes.Default:
                default:
                    return this.DefaultValue.ToString(this.Format);
            }
        }

        public override void SetCoercedValue(IEntity entity, string value, FieldDefinitionValueTypes type = FieldDefinitionValueTypes.Current)
        {
            var accessor = this.GetFieldAccessor(entity);
            switch (type)
            {
                case FieldDefinitionValueTypes.Current:
                    accessor.Value = DataHelper.ToByte(value, this.DefaultValue);
                    break;
                case FieldDefinitionValueTypes.Original:
                    accessor.OriginalValue = DataHelper.ToByte(value, this.DefaultValue);
                    break;
                case FieldDefinitionValueTypes.Default:
                    break;
            }
        }

        public override void HydrateFrom(IEntity entity, IDataReader reader, int index)
        {
            this.LoadValue(entity, reader.GetByte(index));
        }

        public override SqlDbType GetSqlDbType()
        {
            return SqlDbType.TinyInt;
        }

        public override object CoerceValueIntoType(string value)
        {
            return DataHelper.ToByte(value, this.DefaultValue);
        }
    }

    #endregion

    #region NullableByte

    public class NullableByteFieldDefinition : FieldDefinition<byte?>
    {
        public NullableByteFieldDefinition(Type entityType, string name, byte? defaultValue = default(byte?), string format = null)
            : base(entityType, name, defaultValue, 1) { this.Format = format; }

        public string Format { get; private set; }

        public override string GetCoercedValue(IEntity entity, FieldDefinitionValueTypes type = FieldDefinitionValueTypes.Current)
        {
            var accessor = this.GetFieldAccessor(entity);
            switch (type)
            {
                case FieldDefinitionValueTypes.Current:
                    return accessor.Value.HasValue ? this.ConvertToString(accessor.Value) : this.ConvertToString(this.DefaultValue);
                case FieldDefinitionValueTypes.Original:
                    return accessor.OriginalValue.HasValue ? this.ConvertToString(accessor.OriginalValue) : this.ConvertToString(this.DefaultValue);
                case FieldDefinitionValueTypes.Default:
                default:
                    return this.ConvertToString(this.DefaultValue);
            }
        }

        public override void SetCoercedValue(IEntity entity, string value, FieldDefinitionValueTypes type = FieldDefinitionValueTypes.Current)
        {
            var accessor = this.GetFieldAccessor(entity);
            switch (type)
            {
                case FieldDefinitionValueTypes.Current:
                    accessor.Value = DataHelper.ToNullableByte(value);
                    break;
                case FieldDefinitionValueTypes.Original:
                    accessor.OriginalValue = DataHelper.ToNullableByte(value);
                    break;
                case FieldDefinitionValueTypes.Default:
                    break;
            }
        }

        public override void HydrateFrom(IEntity entity, IDataReader reader, int index)
        {
            this.LoadValue(entity, reader.GetNullableByte(index));
        }

        public override SqlDbType GetSqlDbType()
        {
            return SqlDbType.TinyInt;
        }

        protected string ConvertToString(byte? value)
        {
            return value.HasValue ? value.Value.ToString(this.Format) : null;
        }

        public override object CoerceValueIntoType(string value)
        {
            return DataHelper.ToNullableByte(value);
        }
    }

    #endregion

    #region Short

    public class ShortFieldDefinition : FieldDefinition<short>
    {
        public ShortFieldDefinition(Type entityType, string name, short defaultValue = default(short), string format = null)
            : base(entityType, name, defaultValue, 2) { this.Format = format; }

        public string Format { get; private set; }

        public override string GetCoercedValue(IEntity entity, FieldDefinitionValueTypes type = FieldDefinitionValueTypes.Current)
        {
            var accessor = this.GetFieldAccessor(entity);
            switch (type)
            {
                case FieldDefinitionValueTypes.Current:
                    return accessor.Value.ToString(this.Format);
                case FieldDefinitionValueTypes.Original:
                    return accessor.OriginalValue.ToString(this.Format);
                case FieldDefinitionValueTypes.Default:
                default:
                    return this.DefaultValue.ToString(this.Format);
            }
        }

        public override void SetCoercedValue(IEntity entity, string value, FieldDefinitionValueTypes type = FieldDefinitionValueTypes.Current)
        {
            var accessor = this.GetFieldAccessor(entity);
            switch (type)
            {
                case FieldDefinitionValueTypes.Current:
                    accessor.Value = DataHelper.ToShort(value, this.DefaultValue);
                    break;
                case FieldDefinitionValueTypes.Original:
                    accessor.OriginalValue = DataHelper.ToShort(value, this.DefaultValue);
                    break;
                case FieldDefinitionValueTypes.Default:
                    break;
            }
        }

        public override void HydrateFrom(IEntity entity, IDataReader reader, int index)
        {
            this.LoadValue(entity, reader.GetShort(index));
        }

        public override SqlDbType GetSqlDbType()
        {
            return SqlDbType.SmallInt;
        }

        public override object CoerceValueIntoType(string value)
        {
            return DataHelper.ToShort(value, this.DefaultValue);
        }
    }

    #endregion

    #region NullableShort

    public class NullableShortFieldDefinition : FieldDefinition<short?>
    {
        public NullableShortFieldDefinition(Type entityType, string name, short? defaultValue = default(short?), string format = null)
            : base(entityType, name, defaultValue, 2) { this.Format = format; }

        public string Format { get; private set; }

        public override string GetCoercedValue(IEntity entity, FieldDefinitionValueTypes type = FieldDefinitionValueTypes.Current)
        {
            var accessor = this.GetFieldAccessor(entity);
            switch (type)
            {
                case FieldDefinitionValueTypes.Current:
                    return accessor.Value.HasValue ? this.ConvertToString(accessor.Value) : this.ConvertToString(this.DefaultValue);
                case FieldDefinitionValueTypes.Original:
                    return accessor.OriginalValue.HasValue ? this.ConvertToString(accessor.OriginalValue) : this.ConvertToString(this.DefaultValue);
                case FieldDefinitionValueTypes.Default:
                default:
                    return this.ConvertToString(this.DefaultValue);
            }
        }

        public override void SetCoercedValue(IEntity entity, string value, FieldDefinitionValueTypes type = FieldDefinitionValueTypes.Current)
        {
            var accessor = this.GetFieldAccessor(entity);
            switch (type)
            {
                case FieldDefinitionValueTypes.Current:
                    accessor.Value = DataHelper.ToNullableShort(value);
                    break;
                case FieldDefinitionValueTypes.Original:
                    accessor.OriginalValue = DataHelper.ToNullableShort(value);
                    break;
                case FieldDefinitionValueTypes.Default:
                    break;
            }
        }

        public override void HydrateFrom(IEntity entity, IDataReader reader, int index)
        {
            this.LoadValue(entity, reader.GetNullableShort(index));
        }

        public override SqlDbType GetSqlDbType()
        {
            return SqlDbType.SmallInt;
        }

        protected string ConvertToString(short? value)
        {
            return value.HasValue ? value.Value.ToString(this.Format) : null;
        }

        public override object CoerceValueIntoType(string value)
        {
            return DataHelper.ToNullableShort(value);
        }
    }

    #endregion

    #region Int

    public class IntFieldDefinition : FieldDefinition<int>
    {
        public IntFieldDefinition(Type entityType, string name, int defaultValue = default(int), string format = null)
            : base(entityType, name, defaultValue, 4) { this.Format = format; }

        public string Format { get; private set; }

        public override string GetCoercedValue(IEntity entity, FieldDefinitionValueTypes type = FieldDefinitionValueTypes.Current)
        {
            var accessor = this.GetFieldAccessor(entity);
            switch (type)
            {
                case FieldDefinitionValueTypes.Current:
                    return accessor.Value.ToString(this.Format);
                case FieldDefinitionValueTypes.Original:
                    return accessor.OriginalValue.ToString(this.Format);
                case FieldDefinitionValueTypes.Default:
                default:
                    return this.DefaultValue.ToString(this.Format);
            }
        }

        public override void SetCoercedValue(IEntity entity, string value, FieldDefinitionValueTypes type = FieldDefinitionValueTypes.Current)
        {
            var accessor = this.GetFieldAccessor(entity);
            switch (type)
            {
                case FieldDefinitionValueTypes.Current:
                    accessor.Value = DataHelper.ToInt(value, this.DefaultValue);
                    break;
                case FieldDefinitionValueTypes.Original:
                    accessor.OriginalValue = DataHelper.ToInt(value, this.DefaultValue);
                    break;
                case FieldDefinitionValueTypes.Default:
                    break;
            }
        }

        public override void HydrateFrom(IEntity entity, IDataReader reader, int index)
        {
            this.LoadValue(entity, reader.GetInt(index));
        }

        public override SqlDbType GetSqlDbType()
        {
            return SqlDbType.Int;
        }

        public override object CoerceValueIntoType(string value)
        {
            return DataHelper.ToInt(value, this.DefaultValue);
        }
    }

    #endregion

    #region NullableInt

    public class NullableIntFieldDefinition : FieldDefinition<int?>
    {
        public NullableIntFieldDefinition(Type entityType, string name, int? defaultValue = default(int?), string format = null)
            : base(entityType, name, defaultValue, 4) { this.Format = format; }

        public string Format { get; private set; }

        public override string GetCoercedValue(IEntity entity, FieldDefinitionValueTypes type = FieldDefinitionValueTypes.Current)
        {
            var accessor = this.GetFieldAccessor(entity);
            switch (type)
            {
                case FieldDefinitionValueTypes.Current:
                    return accessor.Value.HasValue ? this.ConvertToString(accessor.Value) : this.ConvertToString(this.DefaultValue);
                case FieldDefinitionValueTypes.Original:
                    return accessor.OriginalValue.HasValue ? this.ConvertToString(accessor.OriginalValue) : this.ConvertToString(this.DefaultValue);
                case FieldDefinitionValueTypes.Default:
                default:
                    return this.ConvertToString(this.DefaultValue);
            }
        }

        public override void SetCoercedValue(IEntity entity, string value, FieldDefinitionValueTypes type = FieldDefinitionValueTypes.Current)
        {
            var accessor = this.GetFieldAccessor(entity);
            switch (type)
            {
                case FieldDefinitionValueTypes.Current:
                    accessor.Value = DataHelper.ToNullableInt(value);
                    break;
                case FieldDefinitionValueTypes.Original:
                    accessor.OriginalValue = DataHelper.ToNullableInt(value);
                    break;
                case FieldDefinitionValueTypes.Default:
                    break;
            }
        }

        public override void HydrateFrom(IEntity entity, IDataReader reader, int index)
        {
            this.LoadValue(entity, reader.GetNullableInt(index));
        }

        public override SqlDbType GetSqlDbType()
        {
            return SqlDbType.Int;
        }

        protected string ConvertToString(int? value)
        {
            return value.HasValue ? value.Value.ToString(this.Format) : null;
        }

        public override object CoerceValueIntoType(string value)
        {
            return DataHelper.ToNullableInt(value);
        }
    }

    #endregion

    #region Long

    public class LongFieldDefinition : FieldDefinition<long>
    {
        public LongFieldDefinition(Type entityType, string name, long defaultValue = default(long), string format = null)
            : base(entityType, name, defaultValue, 8) { this.Format = format; }

        public string Format { get; private set; }

        public override string GetCoercedValue(IEntity entity, FieldDefinitionValueTypes type = FieldDefinitionValueTypes.Current)
        {
            var accessor = this.GetFieldAccessor(entity);
            switch (type)
            {
                case FieldDefinitionValueTypes.Current:
                    return accessor.Value.ToString(this.Format);
                case FieldDefinitionValueTypes.Original:
                    return accessor.OriginalValue.ToString(this.Format);
                case FieldDefinitionValueTypes.Default:
                default:
                    return this.DefaultValue.ToString(this.Format);
            }
        }

        public override void SetCoercedValue(IEntity entity, string value, FieldDefinitionValueTypes type = FieldDefinitionValueTypes.Current)
        {
            var accessor = this.GetFieldAccessor(entity);
            switch (type)
            {
                case FieldDefinitionValueTypes.Current:
                    accessor.Value = DataHelper.ToLong(value, this.DefaultValue);
                    break;
                case FieldDefinitionValueTypes.Original:
                    accessor.OriginalValue = DataHelper.ToLong(value, this.DefaultValue);
                    break;
                case FieldDefinitionValueTypes.Default:
                    break;
            }
        }

        public override void HydrateFrom(IEntity entity, IDataReader reader, int index)
        {
            this.LoadValue(entity, reader.GetLong(index));
        }

        public override SqlDbType GetSqlDbType()
        {
            return SqlDbType.BigInt;
        }

        public override object CoerceValueIntoType(string value)
        {
            return DataHelper.ToLong(value, this.DefaultValue);
        }
    }

    #endregion

    #region NullableLong

    public class NullableLongFieldDefinition : FieldDefinition<long?>
    {
        public NullableLongFieldDefinition(Type entityType, string name, long? defaultValue = default(long?), string format = null)
            : base(entityType, name, defaultValue, 8) { this.Format = format; }

        public string Format { get; private set; }

        public override string GetCoercedValue(IEntity entity, FieldDefinitionValueTypes type = FieldDefinitionValueTypes.Current)
        {
            var accessor = this.GetFieldAccessor(entity);
            switch (type)
            {
                case FieldDefinitionValueTypes.Current:
                    return accessor.Value.HasValue ? this.ConvertToString(accessor.Value) : this.ConvertToString(this.DefaultValue);
                case FieldDefinitionValueTypes.Original:
                    return accessor.OriginalValue.HasValue ? this.ConvertToString(accessor.OriginalValue) : this.ConvertToString(this.DefaultValue);
                case FieldDefinitionValueTypes.Default:
                default:
                    return this.ConvertToString(this.DefaultValue);
            }
        }

        public override void SetCoercedValue(IEntity entity, string value, FieldDefinitionValueTypes type = FieldDefinitionValueTypes.Current)
        {
            var accessor = this.GetFieldAccessor(entity);
            switch (type)
            {
                case FieldDefinitionValueTypes.Current:
                    accessor.Value = DataHelper.ToNullableLong(value);
                    break;
                case FieldDefinitionValueTypes.Original:
                    accessor.OriginalValue = DataHelper.ToNullableLong(value);
                    break;
                case FieldDefinitionValueTypes.Default:
                    break;
            }
        }

        public override void HydrateFrom(IEntity entity, IDataReader reader, int index)
        {
            this.LoadValue(entity, reader.GetNullableLong(index));
        }

        public override SqlDbType GetSqlDbType()
        {
            return SqlDbType.BigInt;
        }

        protected string ConvertToString(long? value)
        {
            return value.HasValue ? value.Value.ToString(this.Format) : null;
        }

        public override object CoerceValueIntoType(string value)
        {
            return DataHelper.ToNullableLong(value);
        }
    }

    #endregion

    #region Decimal

    public class DecimalFieldDefinition : FieldDefinition<decimal>
    {
        public DecimalFieldDefinition(Type entityType, string name, decimal defaultValue = default(decimal), string format = null, int? size = null)
            : base(entityType, name, defaultValue, size) { this.Format = format; }

        public string Format { get; private set; }

        public override string GetCoercedValue(IEntity entity, FieldDefinitionValueTypes type = FieldDefinitionValueTypes.Current)
        {
            var accessor = this.GetFieldAccessor(entity);
            switch (type)
            {
                case FieldDefinitionValueTypes.Current:
                    return accessor.Value.ToString(this.Format);
                case FieldDefinitionValueTypes.Original:
                    return accessor.OriginalValue.ToString(this.Format);
                case FieldDefinitionValueTypes.Default:
                default:
                    return this.DefaultValue.ToString(this.Format);
            }
        }

        public override void SetCoercedValue(IEntity entity, string value, FieldDefinitionValueTypes type = FieldDefinitionValueTypes.Current)
        {
            var accessor = this.GetFieldAccessor(entity);
            switch (type)
            {
                case FieldDefinitionValueTypes.Current:
                    accessor.Value = DataHelper.ToDecimal(value, this.DefaultValue);
                    break;
                case FieldDefinitionValueTypes.Original:
                    accessor.OriginalValue = DataHelper.ToDecimal(value, this.DefaultValue);
                    break;
                case FieldDefinitionValueTypes.Default:
                    break;
            }
        }

        public override void HydrateFrom(IEntity entity, IDataReader reader, int index)
        {
            this.LoadValue(entity, reader.GetDecimal(index));
        }

        public override SqlDbType GetSqlDbType()
        {
            return SqlDbType.Decimal;
        }

        public override object CoerceValueIntoType(string value)
        {
            return DataHelper.ToDecimal(value, this.DefaultValue);
        }
    }

    #endregion

    #region NullableDecimal

    public class NullableDecimalFieldDefinition : FieldDefinition<decimal?>
    {
        public NullableDecimalFieldDefinition(Type entityType, string name, decimal? defaultValue = default(decimal?), string format = null, int? size = null)
            : base(entityType, name, defaultValue, size) { this.Format = format; }

        public string Format { get; private set; }

        public override string GetCoercedValue(IEntity entity, FieldDefinitionValueTypes type = FieldDefinitionValueTypes.Current)
        {
            var accessor = this.GetFieldAccessor(entity);
            switch (type)
            {
                case FieldDefinitionValueTypes.Current:
                    return accessor.Value.HasValue ? this.ConvertToString(accessor.Value) : this.ConvertToString(this.DefaultValue);
                case FieldDefinitionValueTypes.Original:
                    return accessor.OriginalValue.HasValue ? this.ConvertToString(accessor.OriginalValue) : this.ConvertToString(this.DefaultValue);
                case FieldDefinitionValueTypes.Default:
                default:
                    return this.ConvertToString(this.DefaultValue);
            }
        }

        public override void SetCoercedValue(IEntity entity, string value, FieldDefinitionValueTypes type = FieldDefinitionValueTypes.Current)
        {
            var accessor = this.GetFieldAccessor(entity);
            switch (type)
            {
                case FieldDefinitionValueTypes.Current:
                    accessor.Value = DataHelper.ToNullableDecimal(value);
                    break;
                case FieldDefinitionValueTypes.Original:
                    accessor.OriginalValue = DataHelper.ToNullableDecimal(value);
                    break;
                case FieldDefinitionValueTypes.Default:
                    break;
            }
        }

        public override void HydrateFrom(IEntity entity, IDataReader reader, int index)
        {
            this.LoadValue(entity, reader.GetNullableDecimal(index));
        }

        public override SqlDbType GetSqlDbType()
        {
            return SqlDbType.Decimal;
        }

        protected string ConvertToString(decimal? value)
        {
            return value.HasValue ? value.Value.ToString(this.Format) : null;
        }

        public override object CoerceValueIntoType(string value)
        {
            return DataHelper.ToNullableDecimal(value);
        }
    }

    #endregion

    #region Float

    public class FloatFieldDefinition : FieldDefinition<float>
    {
        public FloatFieldDefinition(Type entityType, string name, float defaultValue = default(float), string format = null, int? size = null)
            : base(entityType, name, defaultValue, size) { this.Format = format; }

        public string Format { get; private set; }

        public override string GetCoercedValue(IEntity entity, FieldDefinitionValueTypes type = FieldDefinitionValueTypes.Current)
        {
            var accessor = this.GetFieldAccessor(entity);
            switch (type)
            {
                case FieldDefinitionValueTypes.Current:
                    return accessor.Value.ToString(this.Format);
                case FieldDefinitionValueTypes.Original:
                    return accessor.OriginalValue.ToString(this.Format);
                case FieldDefinitionValueTypes.Default:
                default:
                    return this.DefaultValue.ToString(this.Format);
            }
        }

        public override void SetCoercedValue(IEntity entity, string value, FieldDefinitionValueTypes type = FieldDefinitionValueTypes.Current)
        {
            var accessor = this.GetFieldAccessor(entity);
            switch (type)
            {
                case FieldDefinitionValueTypes.Current:
                    accessor.Value = DataHelper.ToFloat(value, this.DefaultValue);
                    break;
                case FieldDefinitionValueTypes.Original:
                    accessor.OriginalValue = DataHelper.ToFloat(value, this.DefaultValue);
                    break;
                case FieldDefinitionValueTypes.Default:
                    break;
            }
        }

        public override void HydrateFrom(IEntity entity, IDataReader reader, int index)
        {
            this.LoadValue(entity, reader.GetFloat(index));
        }

        public override SqlDbType GetSqlDbType()
        {
            return SqlDbType.Float;
        }

        public override object CoerceValueIntoType(string value)
        {
            return DataHelper.ToFloat(value, this.DefaultValue);
        }
    }

    #endregion

    #region NullableFloat

    public class NullableFloatFieldDefinition : FieldDefinition<float?>
    {
        public NullableFloatFieldDefinition(Type entityType, string name, float? defaultValue = default(float?), string format = null, int? size = null)
            : base(entityType, name, defaultValue, size) { this.Format = format; }

        public string Format { get; private set; }

        public override string GetCoercedValue(IEntity entity, FieldDefinitionValueTypes type = FieldDefinitionValueTypes.Current)
        {
            var accessor = this.GetFieldAccessor(entity);
            switch (type)
            {
                case FieldDefinitionValueTypes.Current:
                    return accessor.Value.HasValue ? this.ConvertToString(accessor.Value) : this.ConvertToString(this.DefaultValue);
                case FieldDefinitionValueTypes.Original:
                    return accessor.OriginalValue.HasValue ? this.ConvertToString(accessor.OriginalValue) : this.ConvertToString(this.DefaultValue);
                case FieldDefinitionValueTypes.Default:
                default:
                    return this.ConvertToString(this.DefaultValue);
            }
        }

        public override void SetCoercedValue(IEntity entity, string value, FieldDefinitionValueTypes type = FieldDefinitionValueTypes.Current)
        {
            var accessor = this.GetFieldAccessor(entity);
            switch (type)
            {
                case FieldDefinitionValueTypes.Current:
                    accessor.Value = DataHelper.ToNullableFloat(value);
                    break;
                case FieldDefinitionValueTypes.Original:
                    accessor.OriginalValue = DataHelper.ToNullableFloat(value);
                    break;
                case FieldDefinitionValueTypes.Default:
                    break;
            }
        }

        public override void HydrateFrom(IEntity entity, IDataReader reader, int index)
        {
            this.LoadValue(entity, reader.GetNullableFloat(index));
        }

        public override SqlDbType GetSqlDbType()
        {
            return SqlDbType.Float;
        }

        protected string ConvertToString(float? value)
        {
            return value.HasValue ? value.Value.ToString(this.Format) : null;
        }

        public override object CoerceValueIntoType(string value)
        {
            return DataHelper.ToNullableFloat(value);
        }
    }

    #endregion

    #region Double

    public class DoubleFieldDefinition : FieldDefinition<double>
    {
        public DoubleFieldDefinition(Type entityType, string name, double defaultValue = default(double), string format = null, int? size = null)
            : base(entityType, name, defaultValue, size) { this.Format = format; }

        public string Format { get; private set; }

        public override string GetCoercedValue(IEntity entity, FieldDefinitionValueTypes type = FieldDefinitionValueTypes.Current)
        {
            var accessor = this.GetFieldAccessor(entity);
            switch (type)
            {
                case FieldDefinitionValueTypes.Current:
                    return accessor.Value.ToString(this.Format);
                case FieldDefinitionValueTypes.Original:
                    return accessor.OriginalValue.ToString(this.Format);
                case FieldDefinitionValueTypes.Default:
                default:
                    return this.DefaultValue.ToString(this.Format);
            }
        }

        public override void SetCoercedValue(IEntity entity, string value, FieldDefinitionValueTypes type = FieldDefinitionValueTypes.Current)
        {
            var accessor = this.GetFieldAccessor(entity);
            switch (type)
            {
                case FieldDefinitionValueTypes.Current:
                    accessor.Value = DataHelper.ToDouble(value, this.DefaultValue);
                    break;
                case FieldDefinitionValueTypes.Original:
                    accessor.OriginalValue = DataHelper.ToDouble(value, this.DefaultValue);
                    break;
                case FieldDefinitionValueTypes.Default:
                    break;
            }
        }

        public override void HydrateFrom(IEntity entity, IDataReader reader, int index)
        {
            this.LoadValue(entity, reader.GetDouble(index));
        }

        public override SqlDbType GetSqlDbType()
        {
            return SqlDbType.Float;
        }

        public override object CoerceValueIntoType(string value)
        {
            return DataHelper.ToDouble(value, this.DefaultValue);
        }
    }

    #endregion

    #region NullableDouble

    public class NullableDoubleFieldDefinition : FieldDefinition<double?>
    {
        public NullableDoubleFieldDefinition(Type entityType, string name, double? defaultValue = default(double?), string format = null, int? size = null)
            : base(entityType, name, defaultValue, size) { this.Format = format; }

        public string Format { get; private set; }

        public override string GetCoercedValue(IEntity entity, FieldDefinitionValueTypes type = FieldDefinitionValueTypes.Current)
        {
            var accessor = this.GetFieldAccessor(entity);
            switch (type)
            {
                case FieldDefinitionValueTypes.Current:
                    return accessor.Value.HasValue ? this.ConvertToString(accessor.Value) : this.ConvertToString(this.DefaultValue);
                case FieldDefinitionValueTypes.Original:
                    return accessor.OriginalValue.HasValue ? this.ConvertToString(accessor.OriginalValue) : this.ConvertToString(this.DefaultValue);
                case FieldDefinitionValueTypes.Default:
                default:
                    return this.ConvertToString(this.DefaultValue);
            }
        }

        public override void SetCoercedValue(IEntity entity, string value, FieldDefinitionValueTypes type = FieldDefinitionValueTypes.Current)
        {
            var accessor = this.GetFieldAccessor(entity);
            switch (type)
            {
                case FieldDefinitionValueTypes.Current:
                    accessor.Value = DataHelper.ToNullableDouble(value);
                    break;
                case FieldDefinitionValueTypes.Original:
                    accessor.OriginalValue = DataHelper.ToNullableDouble(value);
                    break;
                case FieldDefinitionValueTypes.Default:
                    break;
            }
        }

        public override void HydrateFrom(IEntity entity, IDataReader reader, int index)
        {
            this.LoadValue(entity, reader.GetNullableDouble(index));
        }

        public override SqlDbType GetSqlDbType()
        {
            return SqlDbType.Float;
        }

        protected string ConvertToString(double? value)
        {
            return value.HasValue ? value.Value.ToString(this.Format) : null;
        }

        public override object CoerceValueIntoType(string value)
        {
            return DataHelper.ToNullableDouble(value);
        }
    }

    #endregion

    #region DateTime

    public class DateTimeFieldDefinition : FieldDefinition<DateTime>
    {
        public DateTimeFieldDefinition(Type entityType, string name, DateTime defaultValue = default(DateTime), string format = null)
            : base(entityType, name, defaultValue, 8) { this.Format = format; }

        public string Format { get; private set; }

        public override string GetCoercedValue(IEntity entity, FieldDefinitionValueTypes type = FieldDefinitionValueTypes.Current)
        {
            var accessor = this.GetFieldAccessor(entity);
            switch (type)
            {
                case FieldDefinitionValueTypes.Current:
                    return accessor.Value.ToString(this.Format);
                case FieldDefinitionValueTypes.Original:
                    return accessor.OriginalValue.ToString(this.Format);
                case FieldDefinitionValueTypes.Default:
                default:
                    return this.DefaultValue.ToString(this.Format);
            }
        }

        public override void SetCoercedValue(IEntity entity, string value, FieldDefinitionValueTypes type = FieldDefinitionValueTypes.Current)
        {
            var accessor = this.GetFieldAccessor(entity);
            switch (type)
            {
                case FieldDefinitionValueTypes.Current:
                    accessor.Value = DataHelper.ToDateTime(value, this.DefaultValue);
                    break;
                case FieldDefinitionValueTypes.Original:
                    accessor.OriginalValue = DataHelper.ToDateTime(value, this.DefaultValue);
                    break;
                case FieldDefinitionValueTypes.Default:
                    break;
            }
        }

        public override void HydrateFrom(IEntity entity, IDataReader reader, int index)
        {
            this.LoadValue(entity, reader.GetDateTime(index));
        }

        public override SqlDbType GetSqlDbType()
        {
            return SqlDbType.DateTime;
        }

        public override object CoerceValueIntoType(string value)
        {
            return DataHelper.ToDateTime(value, this.DefaultValue);
        }
    }

    #endregion

    #region NullableDateTime

    public class NullableDateTimeFieldDefinition : FieldDefinition<DateTime?>
    {
        public NullableDateTimeFieldDefinition(Type entityType, string name, DateTime? defaultValue = default(DateTime?), string format = null)
            : base(entityType, name, defaultValue, 8) { this.Format = format; }

        public string Format { get; private set; }

        public override string GetCoercedValue(IEntity entity, FieldDefinitionValueTypes type = FieldDefinitionValueTypes.Current)
        {
            var accessor = this.GetFieldAccessor(entity);
            switch (type)
            {
                case FieldDefinitionValueTypes.Current:
                    return accessor.Value.HasValue ? this.ConvertToString(accessor.Value) : this.ConvertToString(this.DefaultValue);
                case FieldDefinitionValueTypes.Original:
                    return accessor.OriginalValue.HasValue ? this.ConvertToString(accessor.OriginalValue) : this.ConvertToString(this.DefaultValue);
                case FieldDefinitionValueTypes.Default:
                default:
                    return this.ConvertToString(this.DefaultValue);
            }
        }

        public override void SetCoercedValue(IEntity entity, string value, FieldDefinitionValueTypes type = FieldDefinitionValueTypes.Current)
        {
            var accessor = this.GetFieldAccessor(entity);
            switch (type)
            {
                case FieldDefinitionValueTypes.Current:
                    accessor.Value = DataHelper.ToNullableDateTime(value);
                    break;
                case FieldDefinitionValueTypes.Original:
                    accessor.OriginalValue = DataHelper.ToNullableDateTime(value);
                    break;
                case FieldDefinitionValueTypes.Default:
                    break;
            }
        }

        public override void HydrateFrom(IEntity entity, IDataReader reader, int index)
        {
            this.LoadValue(entity, reader.GetNullableDateTime(index));
        }

        public override SqlDbType GetSqlDbType()
        {
            return SqlDbType.DateTime;
        }

        protected string ConvertToString(DateTime? value)
        {
            return value.HasValue ? value.Value.ToString(this.Format) : null;
        }

        public override object CoerceValueIntoType(string value)
        {
            return DataHelper.ToNullableDateTime(value);
        }
    }

    #endregion

    #region TimeSpan

    public class TimeSpanFieldDefinition : FieldDefinition<TimeSpan>
    {
        public TimeSpanFieldDefinition(Type entityType, string name, TimeSpan defaultValue = default(TimeSpan), string format = null)
            : base(entityType, name, defaultValue, 8) { this.Format = format; }

        public string Format { get; private set; }

        public override string GetCoercedValue(IEntity entity, FieldDefinitionValueTypes type = FieldDefinitionValueTypes.Current)
        {
            var accessor = this.GetFieldAccessor(entity);
            switch (type)
            {
                case FieldDefinitionValueTypes.Current:
                    return accessor.Value.ToString(this.Format);
                case FieldDefinitionValueTypes.Original:
                    return accessor.OriginalValue.ToString(this.Format);
                case FieldDefinitionValueTypes.Default:
                default:
                    return this.DefaultValue.ToString(this.Format);
            }
        }

        public override void SetCoercedValue(IEntity entity, string value, FieldDefinitionValueTypes type = FieldDefinitionValueTypes.Current)
        {
            var accessor = this.GetFieldAccessor(entity);
            switch (type)
            {
                case FieldDefinitionValueTypes.Current:
                    accessor.Value = DataHelper.ToTimeSpan(value, this.DefaultValue);
                    break;
                case FieldDefinitionValueTypes.Original:
                    accessor.OriginalValue = DataHelper.ToTimeSpan(value, this.DefaultValue);
                    break;
                case FieldDefinitionValueTypes.Default:
                    break;
            }
        }

        public override void HydrateFrom(IEntity entity, IDataReader reader, int index)
        {
            this.LoadValue(entity, reader.GetTimeSpan(index));
        }

        public override SqlDbType GetSqlDbType()
        {
            return SqlDbType.BigInt;
        }

        public override object CoerceValueIntoType(string value)
        {
            return DataHelper.ToTimeSpan(value, this.DefaultValue);
        }
    }

    #endregion

    #region NullableTimeSpan

    public class NullableTimeSpanFieldDefinition : FieldDefinition<TimeSpan?>
    {
        public NullableTimeSpanFieldDefinition(Type entityType, string name, TimeSpan? defaultValue = default(TimeSpan?), string format = null)
            : base(entityType, name, defaultValue, 8) { this.Format = format; }

        public string Format { get; private set; }

        public override string GetCoercedValue(IEntity entity, FieldDefinitionValueTypes type = FieldDefinitionValueTypes.Current)
        {
            var accessor = this.GetFieldAccessor(entity);
            switch (type)
            {
                case FieldDefinitionValueTypes.Current:
                    return accessor.Value.HasValue ? this.ConvertToString(accessor.Value) : this.ConvertToString(this.DefaultValue);
                case FieldDefinitionValueTypes.Original:
                    return accessor.OriginalValue.HasValue ? this.ConvertToString(accessor.OriginalValue) : this.ConvertToString(this.DefaultValue);
                case FieldDefinitionValueTypes.Default:
                default:
                    return this.ConvertToString(this.DefaultValue);
            }
        }

        public override void SetCoercedValue(IEntity entity, string value, FieldDefinitionValueTypes type = FieldDefinitionValueTypes.Current)
        {
            var accessor = this.GetFieldAccessor(entity);
            switch (type)
            {
                case FieldDefinitionValueTypes.Current:
                    accessor.Value = DataHelper.ToNullableTimeSpan(value);
                    break;
                case FieldDefinitionValueTypes.Original:
                    accessor.OriginalValue = DataHelper.ToNullableTimeSpan(value);
                    break;
                case FieldDefinitionValueTypes.Default:
                    break;
            }
        }

        public override void HydrateFrom(IEntity entity, IDataReader reader, int index)
        {
            this.LoadValue(entity, reader.GetNullableTimeSpan(index));
        }

        public override SqlDbType GetSqlDbType()
        {
            return SqlDbType.BigInt;
        }

        protected string ConvertToString(TimeSpan? value)
        {
            return value.HasValue ? value.Value.ToString(this.Format) : null;
        }

        public override object CoerceValueIntoType(string value)
        {
            return DataHelper.ToNullableTimeSpan(value);
        }
    }

    #endregion

    #region Guid

    public class GuidFieldDefinition : FieldDefinition<Guid>
    {
        public GuidFieldDefinition(Type entityType, string name, Guid defaultValue = default(Guid), string format = null)
            : base(entityType, name, defaultValue, 16) { this.Format = format; }

        public string Format { get; private set; }

        public override string GetCoercedValue(IEntity entity, FieldDefinitionValueTypes type = FieldDefinitionValueTypes.Current)
        {
            var accessor = this.GetFieldAccessor(entity);
            switch (type)
            {
                case FieldDefinitionValueTypes.Current:
                    return accessor.Value.ToString(this.Format);
                case FieldDefinitionValueTypes.Original:
                    return accessor.OriginalValue.ToString(this.Format);
                case FieldDefinitionValueTypes.Default:
                default:
                    return this.DefaultValue.ToString(this.Format);
            }
        }

        public override void SetCoercedValue(IEntity entity, string value, FieldDefinitionValueTypes type = FieldDefinitionValueTypes.Current)
        {
            var accessor = this.GetFieldAccessor(entity);
            switch (type)
            {
                case FieldDefinitionValueTypes.Current:
                    accessor.Value = DataHelper.ToGuid(value, this.DefaultValue);
                    break;
                case FieldDefinitionValueTypes.Original:
                    accessor.OriginalValue = DataHelper.ToGuid(value, this.DefaultValue);
                    break;
                case FieldDefinitionValueTypes.Default:
                    break;
            }
        }

        public override void HydrateFrom(IEntity entity, IDataReader reader, int index)
        {
            this.LoadValue(entity, reader.GetGuid(index));
        }

        public override SqlDbType GetSqlDbType()
        {
            return SqlDbType.UniqueIdentifier;
        }

        public override object CoerceValueIntoType(string value)
        {
            return DataHelper.ToGuid(value, this.DefaultValue);
        }
    }

    #endregion

    #region NullableGuid

    public class NullableGuidFieldDefinition : FieldDefinition<Guid?>
    {
        public NullableGuidFieldDefinition(Type entityType, string name, Guid? defaultValue = default(Guid?), string format = null)
            : base(entityType, name, defaultValue, 16) { this.Format = format; }

        public string Format { get; private set; }

        public override string GetCoercedValue(IEntity entity, FieldDefinitionValueTypes type = FieldDefinitionValueTypes.Current)
        {
            var accessor = this.GetFieldAccessor(entity);
            switch (type)
            {
                case FieldDefinitionValueTypes.Current:
                    return accessor.Value.HasValue ? this.ConvertToString(accessor.Value) : this.ConvertToString(this.DefaultValue);
                case FieldDefinitionValueTypes.Original:
                    return accessor.OriginalValue.HasValue ? this.ConvertToString(accessor.OriginalValue) : this.ConvertToString(this.DefaultValue);
                case FieldDefinitionValueTypes.Default:
                default:
                    return this.ConvertToString(this.DefaultValue);
            }
        }

        public override void SetCoercedValue(IEntity entity, string value, FieldDefinitionValueTypes type = FieldDefinitionValueTypes.Current)
        {
            var accessor = this.GetFieldAccessor(entity);
            switch (type)
            {
                case FieldDefinitionValueTypes.Current:
                    accessor.Value = DataHelper.ToNullableGuid(value);
                    break;
                case FieldDefinitionValueTypes.Original:
                    accessor.OriginalValue = DataHelper.ToNullableGuid(value);
                    break;
                case FieldDefinitionValueTypes.Default:
                    break;
            }
        }

        public override void HydrateFrom(IEntity entity, IDataReader reader, int index)
        {
            this.LoadValue(entity, reader.GetNullableGuid(index));
        }

        public override SqlDbType GetSqlDbType()
        {
            return SqlDbType.UniqueIdentifier;
        }

        protected string ConvertToString(Guid? value)
        {
            return value.HasValue ? value.Value.ToString(this.Format) : null;
        }

        public override object CoerceValueIntoType(string value)
        {
            return DataHelper.ToNullableGuid(value);
        }
    }

    #endregion
}
