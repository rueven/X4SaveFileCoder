﻿using System.Collections.Generic;
using System.Linq;

namespace Power.Framework.FieldDefinitionReaders
{
    public class ElementAtFieldDefinitionReader : IFieldDefinitionReader<IEnumerable<string>>
    {
        public FieldDefinition FieldDefinition { get; set; }
        public int Index { get; set; }

        public string GetValue(IEnumerable<string> source)
        {
            return source
                .ElementAt(this.Index)
                ?.Trim();
        }
    }
}
