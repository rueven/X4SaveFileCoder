﻿using System.Data;

namespace Power.Framework.FieldDefinitionReaders
{
    public class DataRowFieldDefinitionReader : IFieldDefinitionReader<System.Data.DataRow>
    {
        public FieldDefinition FieldDefinition { get; set; }
        public DataColumn Column { get; set; }

        public string GetValue(DataRow row)
        {
            return row[this.Column]
                ?.ToString()
                ?.Trim();
        }
    }
}
