﻿using System.Collections.Generic;

namespace Power.Framework
{
    public interface IEntity
    {
        object ReferenceId { get; }
        IReadOnlyDictionary<FieldDefinition, FieldAccessor> Fields { get; }
    }
}
