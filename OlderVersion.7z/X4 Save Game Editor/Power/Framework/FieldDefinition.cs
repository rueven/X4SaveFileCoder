﻿using System;
using System.Collections.Generic;

namespace Power.Framework
{
    public abstract class FieldDefinition
    {
        public FieldDefinition(Type entityType, string name, Type type, int? size)
        {
            this.EntityType = entityType;
            this.Name = name;
            this.Type = type;
            this.Size = size;
        }

        public Type EntityType { get; private set; }
        public string Name { get; private set; }
        public Type Type { get; private set; }
        public int? Size { get; private set; }

        public FieldAccessor FindFieldAccessor(IDictionary<FieldDefinition, FieldAccessor> fields)
        {
            if (fields == null) { return null; }
            return fields.ContainsKey(this) ? fields[this] : null;
        }

        public abstract void SetBoxedValue(IEntity entity, object value, FieldDefinitionValueTypes type = FieldDefinitionValueTypes.Current);
        public abstract object GetBoxedValue(IEntity entity, FieldDefinitionValueTypes type = FieldDefinitionValueTypes.Current);

        public abstract void SetCoercedValue(IEntity entity, string value, FieldDefinitionValueTypes type = FieldDefinitionValueTypes.Current);
        public abstract string GetCoercedValue(IEntity entity, FieldDefinitionValueTypes type = FieldDefinitionValueTypes.Current);

        public void HydrateFrom(IEntity entity, System.Data.IDataReader reader, string name)
        {
            var ordinal = reader.GetOrdinal(name);
            this.HydrateFrom(entity, reader, ordinal);
        }
        public abstract void HydrateFrom(IEntity entity, System.Data.IDataReader reader, int index);
        public void HydrateFrom(IEntity entity, System.Data.SqlClient.SqlCommand command, string parameterName)
        {
            var parameter = command.Parameters[parameterName];
            this.SetBoxedValue(entity, parameter.Value);
        }

        public System.Data.SqlClient.SqlParameter WriteTo(IEntity entity, System.Data.SqlClient.SqlCommand command, string parameterName)
        {
            var value = this.GetBoxedValue(entity);
            var output = command.Parameters[parameterName];
            if (this.Size.HasValue)
            {
                output = command
                    .Parameters
                    .Add(parameterName, this.GetSqlDbType(), this.Size.Value);
            }
            else
            {
                output = command
                    .Parameters
                    .Add(parameterName, this.GetSqlDbType());
            }
            output.Value = value;
            return output;
        }

        public abstract System.Data.SqlDbType GetSqlDbType();

        public virtual bool IsValid(IEntity entity, FieldDefinitionValueTypes type = FieldDefinitionValueTypes.Current) { return true; }

        public abstract bool IsDefaultValue(IEntity entity);

        public abstract object CoerceValueIntoType(string value);

        public abstract bool IsChanged(IEntity entity);
    }

    public abstract class FieldDefinition<T> : FieldDefinition
    {
        public FieldDefinition(Type entityType, string name, T defaultValue = default(T), int? size = null)
            : base(entityType, name, typeof(T), size)
        {
            this.DefaultValue = defaultValue;
        }

        public T DefaultValue { get; private set; }

        protected FieldAccessor<T> GetFieldAccessor(IEntity entity)
        {
            if (entity == null) { throw new ArgumentNullException("entity"); }
            if (entity.Fields.ContainsKey(this).Equals(false)) { throw new ArgumentException(this.Name + " is not defined in the given entity", "entity"); }
            return entity.Fields[this] as FieldAccessor<T>;
        }

        public sealed override void SetBoxedValue(IEntity entity, object value, FieldDefinitionValueTypes type = FieldDefinitionValueTypes.Current)
        {
            var accessor = this.GetFieldAccessor(entity);
            switch (type)
            {
                case FieldDefinitionValueTypes.Current:
                    accessor.Value = (T)value;
                    break;
                case FieldDefinitionValueTypes.Original:
                    accessor.OriginalValue = (T)value;
                    break;
                default:
                    break;
            }
        }

        public sealed override object GetBoxedValue(IEntity entity, FieldDefinitionValueTypes type = FieldDefinitionValueTypes.Current)
        {
            var accessor = this.GetFieldAccessor(entity);
            switch (type)
            {
                case FieldDefinitionValueTypes.Current:
                    return accessor.Value;
                case FieldDefinitionValueTypes.Original:
                    return accessor.OriginalValue;
                default:
                    return this.DefaultValue;
            }
        }

        public void SetValue(IEntity entity, T value, FieldDefinitionValueTypes type = FieldDefinitionValueTypes.Current)
        {
            var accessor = this.GetFieldAccessor(entity);
            switch (type)
            {
                case FieldDefinitionValueTypes.Current:
                    accessor.Value = value;
                    break;
                case FieldDefinitionValueTypes.Original:
                    accessor.OriginalValue = value;
                    break;
                default:
                    break;
            }
        }

        public T GetValue(IEntity entity, FieldDefinitionValueTypes type = FieldDefinitionValueTypes.Current)
        {
            var accessor = this.GetFieldAccessor(entity);
            switch (type)
            {
                case FieldDefinitionValueTypes.Current:
                    return accessor.Value;
                case FieldDefinitionValueTypes.Original:
                    return accessor.OriginalValue;
                default:
                    return this.DefaultValue;
            }
        }

        public override bool IsDefaultValue(IEntity entity)
        {
            var currentValue = this.GetValue(entity);
            var defaultValue = this.GetValue(entity, FieldDefinitionValueTypes.Default);
            var result = Comparer<T>.Default.Compare(currentValue, defaultValue);
            return result == 0;
        }

        public FieldConversionResult<T> CreateFieldConversionResult(string value)
        {
            var result = (T)this.CoerceValueIntoType(value);
            var isDefaultValue = Comparer<T>.Default.Compare(result, this.DefaultValue) == 0;
            return isDefaultValue ? FieldConversionResult<T>.CreateFail() : FieldConversionResult<T>.CreateSuccess(result);
        }

        public override bool IsChanged(IEntity entity)
        {
            var currentValue = this.GetValue(entity);
            var originalValue = this.GetValue(entity, FieldDefinitionValueTypes.Original);
            var result = Comparer<T>.Default.Compare(currentValue, originalValue);
            return result != 0;
        }
    }
}
