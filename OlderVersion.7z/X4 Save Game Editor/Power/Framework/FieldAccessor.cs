﻿namespace Power.Framework
{
    public abstract class FieldAccessor { }

    public class FieldAccessor<T> : FieldAccessor
    {
        public T Value { get; set; }
        public T OriginalValue { get; set; }
    }
}
