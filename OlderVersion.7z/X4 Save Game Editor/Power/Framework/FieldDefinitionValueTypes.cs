﻿namespace Power.Framework
{
    public enum FieldDefinitionValueTypes
    {
        Default,
        Original,
        Current
    }
}
