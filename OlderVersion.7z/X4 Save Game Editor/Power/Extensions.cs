﻿using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using Power.Framework;
using Power.Types;
using Power.Utilities;

namespace System
{
    public static class Extensions
    {
        #region Fields Definition Methods

        /// <summary>
        /// Sets both the original and current value of the property on the entity
        /// </summary>
        /// <param name="definition">The definition of the property</param>
        /// <param name="entity">The entity with the property</param>
        /// <param name="value">The value to be set on the entity</param>
        public static void LoadValue(this FieldDefinition definition, IEntity entity, string value)
        {
            if (definition == null) { throw new ArgumentNullException("definition"); }
            if (entity == null) { throw new ArgumentNullException("entity"); }
            definition.SetCoercedValue(entity, value, FieldDefinitionValueTypes.Original);
            definition.SetCoercedValue(entity, value, FieldDefinitionValueTypes.Current);
        }

        /// <summary>
        /// Sets both the original and current value of the property on the entity
        /// </summary>
        /// <typeparam name="T">The type of the value to be </typeparam>
        /// <param name="definition">The definition of the property</param>
        /// <param name="entity">The entity with the property</param>
        /// <param name="value">The value to be set on the entity</param>
        public static void LoadValue<T>(this FieldDefinition<T> definition, IEntity entity, T value)
        {
            if (definition == null) { throw new ArgumentNullException("definition"); }
            if (entity == null) { throw new ArgumentNullException("entity"); }
            definition.SetValue(entity, value, FieldDefinitionValueTypes.Original);
            definition.SetValue(entity, value, FieldDefinitionValueTypes.Current);
        }

        #endregion

        #region Cache Service Methods

        /// <summary>
        /// Retrieves value from cache based on key. If the value is not in the cache, then the hydrate method is called and the value returned is placed inside the cache for the duration specified in secondsToCacheIfNotExists
        /// </summary>
        /// <typeparam name="T">The type of value being retrieved</typeparam>
        /// <param name="key">The key that the value is stored under</param>
        /// <param name="hydrate">A method that returns the value for the key in the cache if while getting the value, it is determined the value is not present</param>
        /// <param name="secondsToCacheIfNotExists">The seconds to cache the value under the given key if the value does not exists and the hydrate method is called</param>
        /// <returns>The value filed under the key in the cache</returns>
        public static T GetValue<T>(this ISimpleCacheService service, string key, Func<T> hydrate)
        {
            if (service == null) { throw new ArgumentNullException("service"); }
            if (service.ContainsValue<T>(key)) { return service.GetValue<T>(key); }
            var value = hydrate();
            service.SetValue<T>(key, value);
            return value;
        }

        /// <summary>
        /// Retrieves value from cache based on key. If the value is not in the cache, then the hydrate method is called and the value returned is placed inside the cache for the duration specified in secondsToCacheIfNotExists
        /// </summary>
        /// <typeparam name="T">The type of value being retrieved</typeparam>
        /// <param name="key">The key that the value is stored under</param>
        /// <param name="hydrate">A method that returns the value for the key in the cache if while getting the value, it is determined the value is not present</param>
        /// <param name="expiration">A timestamp indicating when this data will expire</param>
        /// <returns>The value filed under the key in the cache</returns>
        public static T GetValue<T>(this ICacheService service, string key, Func<T> hydrate, DateTime expiration)
        {
            if (service == null) { throw new ArgumentNullException("service"); }
            if (service.ContainsValue<T>(key))
            {
                var output = service.GetValue<T>(key);
            }
            var value = hydrate();
            service.SetValue<T>(key, value, expiration);
            return value;
        }

        /// <summary>
        /// Retrieves value from cache based on key. If the value is not in the cache, then the hydrate method is called and the value returned is placed inside the cache for the duration specified in secondsToCacheIfNotExists
        /// </summary>
        /// <typeparam name="T">The type of value being retrieved</typeparam>
        /// <param name="key">The key that the value is stored under</param>
        /// <param name="hydrate">A method that returns the value for the key in the cache if while getting the value, it is determined the value is not present</param>
        /// <param name="expiration">A timespan indicating how long this item will stick around in the cache if not used. Calling get or set will reset the timer</param>
        /// <returns>The value filed under the key in the cache</returns>
        public static T GetValue<T>(this ICacheService service, string key, Func<T> hydrate, TimeSpan expiration)
        {
            if (service == null) { throw new ArgumentNullException("service"); }
            if (service.ContainsValue<T>(key)) { return service.GetValue<T>(key); }
            var value = hydrate();
            service.SetValue<T>(key, value, expiration);
            return value;
        }

        #endregion

        public static string Replace(this string value, string oldValue, string newValue, StringComparison comparison)
        {
            var builder = new StringBuilder();
            var previousIndex = 0;
            var index = value.IndexOf(oldValue, comparison);
            while (index != -1)
            {
                builder.Append(value.Substring(previousIndex, index - previousIndex));
                builder.Append(newValue);
                index += oldValue.Length;
                previousIndex = index;
                index = value.IndexOf(oldValue, index, comparison);
            }
            builder.Append(value.Substring(previousIndex));
            return builder
                .ToString();
        }

        public static IEnumerable<TOut> FilterByType<TIn, TOut>(this IEnumerable<TIn> values)
            where TIn : class where TOut : class
        {
            return values
                .Where(x => x is TOut)
                .Select(x => x as TOut)
                .ToList();
        }

        public static void CopyRowTo(this DataRow source, DataRow destination)
        {
            source
                .Table
                .Columns
                .Iterate(column => destination[column.ColumnName] = source[column.ColumnName]);
        }

        public static void CopyRowsTo(this DataTable source, DataTable destination, Func<DataTable, DataRow> createNewRow = null)
        {
            createNewRow = createNewRow ?? new Func<DataTable, DataRow>((table) => table.NewRow());
            source
                .Rows
                .Iterate(r =>
                {
                    var row = createNewRow(destination);
                    r.CopyRowTo(row);
                    destination
                        .Rows
                        .Add(row);
                });
        }
    }
}
