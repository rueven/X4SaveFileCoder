﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Power.Types;
using Image = System.Drawing.Image;

namespace Power.Utilities
{
    public static class ImageHelper
    {
        public static Image WriteTextOnImage(Image image, string text, System.Drawing.Color textcolor, System.Drawing.Color? textoutlinecolor)
        {
            using (var writer = new TextImageWriter())
            {
                writer.Font = new System.Drawing.Font("Ariel", 14, System.Drawing.FontStyle.Bold);
                writer.HorizontalAlignment = HorizontalAlignments.Center;
                writer.VerticalAlignment = VerticalAlignments.Bottom;
                if (textoutlinecolor.HasValue)
                {
                    writer.TextOutlinePen = new System.Drawing.Pen(textoutlinecolor.Value, 5);
                }
                writer.TextPen = new System.Drawing.Pen(textcolor);
                writer.Padding = 5;
                image = writer.WriteTextOnImage(image, text, true);
            }
            return image;
        }

        public static Image WritePrettyTextOnImage(Image image, string text, string fontname, int? fontsize, System.Drawing.Color? outline, System.Drawing.Color? uppergradient, System.Drawing.Color? lowergradient, int? outlinewidth)
        {
            fontname = string.IsNullOrEmpty(fontname) ? "impact" : fontname;
            outline = outline ?? System.Drawing.ColorTranslator.FromHtml("#77090C");
            lowergradient = lowergradient ?? System.Drawing.ColorTranslator.FromHtml("#FF6493");
            uppergradient = uppergradient ?? System.Drawing.ColorTranslator.FromHtml("#D00F14");
            outlinewidth = outlinewidth ?? 4;
            using (var graphic = System.Drawing.Graphics.FromImage(image))
            {
                graphic.SmoothingMode = System.Drawing.Drawing2D.SmoothingMode.AntiAlias;
                graphic.PixelOffsetMode = System.Drawing.Drawing2D.PixelOffsetMode.HighQuality;
                using (var format = new System.Drawing.StringFormat() { Alignment = System.Drawing.StringAlignment.Center, LineAlignment = System.Drawing.StringAlignment.Far })
                {
                    using (var font = new System.Drawing.Font(fontname, fontsize ?? 20, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Pixel))
                    {
                        using (var pen = new System.Drawing.Pen(outline.Value, outlinewidth.Value) { LineJoin = System.Drawing.Drawing2D.LineJoin.Round })
                        {
                            var rectangle = new System.Drawing.Rectangle(0, image.Height - font.Height, image.Width, font.Height);
                            using (var brush = new System.Drawing.Drawing2D.LinearGradientBrush(rectangle, lowergradient.Value, uppergradient.Value, 90))
                            {
                                var bounds = new System.Drawing.Rectangle(0, 0, image.Width, image.Height);
                                using (var graphicspath = new System.Drawing.Drawing2D.GraphicsPath())
                                {
                                    graphicspath.AddString
                                    (
                                        text,
                                        font.FontFamily,
                                        (int)font.Style,
                                        fontsize ?? 20,
                                        bounds,
                                        format
                                    );
                                    graphic.DrawPath(pen, graphicspath);
                                    graphic.FillPath(brush, graphicspath);
                                }
                            }
                        }
                    }
                }
            }
            return image;
        }

        public static Image Resize(Image image, int width, int height, System.Drawing.Color backgroundcolor, bool maketransparent, System.Drawing.Color clearingcolor)
        {
            var sourceWidth = image.Width;
            var sourceHeight = image.Height;
            var destX = 0;
            var destY = 0;
            var nPercent = 0f;
            var nPercentW = 0f;
            var nPercentH = 0f;
            nPercentW = ((float)width / (float)sourceWidth);
            nPercentH = ((float)height / (float)sourceHeight);
            nPercent = nPercentH < nPercentW ? nPercentH : nPercentW;
            destX = nPercentH < nPercentW ? System.Convert.ToInt16((width - (sourceWidth * nPercent)) / 2) : System.Convert.ToInt16((height - (sourceHeight * nPercent)) / 2);
            var destWidth = (int)(sourceWidth * nPercent);
            var destHeight = (int)(sourceHeight * nPercent);
            var output = new System.Drawing.Bitmap(width, height);
            output.SetResolution(image.HorizontalResolution, image.VerticalResolution);
            using (var outputgraphic = System.Drawing.Graphics.FromImage(output))
            {
                outputgraphic.Clear(clearingcolor);
                outputgraphic.InterpolationMode = System.Drawing.Drawing2D.InterpolationMode.HighQualityBicubic;
                outputgraphic.DrawImage
                (
                    image,
                    new System.Drawing.Rectangle(destX, destY, destWidth, destHeight),
                    new System.Drawing.Rectangle(0, 0, image.Width - 1, image.Height - 1),
                    System.Drawing.GraphicsUnit.Pixel
                );
            }
            if (maketransparent) { output.MakeTransparent(backgroundcolor); }
            return output;
        }

        public static System.Drawing.Bitmap ConvertToBitmap(this System.Drawing.Image image)
        {
            if (image is System.Drawing.Bitmap) { return (System.Drawing.Bitmap)image; }
            else { return new System.Drawing.Bitmap(image); }
        }

        public static System.Drawing.Image ConvertToImage(byte[] value)
        {
            using (var memorystream = new System.IO.MemoryStream())
            {
                memorystream.Write(value, 0, value.Length);
                return System.Drawing.Image.FromStream(memorystream);
            }
        }

        public static string GetMimeType(this Image image)
        {
            return image
                .RawFormat
                .GetMimeType();
        }

        public static string GetMimeType(this System.Drawing.Imaging.ImageFormat format)
        {
            var match = ImageHelper.GetImageEncoder(format);
            return match == null ? null : match.MimeType;
        }

        public static string GetMimeType(this System.Drawing.Imaging.ImageCodecInfo encoder)
        {
            return encoder.MimeType;
        }

        public static System.Drawing.Imaging.ImageCodecInfo GetImageEncoder(this System.Drawing.Imaging.ImageFormat format)
        {
            var match = System
                .Drawing
                .Imaging
                .ImageCodecInfo
                .GetImageEncoders()
                .FirstOrDefault(x => x.FormatID == format.Guid);
            return match;
        }

        /// <summary>Downloads the image respresented by the url</summary>
        /// <exception cref="System.Exception"></exception>
        /// <returns>An instance of an image object or null</returns>
        public static System.Drawing.Image Download(string url)
        {
            if (string.IsNullOrEmpty(url)) { throw new ArgumentNullException("url"); }
            var request = System.Net.WebRequest.Create(url);
            using (var response = request.GetResponse())
            {
                using (var stream = response.GetResponseStream())
                {
                    return Image.FromStream(stream);
                }
            }
        }
    }
}
