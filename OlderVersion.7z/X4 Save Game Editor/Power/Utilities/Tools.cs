﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Power.Types;

namespace Power.Utilities
{
    /// <summary>
    /// Helper methods that can help with flow control
    /// </summary>
    public static class Tools
    {
        /// <summary>
        /// Return true if all of the values passed in are true
        /// </summary>
        /// <param name="values">The values to check</param>
        /// <returns>Whether or not all values resolved as true</returns>
        public static bool IsAllTrue(params bool?[] values)
        {
            if (values == null || values.Contains(null)) { return false; }
            return Tools.Cumulate<bool>
            (
                (x, y) => x && y,
                true,
                values
            );
        }

        /// <summary>
        /// Return true if any of the values passed in are true
        /// </summary>
        /// <param name="values">The values to check</param>
        /// <returns>Whether or not any values resolved as true</returns>
        public static bool IsAnyTrue(params bool?[] values)
        {
            return Tools.Cumulate<bool>
            (
                (x, y) => x || y,
                false,
                values
            );
        }

        /// <summary>
        /// Adds the given item to the list ands returns the value added
        /// </summary>
        /// <typeparam name="T">The type of list</typeparam>
        /// <param name="source">The list to add teh value to</param>
        /// <param name="item">The item to add to the list</param>
        /// <returns>The item added to the list</returns>
        public static T AddInline<T>(this IList<T> source, T item) { source.Add(item); return item; }

        /// <summary>
        /// Addes the given item to the list only if the item is not null
        /// </summary>
        /// <typeparam name="T">The type of list</typeparam>
        /// <param name="source">The list to add teh value to</param>
        /// <param name="item">The item to add to the list</param>
        /// <returns>The item added to the list</returns>
        public static T AddIfNotNull<T>(this IList<T> source, T item)
        {
            if (Tools.IsAllTrue(Tools.IsNull(source).Equals(false), Tools.IsNull(item).Equals(false)))
            {
                source.Add(item);
            }
            return item;
        }

        /// <summary>
        /// Determines whether or not the given value is in the set of items
        /// </summary>
        /// <typeparam name="T">The type of items being compared</typeparam>
        /// <param name="value">The value to look for</param>
        /// <param name="list">The set of items to look in for a match</param>
        /// <returns>True if the item is found in the list</returns>
        public static bool IsInList<T>(T value, params T[] list)
        {
            var output = false;
            foreach (var compareablevalue in list)
            {
                if (compareablevalue == null) { output |= value == null; }
                else { output |= compareablevalue.Equals(value); }
            }
            return output;
        }

        /// <summary>
        /// Similar to Enumerable.Aggregate, this method cycle over the values and performs the cumulation method on each one.
        /// </summary>
        /// <typeparam name="T">The type to cumulate</typeparam>
        /// <param name="cumulation">A method that aggregates two of the value at a time</param>
        /// <param name="seed">The initial value to start from. If null is passed, then default(T) is used</param>
        /// <param name="values">The values to cumulate</param>
        /// <returns>The resulting value</returns>
        public static T Cumulate<T>(Func<T, T, T> cumulation, T? seed, params T?[] values) where T : struct
        {
            var output = seed ?? default(T);
            if (values != null)
            {
                foreach (var value in values)
                {
                    if (value.HasValue.Equals(false)) { continue; }
                    output = cumulation(output, value.Value);
                }
            }
            return output;
        }

        /// <summary>
        /// Can be used to recursively iterate over nested item graphs such as nodes in a treeview and perform actions on each item
        /// </summary>
        /// <typeparam name="Item">The type of items contained in the collection</typeparam>
        /// <typeparam name="Collection">The container for the items</typeparam>
        /// <param name="collectionselector">A method that selects the nested collection on any item</param>
        /// <param name="processitem">The method to perform on each item</param>
        /// <param name="seed">The initial item to begin recursion from</param>
        public static void Recurse<Item, Collection>(Func<Item, Collection> collectionselector, Action<Item> processitem, Item seed) where Collection : IEnumerable<Item>
        {
            if (Tools.IsInList<object>(null, collectionselector, processitem, seed)) { return; }
            processitem(seed);
            var collection = collectionselector(seed);
            if (collection != null) { Tools.Iterate(collection, x => Tools.Recurse(collectionselector, processitem, x)); }
        }

        /// <summary>
        /// Creates a new instance of an IEqualityComparer for the given collection
        /// </summary>
        /// <typeparam name="T">The type of item in the collection</typeparam>
        /// <param name="collection">The collection</param>
        /// <param name="comparer">The method to use for comparing items to each other</param>
        /// <returns>An instance of a IEqualityComparer</returns>
        public static IEqualityComparer<T> CreateComparer<T>(this IEnumerable<T> collection, Func<T, T, bool> comparer)
        {
            return new Power.Types.EqualityComparer<T>(comparer);
        }

        /// <summary>
        /// Gets teh value, or if the value is null executes the getDefault method and returns it's result
        /// </summary>
        /// <typeparam name="T">The type to return</typeparam>
        /// <param name="value">The value returned</param>
        /// <param name="getDefault">The method to call if value is null. This method should return the fallback value</param>
        /// <returns>a value of type T</returns>
        public static T GetValueOrDefault<T>(this T value, Func<T> getDefault)
        {
            if (value == null) { return getDefault(); }
            return value;
        }

        #region Itemize

        public static IItemizer<T> Itemize<T>(this T value)
        {
            return new Itemizer<T>(value);
        }

        #endregion

        #region Try

        public static ITryResult Try(Action action)
        {
            return Try<object>(null, x => action());
        }

        public static ITryResult Try<T>(this T value, Action<T> action)
        {
            if (value == null) { return new TryResult(new ArgumentNullException("value")); }
            if (action == null) { return new TryResult(new ArgumentNullException("action")); }
            try
            {
                action(value);
                return new TryResult();
            }
            catch (Exception e) { return new TryResult(e); }
        }

        #endregion

        #region TrySelect

        public static ITryResult<T> TrySelect<T>(Func<T> selector)
        {
            return TrySelect<object, T>(null, x => selector());
        }

        public static ITryResult<TOut> TrySelect<T, TOut>(this T value, Func<T, TOut> selector)
        {
            if (value == null) { return new TryResult<TOut>(default(TOut), new ArgumentNullException("value")); }
            if (selector == null) { return new TryResult<TOut>(default(TOut), new ArgumentNullException("selector")); }
            try { return new TryResult<TOut>(selector(value)); }
            catch (Exception e) { return new TryResult<TOut>(default(TOut), e); };
        }

        #endregion

        #region With

        /// <summary>
        /// Executes the given action if the value passed in is not null
        /// </summary>
        /// <typeparam name="T">The value type to handle</typeparam>
        /// <param name="value">The value to handle</param>
        /// <param name="action">The action to execute against the value</param>
        /// <returns>The value passed in for short circuiting</returns>
        public static T With<T>(this T value, Action<T> action) where T : class
        {
            if (value != null) { action(value); }
            return value;
        }

        /// <summary>
        /// Executes the given action if the value passed in is not null
        /// </summary>
        /// <typeparam name="T">The value type to handle</typeparam>
        /// <param name="value">The value to handle</param>
        /// <param name="action">The action to execute against the value</param>
        /// <returns>The value passed in for short circuiting</returns>
        public static T? With<T>(this T? value, Action<T> action) where T : struct
        {
            if (value.HasValue) { action(value.Value); }
            return value;
        }

        #endregion

        #region WithSelect

        /// <summary>
        /// Executes the given method against the source and selects a value from it
        /// </summary>
        /// <typeparam name="S">The type of value being checked for null</typeparam>
        /// <typeparam name="T">The type of value being returned by the method</typeparam>
        /// <param name="source">The object to check for null</param>
        /// <param name="selector">The method to call against the source to select the return value</param>
        /// <returns>The value selected from the source by the select method</returns>
        public static T WithSelect<S, T>(this S source, Func<S, T> selector) where S : class
        {
            return source != null ? selector(source) : default(T);
        }

        /// <summary>
        /// Executes the given method against the source and selects a value from it
        /// </summary>
        /// <typeparam name="S">The type of value being checked for null</typeparam>
        /// <typeparam name="T">The type of value being returned by the method</typeparam>
        /// <param name="source">The object to check for null</param>
        /// <param name="selector">The method to call against the source to select the return value</param>
        /// <returns>The value selected from the source by the select method</returns>
        public static T WithSelect<S, T>(this S? source, Func<S, T> selector) where S : struct
        {
            return source.HasValue ? selector(source.Value) : default(T);
        }

        #endregion

        #region WithAs

        /// <summary>
        /// Executes the given action if the value passed in is not null if it successfully casts as the desired type
        /// </summary>
        /// <typeparam name="S">The type of value being checked for null</typeparam>
        /// <typeparam name="T">The type of value being returned by the method</typeparam>
        /// <param name="source">The object to check for null</param>
        /// <param name="action">The action to execute against the value</param>
        /// <returns>The value passed in for short circuiting after being cast to the desired type</returns>
        public static T WithAs<S, T>(this S source, Action<T> action)
            where S : class
            where T : class
        {
            var newSource = source as T;
            if (newSource != null) { action(newSource); }
            return newSource;
        }

        #endregion

        #region WithAsSelect

        /// <summary>
        /// Executes the given method against the source and selects a value from it
        /// </summary>
        /// <typeparam name="T">The type of value being checked for null</typeparam>
        /// <typeparam name="Y">The type of value being returned by the method</typeparam>
        /// <param name="source">The object to check for null</param>
        /// <param name="selector">The method to call against the source to select the return value</param>
        /// <returns>The value selected from the source by the select method</returns>
        public static O WithAsSelect<S, T, O>(this S source, Func<T, O> selector)
            where S : class
            where T : class
        {
            var newSource = source as T;
            return newSource != null ? selector(newSource) : default(O);
        }
        
        #endregion

        #region IsNull

        /// <summary>
        /// Checks the given value for null whether that be DbNull or just null
        /// </summary>
        /// <param name="value">The value to examine</param>
        /// <returns>True if value is either null or DbNull</returns>
        public static bool IsNull(object value) { return Tools.IsNull(value, DBNull.Value, null); }

        /// <summary>
        /// Checks the given value for null whether that be DbNull or just null
        /// </summary>
        /// <param name="value">The value to examine</param>
        /// <param name="valuesthatcountasnull">Values that will be used as a basis for comparison. Each value passed counts as a null value</param>
        /// <returns>True if value is equal to one of the values passed in</returns>
        public static bool IsNull(object value, params object[] valuesthatcountasnull) { return Tools.IsInList(value, valuesthatcountasnull); }

        #endregion

        #region If

        /// <summary>
        /// Returns one of two values based on the expression
        /// </summary>
        /// <typeparam name="T">The type of value to return</typeparam>
        /// <param name="expression">The expression to evaluate</param>
        /// <param name="truevalue">The value returned if the expression is true</param>
        /// <param name="falsevalue">The value to return if the expression is false</param>
        /// <returns>Either the truevalue or the falsevalue</returns>
        public static T If<T>(bool? expression, T truevalue, T falsevalue) { return expression ?? true ? truevalue : falsevalue; }

        /// <summary>
        /// Given the expression passed, will either execute the success action or the fail action
        /// </summary>
        /// <param name="expression">The expression to evaluate for success</param>
        /// <param name="successaction">The success action</param>
        /// <param name="failaction">The fail action</param>
        public static void If(bool? expression, Action successaction, Action failaction) { if (expression == true) { successaction(); } else { failaction(); } }

        #endregion

        #region Dequeue

        /// <summary>
        /// Gets the next item out of the queue. Can return null.
        /// </summary>
        /// <typeparam name="T">The type of item in the queue</typeparam>
        /// <param name="source">The queue to grab the next item from</param>
        /// <returns>The next item or null</returns>
        public static T Dequeue<T>(this System.Collections.Concurrent.ConcurrentQueue<T> source) where T : class
        {
            if (source == null) { return null; }
            var output = (T)null; source.TryDequeue(out output);
            return output;
        }

        /// <summary>
        /// Gets the next item out of the queue. Can return null.
        /// </summary>
        /// <typeparam name="T">The type of item in the queue</typeparam>
        /// <param name="source">The queue to grab the next item from</param>
        /// <returns>The next item or null</returns>
        public static Nullable<T> DequeueNullable<T>(this System.Collections.Concurrent.ConcurrentQueue<T> source) where T : struct
        {
            if (source == null) { return null; }
            T output; source.TryDequeue(out output);
            return output;
        }

        #endregion

        #region Iterate

        /// <summary>
        /// Iterates over the given collection in the same way a ForEach does
        /// </summary>
        /// <typeparam name="T">The type of collection being iterated</typeparam>
        /// <param name="source">The collection to iterate over</param>
        /// <param name="action">The action to perform on each item in the collection</param>
        /// <param name="startindex">The index to start performing actions on</param>
        /// <param name="endindex">The index to stop performing actions on</param>
        public static void Iterate<T>(this IEnumerable<T> source, Action<T> action, int? startindex = null, int? endindex = null)
        {
            if (source == null || action == null) { return; }
            var count = source.Count();
            var actualendindex = count;
            actualendindex = endindex.HasValue && (endindex.Value + 1) < count ? endindex.Value + 1 : count;
            for (var i = (startindex ?? 0); i < actualendindex; i++) { action((T)source.ElementAt(i)); }
        }

        /// <summary>
        /// Iterates over the given collection in the same way a ForEach does
        /// </summary>
        /// <typeparam name="T">The type of type of item contained in the source being iterated</typeparam>
        /// <param name="source">The collection to iterate over</param>
        /// <param name="action">The action to perform on each item in the collection</param>
        /// <param name="startindex">The index to start performing actions on</param>
        /// <param name="endindex">The index to stop performing actions on</param>
        public static void Iterate<T>(this System.Collections.IEnumerable source, Action<T> action, int? startindex = null, int? endindex = null)
        {
            source.Iterate<T>(x =>
            {
                action(x);
                return false;
            }, startindex, endindex);
        }

        /// <summary>
        /// Iterates over the given collection in the same way a ForEach does
        /// </summary>
        /// <typeparam name="T">The type of type of item contained in the source being iterated</typeparam>
        /// <param name="source">The collection to iterate over</param>
        /// <param name="action">The Func to perform on each item in the collection. Returning true from the Func will cause the loop to break.</param>
        /// <param name="startindex">The index to start performing actions on</param>
        /// <param name="endindex">The index to stop performing actions on</param>
        public static void Iterate<T>(this System.Collections.IEnumerable source, Func<T, bool> action, int? startindex = null, int? endindex = null)
        {
            if (source == null || action == null) { return; }
            var enumerator = source.GetEnumerator();
            var index = 0;
            while (enumerator.MoveNext())
            {
                if (startindex.HasValue && index < startindex.Value)
                {
                    index++;
                    continue;
                }
                if (endindex.HasValue && index > endindex.Value) { break; }
                var current = (T)enumerator.Current;
                if (action(current)) { break; }
            }
        }

        /// <summary>
        /// Iterates over the given collection in the same way a ForEach does
        /// </summary>
        /// <typeparam name="T">The type of collection being iterated</typeparam>
        /// <param name="source">The collection to iterate over</param>
        /// <param name="action">The action to perform on each item in the collection</param>
        /// <param name="startindex">The index to start performing actions on</param>
        /// <param name="endindex">The index to stop performing actions on</param>
        public static void Iterate(this System.Data.DataRowCollection source, Action<System.Data.DataRow> action, int? startindex = null, int? endindex = null)
        {
            if (source == null || action == null) { return; }
            var count = source.Count;
            var actualendindex = count;
            actualendindex = endindex.HasValue && (endindex.Value + 1) < count ? endindex.Value + 1 : count;
            for (var i = (startindex ?? 0); i < actualendindex; i++) { action(source[i]); }
        }

        /// <summary>
        /// Iterates over the given collection in the same way a ForEach does
        /// </summary>
        /// <typeparam name="T">The type of collection being iterated</typeparam>
        /// <param name="source">The collection to iterate over</param>
        /// <param name="action">The action to perform on each item in the collection</param>
        /// <param name="startindex">The index to start performing actions on</param>
        /// <param name="endindex">The index to stop performing actions on</param>
        public static void Iterate(this System.Data.DataColumnCollection source, Action<System.Data.DataColumn> action, int? startindex = null, int? endindex = null)
        {
            if (source == null || action == null) { return; }
            var count = source.Count;
            var actualendindex = count;
            actualendindex = endindex.HasValue && (endindex.Value + 1) < count ? endindex.Value + 1 : count;
            for (var i = (startindex ?? 0); i < actualendindex; i++) { action(source[i]); }
        }

        /// <summary>
        /// Iterates over the given collection in the same way a ForEach does
        /// </summary>
        /// <typeparam name="T">The type of collection being iterated</typeparam>
        /// <param name="source">The collection to iterate over</param>
        /// <param name="action">The action to perform on each item in the collection</param>
        /// <param name="startindex">The index to start performing actions on</param>
        /// <param name="endindex">The index to stop performing actions on</param>
        public static void Iterate(this System.Text.RegularExpressions.MatchCollection source, Action<System.Text.RegularExpressions.Match> action, int? startindex = null, int? endindex = null)
        {
            if (source == null || action == null) { return; }
            var count = source.Count;
            var actualendindex = count;
            actualendindex = endindex.HasValue && (endindex.Value + 1) < count ? endindex.Value + 1 : count;
            for (var i = (startindex ?? 0); i < actualendindex; i++) { action(source[i]); }
        }

        /// <summary>
        /// Iterates over the given collection in the same way a ForEach does
        /// </summary>
        /// <typeparam name="T">The type of collection being iterated</typeparam>
        /// <param name="source">The collection to iterate over</param>
        /// <param name="action">The action to perform on each item in the collection</param>
        /// <param name="startindex">The index to start performing actions on</param>
        /// <param name="endindex">The index to stop performing actions on</param>
        public static void Iterate(this System.Xml.XmlNodeList source, Action<System.Xml.XmlNode> action, int? startindex = null, int? endindex = null)
        {
            if (source == null || action == null) { return; }
            var count = source.Count;
            var actualendindex = count;
            actualendindex = endindex.HasValue && (endindex.Value + 1) < count ? endindex.Value + 1 : count;
            for (var i = (startindex ?? 0); i < actualendindex; i++) { action(source[i]); }
        }

        #endregion
    }
}
