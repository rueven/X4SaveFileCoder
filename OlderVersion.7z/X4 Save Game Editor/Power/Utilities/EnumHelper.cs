﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Power.Utilities
{
    public static class EnumHelper
    {
        /// <summary>
        /// A foreach construct for enums
        /// </summary>
        /// <typeparam name="T">The type of enum to loop over</typeparam>
        /// <param name="method">The method to handle each value in the enum</param>
        public static void ForEachValueInEnum<T>(Action<T> method) where T : struct, IComparable, IFormattable, IConvertible
        {
            if (method == null) { return; }
            foreach (T value in Enum.GetValues(typeof(T))) { method(value); }
        }

        /// <summary>
        /// Gets a distinct list of enum values
        /// </summary>
        /// <typeparam name="T">The type of enum</typeparam>
        /// <returns>A list of the type of enum</returns>
        public static List<T> GetDistinctEnumValues<T>() where T : struct, IComparable, IFormattable, IConvertible
        {
            return Enum.GetValues(typeof(T)).Cast<T>().ToList();
        }

        /// <summary>
        /// Parses a comma delimited string of enum names or integer values into a List&lt;T&gt; of that enum type.  This method is case-insensitive for enum names.  Note: It will ignore un-parseable values
        /// </summary>
        /// <typeparam name="T">Enum&apos; type</typeparam>
        /// <param name="csv">comma delimited string of enum names and/or integer values</param>
        /// <returns>List&lt;T&gt; of that enum type</returns>
        public static List<T> GetEnumValuesFromCsvString<T>(string csv) where T : struct, IComparable, IFormattable, IConvertible
        {
            if (string.IsNullOrEmpty(csv)) { return new List<T>(); }
            var names = EnumHelper.GetDistinctEnumValues<T>();
            return csv.Split(new char[] { ',' }, StringSplitOptions.RemoveEmptyEntries)
                .Select(x => DataHelper.ToNullableEnum<T>(x))
                .Where(x => x.HasValue)
                .Select(x => x.Value)
                .ToList();
        }

        /// <summary>
        /// Gets the any attribute of the given type from the value specified
        /// </summary>
        /// <typeparam name="T">The type of attribute</typeparam>
        /// <param name="value">The value to get the attribute from</param>
        /// <returns>The attribute if any exists or null</returns>
        public static T GetAttribute<T>(object value) where T : System.Attribute
        {
            if (value == null) { return null; }
            return value
                .GetType()
                .GetCustomAttributes(true)
                .OfType<T>()
                .FirstOrDefault();
        }
    }
}
