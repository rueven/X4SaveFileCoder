﻿using System;
using System.Data;

namespace Power.Utilities
{
    public static class DataReaderHelper
    {
        #region Methods extending functionality of the index reads

        public static short GetShort(this IDataReader reader, int index)
        {
            return reader.GetInt16(index);
        }

        public static int GetInt(this IDataReader reader, int index)
        {
            return reader.GetInt32(index);
        }

        public static long GetLong(this IDataReader reader, int index)
        {
            return reader.GetInt64(index);
        }

        public static TimeSpan GetTimeSpan(this IDataReader reader, int index)
        {
            var ticks = reader.GetInt64(index);
            return new TimeSpan(ticks);
        }

        public static bool? GetNullableBoolean(this IDataReader reader, int index)
        {
            return reader.IsDBNull(index) ? (bool?)null : reader.GetBoolean(index);
        }

        public static short? GetNullableInt16(this IDataReader reader, int index)
        {
            return reader.IsDBNull(index) ? (short?)null : reader.GetInt16(index);
        }

        public static int? GetNullableInt32(this IDataReader reader, int index)
        {
            return reader.IsDBNull(index) ? (int?)null : reader.GetInt32(index);
        }

        public static long? GetNullableInt64(this IDataReader reader, int index)
        {
            return reader.IsDBNull(index) ? (long?)null : reader.GetInt64(index);
        }

        public static short? GetNullableShort(this IDataReader reader, int index)
        {
            return reader.IsDBNull(index) ? (short?)null : reader.GetInt16(index);
        }

        public static int? GetNullableInt(this IDataReader reader, int index)
        {
            return reader.IsDBNull(index) ? (int?)null : reader.GetInt32(index);
        }

        public static long? GetNullableLong(this IDataReader reader, int index)
        {
            return reader.IsDBNull(index) ? (long?)null : reader.GetInt64(index);
        }

        public static byte? GetNullableByte(this IDataReader reader, int index)
        {
            return reader.IsDBNull(index) ? (byte?)null : reader.GetByte(index);
        }

        public static decimal? GetNullableDecimal(this IDataReader reader, int index)
        {
            return reader.IsDBNull(index) ? (decimal?)null : reader.GetDecimal(index);
        }

        public static float? GetNullableFloat(this IDataReader reader, int index)
        {
            return reader.IsDBNull(index) ? (float?)null : reader.GetFloat(index);
        }

        public static double? GetNullableDouble(this IDataReader reader, int index)
        {
            return reader.IsDBNull(index) ? (double?)null : reader.GetDouble(index);
        }

        public static DateTime? GetNullableDateTime(this IDataReader reader, int index)
        {
            return reader.IsDBNull(index) ? (DateTime?)null : reader.GetDateTime(index);
        }

        public static TimeSpan? GetNullableTimeSpan(this IDataReader reader, int index)
        {
            var ticks = reader.GetNullableInt64(index);
            return ticks.HasValue ? new TimeSpan(ticks.Value) : (TimeSpan?)null;
        }

        public static Guid? GetNullableGuid(this IDataReader reader, int index)
        {
            return reader.IsDBNull(index) ? (Guid?)null : reader.GetGuid(index);
        }

        public static byte[] GetBytes(this IDataReader reader, int index)
        {
            using (var stream = new System.IO.MemoryStream())
            {
                var buffer = new byte[1024];
                var offset = 0L;
                var bytesRead = 0L;
                do
                {
                    bytesRead = reader.GetBytes(index, offset, buffer, 0, buffer.Length);
                    stream.Write(buffer, 0, (int)bytesRead);
                    offset += bytesRead;
                } while (bytesRead >= buffer.Length);
                return stream.ToArray();
            }
        }

        public static byte[] GetByteArray(this IDataReader reader, int index)
        {
            return GetBytes(reader, index);
        }

        public static string GetNullableString(this IDataReader reader, int index)
        {
            return reader.IsDBNull(index) ? null : reader.GetString(index);
        }

        #endregion

        #region Overloaded methods that get columns by names

        public static bool GetBoolean(this IDataReader reader, string name)
        {
            return reader.GetBoolean(reader.GetOrdinal(name));
        }

        public static byte GetByte(this IDataReader reader, string name)
        {
            return reader.GetByte(reader.GetOrdinal(name));
        }

        public static long GetBytes(this IDataReader reader, string name, int i, long fieldOffset, byte[] buffer, int bufferoffset, int length)
        {
            return reader.GetBytes(reader.GetOrdinal(name), fieldOffset, buffer, bufferoffset, length);
        }

        public static char GetChar(this IDataReader reader, string name)
        {
            return reader.GetChar(reader.GetOrdinal(name));
        }

        public static long GetChars(this IDataReader reader, string name, long fieldoffset, char[] buffer, int bufferoffset, int length)
        {
            return reader.GetChars(reader.GetOrdinal(name), fieldoffset, buffer, bufferoffset, length);
        }
        
        public static IDataReader GetData(this IDataReader reader, string name)
        {
            return reader.GetData(reader.GetOrdinal(name));
        }

        public static string GetDataTypeName(this IDataReader reader, string name)
        {
            return reader.GetDataTypeName(reader.GetOrdinal(name));
        }
        
        public static DateTime GetDateTime(this IDataReader reader, string name)
        {
            return reader.GetDateTime(reader.GetOrdinal(name));
        }
        
        public static decimal GetDecimal(this IDataReader reader, string name)
        {
            return reader.GetDecimal(reader.GetOrdinal(name));
        }
        
        public static double GetDouble(this IDataReader reader, string name)
        {
            return reader.GetDouble(reader.GetOrdinal(name));
        }
        
        public static Type GetFieldType(this IDataReader reader, string name)
        {
            return reader.GetFieldType(reader.GetOrdinal(name));
        }

        public static float GetFloat(this IDataReader reader, string name)
        {
            return reader.GetFloat(reader.GetOrdinal(name));
        }

        public static Guid GetGuid(this IDataReader reader, string name)
        {
            return reader.GetGuid(reader.GetOrdinal(name));
        }

        public static short GetInt16(this IDataReader reader, string name)
        {
            return reader.GetInt16(reader.GetOrdinal(name));
        }

        public static int GetInt32(this IDataReader reader, string name)
        {
            return reader.GetInt32(reader.GetOrdinal(name));
        }

        public static long GetInt64(this IDataReader reader, string name)
        {
            return reader.GetInt64(reader.GetOrdinal(name));
        }
        
        public static string GetString(this IDataReader reader, string name)
        {
            return reader.GetNullableString(reader.GetOrdinal(name));
        }

        public static short GetShort(this IDataReader reader, string name)
        {
            return reader.GetInt16(reader.GetOrdinal(name));
        }

        public static int GetInt(this IDataReader reader, string name)
        {
            return reader.GetInt32(reader.GetOrdinal(name));
        }

        public static long GetLong(this IDataReader reader, string name)
        {
            return reader.GetInt64(reader.GetOrdinal(name));
        }

        public static TimeSpan GetTimeSpan(this IDataReader reader, string name)
        {
            return reader.GetTimeSpan(reader.GetOrdinal(name));
        }

        public static bool? GetNullableBoolean(this IDataReader reader, string name)
        {
            return reader.GetNullableBoolean(reader.GetOrdinal(name));
        }

        public static short? GetNullableInt16(this IDataReader reader, string name)
        {
            return reader.GetNullableInt16(reader.GetOrdinal(name));
        }

        public static int? GetNullableInt32(this IDataReader reader, string name)
        {
            return reader.GetNullableInt32(reader.GetOrdinal(name));
        }

        public static long? GetNullableInt64(this IDataReader reader, string name)
        {
            return reader.GetNullableInt64(reader.GetOrdinal(name));
        }

        public static short? GetNullableShort(this IDataReader reader, string name)
        {
            return reader.GetNullableShort(reader.GetOrdinal(name));
        }

        public static int? GetNullableInt(this IDataReader reader, string name)
        {
            return reader.GetNullableInt(reader.GetOrdinal(name));
        }

        public static long? GetNullableLong(this IDataReader reader, string name)
        {
            return reader.GetNullableLong(reader.GetOrdinal(name));
        }

        public static byte? GetNullableByte(this IDataReader reader, string name)
        {
            return reader.GetNullableByte(reader.GetOrdinal(name));
        }

        public static decimal? GetNullableDecimal(this IDataReader reader, string name)
        {
            return reader.GetNullableDecimal(reader.GetOrdinal(name));
        }

        public static float? GetNullableFloat(this IDataReader reader, string name)
        {
            return reader.GetNullableFloat(reader.GetOrdinal(name));
        }

        public static double? GetNullableDouble(this IDataReader reader, string name)
        {
            return reader.GetNullableDouble(reader.GetOrdinal(name));
        }

        public static DateTime? GetNullableDateTime(this IDataReader reader, string name)
        {
            return reader.GetNullableDateTime(reader.GetOrdinal(name));
        }

        public static TimeSpan? GetNullableTimeSpan(this IDataReader reader, string name)
        {
            return reader.GetNullableTimeSpan(reader.GetOrdinal(name));
        }

        public static Guid? GetNullableGuid(this IDataReader reader, string name)
        {
            return reader.GetNullableGuid(reader.GetOrdinal(name));
        }

        public static byte[] GetBytes(this IDataReader reader, string name)
        {
            return reader.GetBytes(reader.GetOrdinal(name));
        }

        public static byte[] GetByteArray(this IDataReader reader, string name)
        {
            return reader.GetByteArray(reader.GetOrdinal(name));
        }

        public static string GetNullableString(this IDataReader reader, string name)
        {
            return reader.GetNullableString(reader.GetOrdinal(name));
        }

        #endregion
    }
}
