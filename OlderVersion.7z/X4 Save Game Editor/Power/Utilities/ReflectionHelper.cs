﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Power.Utilities
{
    public static class ReflectionHelper
    {
        public static List<Type> GetTypesDerivedFrom<T>()
        {
            return ReflectionHelper.GetTypesDerivedFrom(typeof(T));
        }

        public static List<Type> GetTypesDerivedFrom(Type basetype)
        {
            var output = new List<Type>();
            foreach (var assembly in AppDomain.CurrentDomain.GetAssemblies())
            {
                output.AddRange(ReflectionHelper.GetTypesDerivedFrom(basetype, assembly));
            }
            return output;
        }

        public static List<Type> GetTypesDerivedFrom<T>(System.Reflection.Assembly assembly)
        {
            return ReflectionHelper.GetTypesDerivedFrom(typeof(T), assembly);
        }

        public static List<Type> GetTypesDerivedFrom(Type basetype, System.Reflection.Assembly assembly)
        {
            var output = new List<Type>();
            foreach (var type in assembly.GetTypes())
            {
                if (type.IsSubclassOf(basetype))
                {
                    output.Add(type);
                }
            }
            return output;
        }

        public static List<Type> GetTypesImplementing<T>()
        {
            return ReflectionHelper.GetTypesImplementing(typeof(T));
        }

        public static List<Type> GetTypesImplementing(Type interfacetype)
        {
            var output = new List<Type>();
            foreach (var assembly in AppDomain.CurrentDomain.GetAssemblies())
            {
                output.AddRange(ReflectionHelper.GetTypesImplementing(interfacetype, assembly));
            }
            return output;
        }

        public static List<Type> GetTypesImplementing<T>(System.Reflection.Assembly assembly)
        {
            return ReflectionHelper.GetTypesImplementing(typeof(T), assembly);
        }

        public static List<Type> GetTypesImplementing(Type interfacetype, System.Reflection.Assembly assembly)
        {
            var output = new List<Type>();
            foreach (var type in assembly.GetTypes())
            {
                if (type.IsInterface.Equals(false) && interfacetype.IsAssignableFrom(type))
                {
                    output.Add(type);
                }
            }
            return output;
        }

        public static List<T> InstantiateAll<T>(this IEnumerable<Type> collection)
        {
            var output = new List<T>();
            foreach (var value in collection)
            {
                output.Add((T)Activator.CreateInstance(value));
            }
            return output;
        }
    }
}
