﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml;
using NodeParser = Power.Types.NodeParser;

namespace Power.Utilities
{
    public static class XmlDocumentExtensions
    {
        public static XmlNode ResolveOrCreate(this XmlDocument document, string xpath, XmlNamespaceManager manager = null)
        {
            if (document == null) throw new ArgumentNullException("document");
            if (xpath == null) throw new ArgumentNullException("xpath");
            return document.ResolveOrCreate(document, xpath, manager);
        }

        public static XmlNode ResolveOrCreate(this XmlNode root, XmlDocument document, string xpath, XmlNamespaceManager manager = null)
        {
            if (document == null) throw new ArgumentNullException("document");
            if (xpath == null) throw new ArgumentNullException("xpath");
            var output = root.SelectSingleNode(xpath, manager);
            if (output != null) { return output; }
            var element = document.ExtractNext(root, ref xpath, manager);
            while (element != null)
            {
                output = element;
                element = document.ExtractNext(element, ref xpath, manager);
            }
            return output;
        }

        private static XmlNode ExtractNext(this XmlDocument document, XmlNode root, ref string xpath, XmlNamespaceManager manager)
        {
            if (document == null) throw new ArgumentNullException("document");
            if (root == null) throw new ArgumentNullException("root");
            if (string.IsNullOrEmpty(xpath)) return null;
            var nextsection = XmlDocumentExtensions.GetNextSection(xpath);
            xpath = xpath.Substring(nextsection.Length);
            if (nextsection.StartsWith("/")) nextsection = nextsection.Substring(1);
            var nextnode = root.SelectSingleNode(nextsection, manager);
            if (nextnode != null) return nextnode;
            nextnode = document.FabricateNode(root, nextsection, manager);
            return nextnode;
        }

        private static XmlNode FabricateNode(this XmlDocument document, XmlNode current, string singlepath, XmlNamespaceManager manager)
        {
            if (document == null) throw new ArgumentNullException("document");
            if (current == null) throw new ArgumentNullException("current");
            if (string.IsNullOrEmpty(singlepath)) throw new ArgumentNullException("singlepath");
            var parsed = NodeParser.Parse(singlepath);
            var node = document.FabricateNode(current, singlepath, parsed, manager);
            if (node == null) throw new Exception("Node was null and that is bad");
            if (string.IsNullOrEmpty(parsed.Value).Equals(false)) node.InnerText = parsed.Value;
            if (parsed.Predicates != null) { document.ResolvePredicate(node, parsed, manager); }
            return node;
        }

        private static XmlNode FabricateNode(this XmlDocument document, XmlNode current, string singlepath, NodeParser parsed, XmlNamespaceManager manager)
        {
            var namespaceuri = string.IsNullOrEmpty(parsed.Prefix) || manager == null ? null : manager.LookupNamespace(parsed.Prefix);
            //namespaceuri = string.IsNullOrEmpty(parsed.Prefix).Equals(false) && string.IsNullOrEmpty(namespaceuri) ? null : document.GetNamespaceOfPrefix(parsed.Prefix);
            if (singlepath.StartsWith("./")) { singlepath = singlepath.Substring(2, singlepath.Length - 2); }
            if (singlepath.StartsWith("@"))
            {
                if (current.Attributes != null)
                {
                    return current.Attributes.Append(document.CreateAttribute(parsed.Prefix, parsed.Name, namespaceuri)).With(x => x.Prefix = parsed.Prefix);
                }
                return null;
            }
            return current.AppendChild(document.CreateElement(parsed.Prefix, parsed.Name, namespaceuri)).With(x => x.Prefix = parsed.Prefix);
        }

        private static void ResolvePredicate(this XmlDocument document, XmlNode root, NodeParser parsed, XmlNamespaceManager manager)
        {
            if (document == null) throw new ArgumentNullException("document");
            if (root == null) throw new ArgumentNullException("root");
            if (parsed == null) throw new ArgumentNullException("parsed");
            foreach (var predicate in parsed.Predicates)
            {
                if (DataHelper.ToNullableInt32(predicate).HasValue) { continue; }
                var subpredicate = NodeParser.Parse(predicate.Trim());
                document.FabricateNode(root, subpredicate.RawName, manager);
            }
        }

        private static string GetNextSection(string xpath)
        {
            if (string.IsNullOrEmpty(xpath)) throw new ArgumentNullException("xpath");
            var next = new StringBuilder();
            var toggledepth = 0;
            var skipfirst = xpath.StartsWith("/");
            foreach (var character in xpath)
            {
                if (character == '[') toggledepth += 1;
                if (character == ']') toggledepth -= 1;
                if (skipfirst && character == '/') { skipfirst = false; }
                else
                {
                    if (character == '/' && toggledepth == 0)
                    {
                        return next.ToString();
                    }
                }
                next.Append(character);
            }
            return next.ToString();
        }
    }
}
