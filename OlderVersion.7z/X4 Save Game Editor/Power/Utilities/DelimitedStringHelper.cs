﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Power.Types;

namespace Power.Utilities
{
    public static class DelimitedStringHelper
    {
        #region CharacterPatternConstruction
        private class CharacterPatternConstruction
        {
            public enum ResultCodes
            {
                ContinuesMatch,
                CompletesMatch,
                NoMatch
            }

            public bool CaseSensitive { get; set; }
            private Dictionary<string, StringBuilder> ConstructedPatterns = new Dictionary<string, StringBuilder>();

            public ResultCodes Check(string pattern, char newCharacter)
            {
                if (this.ConstructedPatterns.ContainsKey(pattern))
                {
                    this.ConstructedPatterns[pattern].Append(newCharacter);
                    if (this.ContinuesPattern(pattern, this.ConstructedPatterns[pattern]).Equals(false))
                    {
                        this.ConstructedPatterns[pattern].Remove(0, this.ConstructedPatterns[pattern].Length);
                        return ResultCodes.NoMatch;
                    }
                }
                else
                {
                    this.ConstructedPatterns.Add(pattern, new StringBuilder(newCharacter.ToString()));
                    if (this.ContinuesPattern(pattern, this.ConstructedPatterns[pattern]).Equals(false))
                    {
                        this.ConstructedPatterns[pattern].Remove(0, this.ConstructedPatterns[pattern].Length);
                        return ResultCodes.NoMatch;
                    }
                }
                if (this.IsPattern(pattern, this.ConstructedPatterns[pattern]))
                {
                    this.ConstructedPatterns[pattern].Remove(0, this.ConstructedPatterns[pattern].Length);
                    return ResultCodes.CompletesMatch;
                }
                return ResultCodes.ContinuesMatch;
            }

            private bool ContinuesPattern(string pattern, string possibleMatch)
            {
                return this.CaseSensitive ? pattern.StartsWith(possibleMatch, StringComparison.CurrentCultureIgnoreCase) : pattern.StartsWith(possibleMatch);
            }
            private bool ContinuesPattern(string pattern, StringBuilder possibleMatch)
            {
                return this.CaseSensitive ? pattern.StartsWith(possibleMatch.ToString(), StringComparison.CurrentCultureIgnoreCase) : pattern.StartsWith(possibleMatch.ToString());
            }

            private bool IsPattern(string pattern, StringBuilder possibleMatch) { return this.IsPattern(pattern, possibleMatch.ToString()); }
            private bool IsPattern(string pattern, string possibleMatch)
            {
                if (this.CaseSensitive)
                {
                    if (this.ConstructedPatterns[pattern].ToString() == pattern)
                    {
                        this.ConstructedPatterns[pattern].Remove(0, this.ConstructedPatterns[pattern].Length);
                        return true;
                    }
                }
                else
                {
                    if (this.ConstructedPatterns[pattern].ToString().ToLower() == pattern.ToLower())
                    {
                        this.ConstructedPatterns[pattern].Remove(0, this.ConstructedPatterns[pattern].Length);
                        return true;
                    }
                }
                return false;
            }
        }
        #endregion

        public static System.Data.DataTable Execute(string body, string rowDelimiter = "\r\n", string columnDelimiter = ",", char escape = '"')
        {
            using (var reader = new System.IO.StringReader(body))
            {
                var output = DelimitedStringHelper.Execute(reader, rowDelimiter, columnDelimiter, escape);
                reader.Close();
                return output;
            }
        }

        public static System.Data.DataTable Execute(System.IO.TextReader reader, string rowDelimiter = "\r\n", string columnDelimiter = ",", char escape = '"')
        {
            var output = new System.Data.DataTable();
            DelimitedStringHelper.Execute(reader, x =>
            {
                if (x == null) { return; }
                while (x.Count > output.Columns.Count) { output.Columns.Add(); }
                var row = output.Rows.Add(x.ToArray());
            }, rowDelimiter, columnDelimiter, escape);
            return output;
        }

        public static void Execute(string body, Action<List<string>> onRowParsedDelegate, string rowDelimiter = "\r\n", string columnDelimiter = ",", char escape = '"')
        {
            using (var reader = new System.IO.StringReader(body))
            {
                DelimitedStringHelper.Execute(reader, onRowParsedDelegate, rowDelimiter, columnDelimiter, escape);
                reader.Close();
            }
        }

        public static void Execute(System.IO.TextReader reader, Action<List<string>> onRowParsedDelegate, string rowDelimiter = "\r\n", string columnDelimiter = ",", char escape = '"')
        {
            var row = new List<string>();
            DelimitedStringHelper.Execute
            (
                reader,
                x => row.Add(x),
                () =>
                {
                    onRowParsedDelegate(row);
                    row = new List<string>();
                },
                rowDelimiter,
                columnDelimiter,
                escape
            );
        }

        public static void Execute(string body, Action<string> signalNewField, Action signalEndObject, string rowDelimiter = "\r\n", string columnDelimiter = ",", char escape = '"')
        {
            using (var reader = new System.IO.StringReader(body))
            {
                DelimitedStringHelper.Execute(reader, signalNewField, signalEndObject, rowDelimiter, columnDelimiter, escape);
                reader.Close();
            }
        }

        public static void Execute(System.IO.TextReader reader, Action<string> signalNewField, Action signalEndObject, string rowDelimiter = "\r\n", string columnDelimiter = ",", char escape = '"')
        {
            if (signalNewField == null || signalEndObject == null) { return; }
            var patternChecker = new CharacterPatternConstruction();
            var currentString = new StringBuilder();
            var isEscaped = false;
            var lastCharacter = new char();
            var nextAction = Actions.AppendCharacter;
            while (reader.Peek() >= 0)
            {
                var c = (char)reader.Read();
                switch (DelimitedStringHelper.EvaluateEscape(escape, c, isEscaped, lastCharacter))
                {
                    case EscapeResults.AppendEmbeddedEscape:
                        isEscaped = !isEscaped;
                        nextAction = Actions.AppendCharacter;
                        break;
                    case EscapeResults.Escaped:
                        if (c == escape) { nextAction = Actions.Skip; }
                        else { nextAction = Actions.AppendCharacter; }
                        isEscaped = true;
                        break;
                    case EscapeResults.NotEscaped:
                    default:
                        isEscaped = false;
                        if (c == escape) { nextAction = Actions.Skip; }
                        else { nextAction = Actions.Undetermined; }
                        break;
                }
                if (!isEscaped && nextAction != Actions.Skip)
                {
                    switch (patternChecker.Check(columnDelimiter, c))
                    {
                        case CharacterPatternConstruction.ResultCodes.CompletesMatch:
                            nextAction = Actions.NewColumn;
                            break;
                        case CharacterPatternConstruction.ResultCodes.NoMatch:
                            nextAction = Actions.AppendCharacter;
                            break;
                        case CharacterPatternConstruction.ResultCodes.ContinuesMatch:
                            nextAction = Actions.Undetermined;
                            break;
                        default:
                            break;
                    }
                    if (nextAction != Actions.NewColumn)
                    {
                        switch (patternChecker.Check(rowDelimiter, c))
                        {
                            case CharacterPatternConstruction.ResultCodes.CompletesMatch:
                                nextAction = Actions.NewLine;
                                break;
                            case CharacterPatternConstruction.ResultCodes.NoMatch:
                                nextAction = Actions.AppendCharacter;
                                break;
                            case CharacterPatternConstruction.ResultCodes.ContinuesMatch:
                                nextAction = Actions.Undetermined;
                                break;
                            default:
                                break;
                        }
                    }
                }
                switch (nextAction)
                {
                    case Actions.AppendCharacter:
                        currentString.Append(c);
                        break;
                    case Actions.NewColumn:
                        signalNewField(currentString.ToString() == escape.ToString() ? string.Empty : currentString.ToString());
                        currentString.Remove(0, currentString.Length);
                        break;
                    case Actions.NewLine:
                        signalNewField(currentString.ToString() == escape.ToString() ? string.Empty : currentString.ToString());
                        currentString.Remove(0, currentString.Length);
                        signalEndObject();
                        break;
                    default:
                        break; // possibly lose characters here. Have to test that
                }
                lastCharacter = c;
            }
            signalNewField(currentString.ToString());
            currentString.Remove(0, currentString.Length);
            signalEndObject();
        }
        
        public static IDelimitedStringToEntityConverter CreateEntityConverter(string rowDelimiter = "\r\n", string columnDelimiter = ",", char escape = '"')
        {
            return new DelimitedStringToEntityConverter(rowDelimiter, columnDelimiter, escape);
        }

        private static EscapeResults EvaluateEscape(char escapeCharacter, char currentCharacter, bool isEscaped, char lastCharacter)
        {
            if (currentCharacter == escapeCharacter && isEscaped && lastCharacter == escapeCharacter) { return EscapeResults.NotEscaped; }
            if (currentCharacter == escapeCharacter && !isEscaped && lastCharacter == escapeCharacter) { return EscapeResults.AppendEmbeddedEscape; }
            if (currentCharacter == escapeCharacter && isEscaped && !(lastCharacter == escapeCharacter)) { return EscapeResults.NotEscaped; }
            if (currentCharacter == escapeCharacter && !isEscaped && !(lastCharacter == escapeCharacter)) { return EscapeResults.Escaped; }
            if (isEscaped) { return EscapeResults.Escaped; }
            else { return EscapeResults.NotEscaped; }
        }

        private enum EscapeResults
        {
            AppendEmbeddedEscape,
            Escaped,
            NotEscaped
        }

        private enum Actions
        {
            AppendCharacter,
            NewLine,
            NewColumn,
            Undetermined,
            Skip
        }
    }
}
