﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Text.RegularExpressions;

namespace Power.Utilities
{
    public static class DataHelper
    {
        #region IsNullOrEmpty
        public static bool IsNullOrEmpty(this string value)
        {
            return string.IsNullOrEmpty(value);
        }
        #endregion

        #region private Methods
        private static string MakeCompareable(string value, bool? ignorecase, bool? trim)
        {
            if (value == null) { return null; }
            if (string.IsNullOrEmpty(value)) { return string.Empty; }
            var output = (trim ?? false) ? value.Trim() : value;
            return (ignorecase ?? false) ? output.ToLowerInvariant() : output;
        }
        #endregion

        #region SafeCast
        public static T SafeCast<T>(object value)
        {
            if (value is T) { return (T)value; }
            return default(T);
        }
        #endregion

        #region ToString
        /// <summary>
        /// Converts the value to a string. Accounts for null
        /// </summary>
        /// <param name="value">The value to be converted</param>
        /// <returns>The converted value or null</returns>
        public static string ToString(object value)
        {
            if (value == null) { return null; }
            return value.ToString();
        }

        public static string ToString(string value, string defaultValue)
        {
            if (value == null) { return defaultValue; }
            return value;
        }
        #endregion

        #region ToEscapedDataString
        /// <summary>
        /// Converts the value to a Uri Escaped Data string in the same way as Uri.EscapeDataString. The difference is that the character limit is not enforced.
        /// </summary>
        /// <param name="value">The value to be converted to an uri escaped data string</param>
        /// <returns>The resulting uri escaped data string</returns>
        public static string ToEscapedDataString(object value)
        {
            if (Tools.IsNull(value)) { return null; }
            return DataHelper.ToEscapedDataString(value.ToString());
        }
        /// <summary>
        /// Converts the value to a Uri Escaped Data string in the same way as Uri.EscapeDataString. The difference is that the character limit is not enforced.
        /// </summary>
        /// <param name="value">The value to be converted to an uri escaped data string</param>
        /// <returns>The resulting uri escaped data string</returns>
        public static string ToEscapedDataString(string value)
        {
            var limit = 2000;
            var output = new StringBuilder();
            var loops = value.Length / limit;
            for (int i = 0; i <= loops; i++)
            {
                if (i < loops) { output.Append(Uri.EscapeDataString(value.Substring(limit * i, limit))); }
                else { output.Append(Uri.EscapeDataString(value.Substring(limit * i))); }
            }
            return output.ToString();
        }
        #endregion

        #region ToBoolean
        /// <summary>
        /// Converts the given value to a boolean. If the value is a string, then 1, true, yes, and on (case-insensitive) are all values that can be accepted.
        /// </summary>
        /// <param name="value">The value to be converted</param>
        /// <returns>The resulting value</returns>
        public static bool? ToNullableBoolean(object value)
        {
            if (Tools.IsNull(value)) { return null; }
            return DataHelper.ToNullableBoolean(value.ToString());
        }
        /// <summary>
        /// Converts the given value to a boolean. If the value is a string, then 1, true, yes, and on (case-insensitive) are all values that can be accepted.
        /// </summary>
        /// <param name="value">The value to be converted</param>
        /// <returns>The resulting value</returns>
        public static bool? ToNullableBoolean(string value)
        {
            if (string.IsNullOrEmpty(value)) { return null; }
            return " 1 true yes on y t ".Contains(" " + DataHelper.MakeCompareable(value, true, true) + " ");
        }
        /// <summary>
        /// Converts the given value to a boolean. If the value is a string, then 1, true, yes, and on (case-insensitive) are all values that can be accepted. False is returned if conversion fails.
        /// </summary>
        /// <param name="value">The value to be converted</param>
        /// <returns>The resulting value</returns>
        public static bool ToBoolean(object value, bool defaultValue) { return DataHelper.ToNullableBoolean(value) ?? defaultValue; }
        /// <summary>
        /// Converts the given value to a boolean. If the value is a string, then 1, true, yes, and on (case-insensitive) are all values that can be accepted. False is returned if conversion fails.
        /// </summary>
        /// <param name="value">The value to be converted</param>
        /// <returns>The resulting value</returns>
        public static bool ToBoolean(string value, bool defaultValue) { return DataHelper.ToNullableBoolean(value) ?? defaultValue; }
        #endregion

        #region ToDerivedDateTime
        /// <summary>
        /// Derives a date using the given format from the specified date and time
        /// </summary>
        /// <param name="format">The format to derive the date from</param>
        /// <param name="derivefrom">The date to derive the new date from</param>
        /// <returns>The resulting derived date</returns>
        /// <remarks>
        /// Useful for adapting a date via a string. Perhaps shaving off the hours and minutes
        /// </remarks>
        public static DateTime? ToNullableDerivedDate(string format, DateTime derivefrom)
        {
            if (string.IsNullOrEmpty(format).Equals(false)) { return null; }
            var value = derivefrom.ToString(format);
            return DataHelper.ToNullableDateTime(value);
        }

        /// <summary>
        /// Derives a date using the given format from the current date and time
        /// </summary>
        /// <param name="format">The format to derive the date from</param>
        /// <returns>The resulting derived date</returns>
        /// <remarks>
        /// Useful for adapting a date via a string. Perhaps shaving off the hours and minutes
        /// </remarks>
        public static DateTime? ToNullableDerivedDate(string format) { return DataHelper.ToNullableDerivedDate(format, DateTime.Now); }
        #endregion

        #region ToDateTime
        public static DateTime? ToNullableDateTime(object value)
        {
            if (Tools.IsNull(value)) { return null; }
            return DataHelper.ToNullableDateTime(DataHelper.MakeCompareable(value.ToString(), true, true));
        }
        public static DateTime? ToNullableDateTime(string value)
        {
            if (string.IsNullOrEmpty(value)) { return null; }
            DateTime output; if (DateTime.TryParse(value, out output)) { return output; } return null;
        }
        public static DateTime ToDateTime(object value, DateTime defaultvalue) { return DataHelper.ToNullableDateTime(value) ?? defaultvalue; }
        public static DateTime ToDateTime(string value, DateTime defaultvalue) { return DataHelper.ToNullableDateTime(value) ?? defaultvalue; }
        #endregion

        #region ToTimeSpan
        public static TimeSpan? ToNullableTimeSpan(object value)
        {
            if (Tools.IsNull(value)) { return null; }
            return DataHelper.ToNullableTimeSpan(DataHelper.MakeCompareable(value.ToString(), true, true));
        }
        public static TimeSpan? ToNullableTimeSpan(string value)
        {
            if (string.IsNullOrEmpty(value)) { return null; }
            TimeSpan output; if (TimeSpan.TryParse(value, out output)) { return output; } return null;
        }
        public static TimeSpan ToTimeSpan(string value, TimeSpan defaultvalue) { return DataHelper.ToNullableTimeSpan(value) ?? defaultvalue; }
        public static TimeSpan ToTimeSpan(object value, TimeSpan defaultvalue) { return DataHelper.ToNullableTimeSpan(value) ?? defaultvalue; }
        #endregion

        #region ToByte
        public static Byte? ToNullableByte(object value)
        {
            if (Tools.IsNull(value)) { return null; }
            return DataHelper.ToNullableByte(DataHelper.MakeCompareable(value.ToString(), true, true));
        }
        public static Byte? ToNullableByte(string value)
        {
            if (String.IsNullOrEmpty(value)) return null;
            byte output; if (Byte.TryParse(value, out output)) { return output; } return null;
        }
        public static Byte ToByte(object value, Byte defaultvalue) { return ToNullableByte(value) ?? defaultvalue; }
        public static Byte ToByte(string value, Byte defaultvalue) { return ToNullableByte(value) ?? defaultvalue; }
        #endregion

        #region ToInt16/Short
        public static short? ToNullableInt16(object value)
        {
            if (Tools.IsNull(value)) { return null; }
            return DataHelper.ToNullableInt16(DataHelper.MakeCompareable(value.ToString(), true, true));
        }
        public static short? ToNullableInt16(string value)
        {
            if (String.IsNullOrEmpty(value)) return null;
            short output; if (Int16.TryParse(value, out output)) { return output; } return null;
        }
        public static short ToInt16(object value, short defaultvalue) { return ToNullableInt16(value) ?? defaultvalue; }
        public static short ToInt16(string value, short defaultvalue) { return ToNullableInt16(value) ?? defaultvalue; }
        public static short? ToNullableShort(object value) { return ToNullableInt16(value); }
        public static short? ToNullableShort(string value) { return ToNullableInt16(value); }
        public static short ToShort(object value, short defaultvalue) { return ToNullableInt16(value) ?? defaultvalue; }
        public static short ToShort(string value, short defaultvalue) { return ToNullableInt16(value) ?? defaultvalue; }
        #endregion

        #region ToInt32/Int
        public static int? ToNullableInt32(object value)
        {
            if (Tools.IsNull(value)) { return null; }
            return DataHelper.ToNullableInt32(DataHelper.MakeCompareable(value.ToString(), true, true));
        }
        public static int? ToNullableInt32(string value)
        {
            if (String.IsNullOrEmpty(value)) return null;
            int output; if (int.TryParse(value, out output)) { return output; } return null;
        }
        public static int ToInt32(object value, int defaultvalue) { return ToNullableInt32(value) ?? defaultvalue; }
        public static int ToInt32(string value, int defaultvalue) { return ToNullableInt32(value) ?? defaultvalue; }
        public static int? ToNullableInt(object value) { return ToNullableInt32(value); }
        public static int? ToNullableInt(string value) { return ToNullableInt32(value); }
        public static int ToInt(object value, int defaultvalue) { return ToNullableInt32(value) ?? defaultvalue; }
        public static int ToInt(string value, int defaultvalue) { return ToNullableInt32(value) ?? defaultvalue; }
        #endregion

        #region ToInt64/Long
        public static long? ToNullableInt64(object value)
        {
            if (Tools.IsNull(value)) { return null; }
            return DataHelper.ToNullableInt64(DataHelper.MakeCompareable(value.ToString(), true, true));
        }
        public static long? ToNullableInt64(string value)
        {
            if (String.IsNullOrEmpty(value)) return null;
            Int64 output; if (Int64.TryParse(value, out output)) { return output; } return null;
        }
        public static long ToInt64(object value, Int64 defaultvalue) { return ToNullableInt64(value) ?? defaultvalue; }
        public static long ToInt64(string value, Int64 defaultvalue) { return ToNullableInt64(value) ?? defaultvalue; }
        public static long? ToNullableLong(object value) { return ToNullableInt64(value); }
        public static long? ToNullableLong(string value) { return ToNullableInt64(value); }
        public static long ToLong(object value, long defaultvalue) { return ToNullableInt64(value) ?? defaultvalue; }
        public static long ToLong(string value, long defaultvalue) { return ToNullableInt64(value) ?? defaultvalue; }
        #endregion

        #region ToDecimal
        public static decimal? ToNullableDecimal(object value)
        {
            if (Tools.IsNull(value)) { return null; }
            return DataHelper.ToNullableDecimal(DataHelper.MakeCompareable(value.ToString(), true, true));
        }
        public static decimal? ToNullableDecimal(string value)
        {
            if (String.IsNullOrEmpty(value)) return null;
            decimal output; if (decimal.TryParse(value, out output)) { return output; } return null;
        }
        public static decimal ToDecimal(object value, decimal defaultvalue) { return ToNullableDecimal(value) ?? defaultvalue; }
        public static decimal ToDecimal(string value, decimal defaultvalue) { return ToNullableDecimal(value) ?? defaultvalue; }
        #endregion

        #region ToFloat
        public static float? ToNullableFloat(object value)
        {
            if (Tools.IsNull(value)) { return null; }
            return DataHelper.ToNullableFloat(DataHelper.MakeCompareable(value.ToString(), true, true));
        }
        public static float? ToNullableFloat(string value)
        {
            if (String.IsNullOrEmpty(value)) return null;
            float output; if (float.TryParse(value, out output)) { return output; } return null;
        }
        public static float ToFloat(object value, float defaultvalue) { return ToNullableFloat(value) ?? defaultvalue; }
        public static float ToFloat(string value, float defaultvalue) { return ToNullableFloat(value) ?? defaultvalue; }
        #endregion

        #region ToNullableDecimalFromCurrency
        /// <summary>
        /// DataHelpers string representation of US currency to Nullable&lt;Decimal&gt;. Defaults to "en-US" culture.
        /// </summary>
        /// <param name="value"><example>$1.00</example></param>
        /// <returns><example>1.00</example></returns>
        public static decimal? ToNullableDecimalFromCurrency(string value)
        {
            if (String.IsNullOrEmpty(value)) return null;
            return DataHelper.ToNullableDecimalFromCurrency(value, "en-US");
        }

        /// <summary>
        /// DataHelpers string representation of currency to Nullable&lt;Decimal&gt; using specified culture
        /// </summary>
        /// <param name="value"><example>$1.00</example></param>
        /// <param name="culture"><example>en-US</example></param>
        /// <returns><example>1.00</example></returns>
        public static decimal? ToNullableDecimalFromCurrency(string value, string culturename)
        {
            if (String.IsNullOrEmpty(value)) return null;
            var style = System.Globalization.NumberStyles.Currency;
            var culture = System.Globalization.CultureInfo.CreateSpecificCulture(culturename);
            decimal output; if (decimal.TryParse(value.Trim(), style, culture, out output)) { return output; } return null;
        }
        #endregion

        #region ToDouble
        public static double? ToNullableDouble(object value)
        {
            if (Tools.IsNull(value)) { return null; }
            return DataHelper.ToNullableDouble(DataHelper.MakeCompareable(value.ToString(), true, true));
        }
        public static double? ToNullableDouble(string value)
        {
            if (String.IsNullOrEmpty(value)) return null;
            double output; if (double.TryParse(value, out output)) { return output; } return null;
        }
        public static double ToDouble(object value, double defaultvalue) { return ToNullableDouble(value) ?? defaultvalue; }
        public static double ToDouble(string value, double defaultvalue) { return ToNullableDouble(value) ?? defaultvalue; }
        #endregion

        #region ToEnum
        public static EnumType? ToNullableEnum<EnumType, UnderlyingType>(UnderlyingType value) where EnumType : struct, IComparable, IFormattable, IConvertible
        {
            if (!typeof(EnumType).IsEnum || Tools.IsNull(value)) { return default(EnumType?); }
            var output = EnumHelper
                .GetDistinctEnumValues<EnumType>()
                .FirstOrDefault(x => ((UnderlyingType)(object)x).Equals(value));
            return Enum.IsDefined(typeof(EnumType), output) ? output : (EnumType?)null;
        }
        public static EnumType? ToNullableEnum<EnumType>(object value) where EnumType : struct
        {
            return Tools.IsNull(value) ? default(EnumType?) : DataHelper.ToNullableEnum<EnumType>(value.ToString());
        }
        public static EnumType? ToNullableEnum<EnumType>(string value) where EnumType : struct
        {
            if (string.IsNullOrEmpty(value)) { return default(EnumType?); }
            EnumType output; return Enum.TryParse<EnumType>(value.Trim(), true, out output) ? output : default(EnumType?);
        }
        public static EnumType ToEnum<EnumType>(object value, EnumType defaultvalue) where EnumType : struct { return ToNullableEnum<EnumType>(value) ?? defaultvalue; }
        public static EnumType ToEnum<EnumType>(string value, EnumType defaultvalue) where EnumType : struct { return ToNullableEnum<EnumType>(value) ?? defaultvalue; }
        #endregion

        #region ToGuid
        public static Guid? ToNullableGuid(object value)
        {
            if (Tools.IsNull(value)) { return null; }
            return DataHelper.ToNullableGuid(DataHelper.MakeCompareable(value.ToString(), true, true));
        }
        public static Guid? ToNullableGuid(string value)
        {
            if (String.IsNullOrEmpty(value)) return null;
            Guid output; if (Guid.TryParse(value, out output)) { return output; } return null;
        }
        public static Guid ToGuid(object value, Guid defaultvalue) { return ToNullableGuid(value) ?? defaultvalue; }
        public static Guid ToGuid(string value, Guid defaultvalue) { return ToNullableGuid(value) ?? defaultvalue; }
        #endregion

        #region ToIpAddress
        public static System.Net.IPAddress ToIpAddress(object value)
        {
            if (Tools.IsNull(value)) { return null; }
            return DataHelper.ToIpAddress(value.ToString());
        }
        public static System.Net.IPAddress ToIpAddress(string value)
        {
            if (Tools.IsNull(value)) { return null; }
            System.Net.IPAddress output; if (System.Net.IPAddress.TryParse(value, out output)) { return output; } return null;
        }
        #endregion

        #region ToDelimitedString
        public static string ToDelimitedString<T>(IEnumerable<T> source, string columndelimiter, string fielddelimiter, bool removeemptyitems)
        {
            if (source == null) { return null; }
            var output = new System.Text.StringBuilder();
            var appendmethod = Tools.If<Action<object>>
            (
                string.IsNullOrEmpty(fielddelimiter),
                x => output.Append(x.ToString()),
                x => output.Append(x.ToString().Replace(fielddelimiter, fielddelimiter + fielddelimiter))
            );
            Tools.Iterate(source, delegate(T item)
            {
                output.Append(output.Length > 0 ? columndelimiter : string.Empty);
                output.Append(fielddelimiter ?? string.Empty);
                if (Tools.IsNull(item)) { if (removeemptyitems.Equals(false)) { appendmethod(string.Empty); } }
                else { appendmethod(item); }
                output.Append(fielddelimiter ?? string.Empty);
            });
            return output.ToString();
        }
        public static string ToDelimitedString<T>(IEnumerable<T> source) { return DataHelper.ToDelimitedString(source, ",", string.Empty, false); }
        public static string ToDelimitedString<T>(IEnumerable<T> source, string columndelimiter) { return DataHelper.ToDelimitedString(source, columndelimiter, string.Empty, false); }
        #endregion

        #region ToList<T>
        public static List<T> ToList<T>(string delimitedtext, Func<string, T> converter, string columndelimiter = ",", char escape = '"')
        {
            var output = new List<T>();
            DelimitedStringHelper.Execute
            (
                delimitedtext,
                field => Tools.AddIfNotNull(output, converter(field)),
                delegate() { },
                "\r\n",
                columndelimiter,
                escape
            );
            return output;
        }
        #endregion

        #region ToDataTable
        public static System.Data.DataTable ToDataTable(string value, string rowDelimiter, string columnDelimiter, char escape)
        {
            return DelimitedStringHelper.Execute
            (
                value,
                rowDelimiter,
                columnDelimiter,
                escape
            );
        }
        #endregion

        #region ToSqlDbType
        public static System.Data.SqlDbType? ToNullableSqlDbType(object value)
        {
            if (Tools.IsNull(value)) { return null; }
            return DataHelper.ToNullableSqlDbType(DataHelper.MakeCompareable(value.ToString(), true, true));
        }
        public static System.Data.SqlDbType? ToNullableSqlDbType(string value)
        {
            if (string.IsNullOrEmpty(value)) { return null; }
            return DataHelper.ToNullableEnum<System.Data.SqlDbType>(value);
        }
        public static System.Data.SqlDbType ToSqlDbType(object value, System.Data.SqlDbType defaultvalue) { return DataHelper.ToNullableSqlDbType(value) ?? defaultvalue; }
        public static System.Data.SqlDbType ToSqlDbType(string value, System.Data.SqlDbType defaultvalue) { return DataHelper.ToNullableSqlDbType(value) ?? defaultvalue; }
        #endregion

        #region ToWrittenOrdinal
        /// <summary>
        /// Given the number, converts it to it's ordinal written format. ie: 1st, 1nd, 3rd, etc
        /// </summary>
        /// <param name="value">The value to convert</param>
        /// <param name="zerobased">Whether or not the number being passed in is zero based. ie: zero is 1st</param>
        /// <returns>The converted string</returns>
        public static string ToWrittenOrdinal(long value, bool zerobased)
        {
            if (zerobased) { value++; }
            if (value == 11 || value == 12 || value == 13) { return value + "th"; }
            if (value.ToString().EndsWith("1")) { return value + "st"; }
            if (value.ToString().EndsWith("2")) { return value + "nd"; }
            if (value.ToString().EndsWith("3")) { return value + "rd"; }
            else { return value + "th"; }
        }
        /// <summary>
        /// Given the number, converts it to it's ordinal written format. ie: 1st, 1nd, 3rd, etc
        /// </summary>
        /// <param name="value">The value to convert</param>
        /// <param name="zerobased">Whether or not the number being passed in is zero based. ie: zero is 1st</param>
        /// <returns>The converted string</returns>
        public static string ToWrittenOrdinal(short value, bool zerobased) { return DataHelper.ToWrittenOrdinal((long)value, zerobased); }
        /// <summary>
        /// Given the number, converts it to it's ordinal written format. ie: 1st, 1nd, 3rd, etc
        /// </summary>
        /// <param name="value">The value to convert</param>
        /// <param name="zerobased">Whether or not the number being passed in is zero based. ie: zero is 1st</param>
        /// <returns>The converted string</returns>
        public static string ToWrittenOrdinal(int value, bool zerobased) { return DataHelper.ToWrittenOrdinal((long)value, zerobased); }
        /// <summary>
        /// Given the number, converts it to it's ordinal written format. ie: 1st, 1nd, 3rd, etc
        /// </summary>
        /// <param name="value">The value to convert</param>
        /// <param name="zerobased">Whether or not the number being passed in is zero based. ie: zero is 1st</param>
        /// <returns>The converted string</returns>
        public static string ToWrittenOrdinal(byte value, bool zerobased) { return DataHelper.ToWrittenOrdinal((long)value, zerobased); }
        #endregion

        #region ToWrittenNumbers
        private static string ToWrittenNumbers<T>(Nullable<T> value, bool iscurrency) where T : struct
        {
            if (value.HasValue.Equals(false)) { return string.Empty; }
            if (iscurrency) { return NumberToStringHelper.ChangeCurrencyToWords(value.Value.ToString()); }
            else { return NumberToStringHelper.ChangeNumericToWords(value.Value.ToString()); }
        }
        public static string ToWrittenNumbers(double? value, bool iscurrency)
        {
            return DataHelper.ToWrittenNumbers(value, iscurrency);
        }
        public static string ToWrittenNumbers(decimal? value, bool iscurrency)
        {
            return DataHelper.ToWrittenNumbers(value, iscurrency);
        }
        #endregion

        #region ToSquishedVin
        public static string ToSquishedVin(string vin)
        {
            if (string.IsNullOrEmpty(vin)) { return null; }
            if (vin.Length != 17) { return null; }
            var output = vin.Substring(0, 8);
            output += vin.Substring(9, 1);
            output += vin.Substring(10, 1);
            return output;
        }
        #endregion

        #region ToImage
        public static System.Drawing.Image ToImage(byte[] bytes)
        {
            return Power.Utilities.ImageHelper.ConvertToImage(bytes);
        }
        #endregion

        #region ToEmailAddress
        public static IEnumerable<System.Net.Mail.MailAddress> ToMailAddresses(string value)
        {
            var output = new System.Net.Mail.MailAddressCollection();
            output.Add(value);
            return output;
        }
        #endregion

        #region ToByteArray
        public static byte[] ToByteArray(this System.IO.Stream value)
        {
            if (value == null) { return null; }
            var stream = value as System.IO.MemoryStream;
            if (stream == null)
            {
                using (stream = new System.IO.MemoryStream())
                {
                    value.CopyTo(stream);
                    return stream.ToArray();
                }
            }
            else { return stream.ToArray(); }
        }

        public static byte[] ToByteArray(this string value, byte[] defaultValue, Encoding encoding = null)
        {
            if (value == null) { return null; }
            var encoder = encoding = encoding ?? System.Text.Encoding.UTF8;
            return encoder.GetBytes(value);
        }
        #endregion

        #region ToPhone
        public static Types.IParsedPhone ToPhone(this string value)
        {
            return Types
                .ParsedPhone
                .Parse(value);
        }
        #endregion

        #region ToQueryStringParameters

        public static string ToQueryStringParameters<T>(IEnumerable<KeyValuePair<string, T>> items, bool beginWithQuestionMark = true)
        {
            return items.ToQueryStringParameters(beginWithQuestionMark);
        }

        public static string ToQueryStringParameters<T>(IEnumerable<T> items, Func<T, string> extractLabel, Func<T, string> extractValue, bool beginWithQuestionMark = true)
        {
            return items.ToQueryStringParameters(extractLabel, extractValue, beginWithQuestionMark);
        }

        #endregion

        #region ToJsonString

        public static string ToJsonString<T>(IEnumerable<KeyValuePair<string, T>> items, Func<string, T, string> valueToString = null)
        {
            return items.ToJsonString(valueToString);
        }

        public static string ToJsonString<T>(IEnumerable<T> items, Func<T, string> extractLabel, Func<T, string> extractValue, bool wrapValue = false)
        {
            return items.ToJsonString(extractLabel, extractValue, wrapValue);
        }

        #endregion
    }
}
