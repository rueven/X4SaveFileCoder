﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Power.Types;

namespace Power.Utilities
{
    public static class IItemizerExtensions
    {
        #region ToQueryStringParameters

        public static string ToQueryStringParameters<T>(this IEnumerable<KeyValuePair<string, T>> items, bool beginWithQuestionMark = true)
        {
            if (items == null) { return null; }
            return items.ToQueryStringParameters<KeyValuePair<string, T>>
            (
                x => x.Key,
                x => DataHelper.ToString(x.Value),
                beginWithQuestionMark
            );
        }

        public static string ToQueryStringParameters(this IEnumerable<ItemizerItem> items, bool beginWithQuestionMark = true)
        {
            if (items == null) { return null; }
            return items.ToQueryStringParameters<ItemizerItem>
            (
                x => x.Name,
                x => DataHelper.ToString(x.Value),
                beginWithQuestionMark
            );
        }

        public static string ToQueryStringParameters<T>(this IEnumerable<T> items, Func<T, string> extractLabel, Func<T, string> extractValue, bool beginWithQuestionMark = true)
        {
            if (items == null) { return null; }
            if (extractLabel == null) { throw new ArgumentNullException("extractLabel"); }
            if (extractValue == null) { throw new ArgumentNullException("extractValue"); }
            return items.ToConvertedString
            (
                extractLabel,
                x => DataHelper.ToEscapedDataString(extractValue(x) ?? string.Empty),
                beginWithQuestionMark ? "?" : string.Empty,
                string.Empty,
                "=",
                "&",
                string.Empty
            );
        }

        #endregion

        #region ToJsonString

        public static string ToJsonString<T>(this IEnumerable<KeyValuePair<string, T>> items, Func<string, T, string> valueToString = null, bool removeEmptyItems = true)
        {
            if (items == null) { return null; }
            if (valueToString == null)
            {
                valueToString = (x, y) => DataHelper.ToString(y);
                return items.ToJsonString(x => x.Key, x => valueToString(x.Key, x.Value), true, removeEmptyItems: removeEmptyItems);
            }
            return items.ToJsonString(x => x.Key, x => valueToString(x.Key, x.Value), removeEmptyItems: removeEmptyItems);
        }

        public static string ToJsonString(this IEnumerable<ItemizerItem> items, Func<string, object, string> valueToString = null, bool removeEmptyItems = true)
        {
            if (items == null) { return null; }
            if (valueToString == null)
            {
                valueToString = (x, y) => DataHelper.ToString(y);
                return items.ToJsonString(x => x.Name, x => valueToString(x.Name, x.Value), true, removeEmptyItems);
            }
            return items.ToJsonString(x => x.Name, x => valueToString(x.Name, x.Value), removeEmptyItems: removeEmptyItems);
        }

        public static string ToJsonString<T>(this IEnumerable<T> items, Func<T, string> extractLabel, Func<T, string> extractValue, bool wrapValue = false, bool removeEmptyItems = true)
        {
            if (items == null) { return null; }
            if (extractLabel == null) { throw new ArgumentNullException("extractLabel"); }
            if (extractValue == null) { throw new ArgumentNullException("extractValue"); }
            return items.ToConvertedString(extractLabel, extractValue, "{", "\"", ":", ",", "}", wrapValue, removeEmptyItems);
        }

        #endregion

        public static IItemizer<T> AddProperties<T>(this IItemizer<T> itemizer)
        {
            if (itemizer == null) { return itemizer; }
            var type = typeof(T);
            var properties = type.GetProperties();
            foreach (var property in properties)
            {
                var p = property;
                itemizer.Add(property.Name, x => p.GetValue(x));
            }
            return itemizer;
        }

        public static IItemizer<T> AddPropertiesViaGetType<T>(this IItemizer<T> itemizer, T value)
        {
            if (itemizer == null) { return itemizer; }
            var type = value.GetType();
            var properties = type.GetProperties();
            foreach (var property in properties)
            {
                var p = property;
                itemizer.Add(property.Name, x => p.GetValue(value));
            }
            return itemizer;
        }

        public static IDictionary<string, object> ToDictionary(this IEnumerable<ItemizerItem> items)
        {
            return items.ToDictionary(x => x.Name, x => x.Value);
        }

        private static string ToConvertedString<T>(this IEnumerable<T> items, Func<T, string> extractLabel, Func<T, string> extractValue, string beginsWith, string wrapper, string equalitySignal, string itemEnd, string finalEnd, bool wrapValue = false, bool removeEmptyItems = true)
        {
            if (items == null) { return null; }
            if (extractLabel == null) { throw new ArgumentNullException("extractLabel"); }
            if (extractValue == null) { throw new ArgumentNullException("extractValue"); }
            var builder = new StringBuilder(beginsWith);
            foreach (var item in items)
            {
                var label = extractLabel(item);
                var value = extractValue(item);
                var isEmpty = string.IsNullOrWhiteSpace(value);
                if (!removeEmptyItems || (removeEmptyItems && !isEmpty))
                {
                    builder
                        .Append(wrapper)
                        .Append(label)
                        .Append(wrapper)
                        .Append(equalitySignal)
                        .Append(wrapValue ? wrapper : string.Empty)
                        .Append(value)
                        .Append(wrapValue ? wrapper : string.Empty)
                        .Append(itemEnd);
                }
            }
            var output = builder
                .ToString()
                .TrimEnd(itemEnd.ToCharArray());
            return output + finalEnd;
        }
    }
}
