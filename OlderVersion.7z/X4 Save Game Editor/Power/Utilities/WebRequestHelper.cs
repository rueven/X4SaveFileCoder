﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Power.Utilities
{
    public static class WebRequestHelper
    {
        public static System.Net.WebRequest Write(this System.Net.WebRequest request, string method = "GET", string mime = null, string content = null)
        {
            if (request == null) { throw new ArgumentNullException("request"); }
            request.Method = method;
            if (string.IsNullOrEmpty(mime).Equals(false)) { request.ContentType = mime; }
            if (string.IsNullOrEmpty(content)) { return request; }
            request.ContentLength = content.Length;
            using (var stream = request.GetRequestStream())
            {
                using (var writer = new System.IO.StreamWriter(stream))
                {
                    writer.Write(content);
                }
            }
            return request;
        }

        public static Power.Types.Response<string> Read(this System.Net.WebRequest request)
        {
            var output = (string)null;
            var exception = (Exception)null;
            request.Read(x => output = x.Read(), (e, x) =>
            {
                exception = e;
                output = x.Read();
            });
            return exception == null ? Power.Types.Response<string>.CreateSuccess(output) : Power.Types.Response<string>.CreateFail(exception).With(x => x.Body = output);
        }

        public static void Read(this System.Net.WebRequest request, Action<System.Net.WebResponse> handleSuccess, Action<System.Net.WebException, System.Net.WebResponse> handleFailure)
        {
            if (request == null) { throw new ArgumentNullException("request"); }
            try
            {
                using (var response = request.GetResponse())
                {
                    if (handleSuccess != null) { handleSuccess(response); }
                }
            }
            catch (System.Net.WebException e)
            {
                if (handleFailure != null) { handleFailure(e, e.Response); }
                e.Response.Dispose();
            }
        }

        public static string Read(this System.Net.WebResponse response)
        {
            if (response == null) { throw new ArgumentNullException("response"); }
            using (var responsestream = response.GetResponseStream())
            {
                using (var reader = new System.IO.StreamReader(responsestream))
                {
                    return reader.ReadToEnd();
                }
            }
        }

        #region Create Ftp Directory

        public static Power.Types.IFtpDirectory CreateFtpDirectory(string url, bool usePassive = true, bool keepAlive = true)
        {
            return new Power.Types.FtpDirectory(url)
            {
                
            };
        }

        public static Power.Types.IFtpDirectory CreateFtpDirectory(string url, string username, string password, bool usePassive = true, bool keepAlive = true)
        {
            return new Power.Types.FtpDirectory(url, username, password);
        }

        #endregion

        #region Upload Ftp File

        /// <summary>Uploads the given file to the FtpDirectory</summary>
        /// <param name="file">The file to write to the FtpDirectory</param>
        public static void Upload(this Power.Types.IFtpDirectory directory, System.IO.FileInfo file, int? timeout = null, int? readTimeout = null)
        {
            WebRequestHelper.Upload(directory, file, file.Name, timeout, readTimeout);
        }

        /// <summary>Uploads the given file to the FtpDirectory with the filename specified</summary>
        /// <param name="file">The file to write to the FtpDirectory</param>
        /// <param name="filename">The name that the file shouldhave when written to the FtpDirectory</param>
        public static void Upload(this Power.Types.IFtpDirectory directory, System.IO.FileInfo file, string filename, int? timeout = null, int? readTimeout = null)
        {
            using (var stream = file.OpenRead())
            {
                WebRequestHelper.Upload(directory, stream, filename, timeout, readTimeout);
            }
        }

        /// <summary>Uploads the given file to the FtpDirectory with the filename specified</summary>
        /// <param name="stream">The stream containing the content of the file to write to the FtpDirectory</param>
        /// <param name="filename">The name that the file shouldhave when written to the FtpDirectory</param>
        public static void Upload(this Power.Types.IFtpDirectory directory, System.IO.Stream stream, string filename, int? timeout = null, int? readTimeout = null)
        {
            WebRequestHelper
                .CreateFtpRequest(new Uri(directory.Uri.ToString().TrimEnd('/') + "/" + filename))
                .WithCredentials(directory.Username, directory.Password, directory.HasCredentials)
                .With(x=>
                {
                    x.Method = System.Net.WebRequestMethods.Ftp.UploadFile;
                    if (timeout.HasValue) { x.Timeout = timeout.Value; }
                    if (readTimeout.HasValue) { x.ReadWriteTimeout = readTimeout.Value; }
                    x.UsePassive = directory.UsePassive;
                    x.KeepAlive = directory.KeepAlive;
                    x.ContentLength = stream.Length;
                    using (var requeststream = x.GetRequestStream())
                    {
                        stream.CopyTo(requeststream);
                        requeststream.Close();
                    }
                });
        }

        public static void UploadFile(string ftpfilepath, string localfilepath, System.Net.NetworkCredential credentials, bool useproxy, bool keepAlive = true, bool usePassive = true)
        {
            var request = System.Net.WebRequest.Create(ftpfilepath) as System.Net.FtpWebRequest;
            request.KeepAlive = keepAlive;
            request.UsePassive = usePassive;
            request.Method = System.Net.WebRequestMethods.Ftp.UploadFile;
            request.ReadWriteTimeout = 1000 * 60 * 5;
            request.Timeout = 1000 * 60 * 2;
            request.Proxy = useproxy ? request.Proxy : null;
            request.Credentials = credentials ?? request.Credentials;
            Byte[] buffer;
            using (var stream = System.IO.File.OpenRead(localfilepath))
            {
                buffer = new byte[stream.Length];
                stream.Read(buffer, 0, buffer.Length);
                stream.Close();
            }
            request.ContentLength = buffer.Length;
            using (var requeststream = request.GetRequestStream())
            {
                requeststream.Write(buffer, 0, buffer.Length);
                requeststream.Flush();
                requeststream.Close();
            }
        }

        #endregion

        #region Download Ftp File

        /// <summary>Downloads the file specified from the remote location. The file is then readable via the readfile method</summary>
        /// <param name="file">The file to download</param>
        /// <param name="reader">The method to read the file with</param>
        public static void Download(this Power.Types.IFtpDirectory directory, Power.Types.IFtpFile file, Action<System.IO.Stream> reader)
        {
            if (directory == null) { throw new ArgumentNullException("directory"); }
            if (file == null) { throw new ArgumentNullException("file"); }
            if (reader == null) { throw new ArgumentNullException("reader"); }
            if (file.Directory != directory.Uri) { throw new ApplicationException("File is not associated with this FtpDirectory"); }
            file.Download(reader);
        }

        /// <summary>Downloads the file specified from the remote location. The file is then readable via the readfile method</summary>
        /// <param name="file">The file to download</param>
        /// <param name="reader">The method to read the file with</param>
        public static void Download(this Power.Types.IFtpFile file, Action<System.IO.Stream> reader)
        {
            if (file == null) { throw new ArgumentNullException("file"); }
            if (reader == null) { throw new ArgumentNullException("reader"); }
            var request = WebRequestHelper.CreateFtpRequest(new Uri(file.Directory.ToString().TrimEnd('/') + "/" + file.Filename));
            request.Method = System.Net.WebRequestMethods.Ftp.DownloadFile;
            using (var response = request.GetResponse())
            {
                using (var stream = response.GetResponseStream())
                {
                    reader(stream);
                }
            }
        }

        #endregion

        #region Enumerate Ftp Files

        /// <summary>Gets a list of all files in the directory</summary>
        /// <returns>A collection of strings. Each string being a filename</returns>
        public static IEnumerable<string> EnumerateFiles(this Power.Types.IFtpDirectory directory)
        {
            var output = new List<string>();
            WebRequestHelper.EnumerateFileListLines(directory, true, filename =>
            {
                if (string.IsNullOrEmpty(filename)) { return; }
                output.Add(filename);
            });
            return output;
        }

        /// <summary>Gets a detailed list of all files in the directory. Uses default parser to parse each line of the response.</summary>
        /// <returns>A collection of FtpFile objects as filled out by the default parser</returns>
        public static IEnumerable<Power.Types.IFtpFile> EnumerateFilesWithDetails(this Power.Types.IFtpDirectory directory)
        {
            return WebRequestHelper.EnumerateFilesWithDetails(directory, Power.Types.FtpDirectory.DefaultParser);
        }

        private static IEnumerable<Power.Types.IFtpFile> EnumerateFilesWithDetails(this Power.Types.IFtpDirectory directory, Func<string, Power.Types.FtpFile, bool> hydratefromstring)
        {
            if (hydratefromstring == null) { throw new ArgumentNullException("hydratefromstring"); }
            var output = new List<Power.Types.FtpFile>();
            WebRequestHelper.EnumerateFileListLines(directory, false, rawline =>
            {
                if (string.IsNullOrEmpty(rawline)) { return; }
                var item = new Power.Types.FtpFile() { Directory = directory.Uri };
                if (hydratefromstring(rawline, item))
                {
                    output.Add(item);
                }
            });
            return output;
        }

        private static void EnumerateFileListLines(this Power.Types.IFtpDirectory directory, bool simpleList, Action<string> handleLine)
        {
            WebRequestHelper
                .CreateFtpRequest(directory.Uri, directory.KeepAlive, directory.UsePassive)
                .WithCredentials(directory.Username, directory.Password, directory.HasCredentials)
                .With(x =>
                {
                    x.Method = simpleList ? System.Net.WebRequestMethods.Ftp.ListDirectory : System.Net.WebRequestMethods.Ftp.ListDirectoryDetails;
                    using (var response = x.GetResponse())
                    {
                        using (var stream = response.GetResponseStream())
                        {
                            using (var reader = new System.IO.StreamReader(stream))
                            {
                                while (reader.EndOfStream.Equals(false))
                                {
                                    handleLine(reader.ReadLine());
                                }
                            }
                        }
                    }
                });
        }

        #endregion

        public static T WithCredentials<T>(this T request, string username, string password, bool skip = false) where T:System.Net.WebRequest
        {
            if (request == null) { return null; }
            if (skip) { return request; }
            request.Credentials = new System.Net.NetworkCredential(username, password);
            return request;
        }

        internal static System.Net.FtpWebRequest CreateFtpRequest(Uri uri, bool keepAlive = true, bool usePassive = true)
        {
            return System
                .Net
                .FtpWebRequest
                .Create(uri)
                .WithSelect(x => x as System.Net.FtpWebRequest)
                .With(x =>
                {
                    x.KeepAlive = keepAlive;
                    x.UsePassive = usePassive;
                    x.ReadWriteTimeout = 1000 * 60 * 5;
                    x.Timeout = 1000 * 60 * 2;
                });
        }
    }
}
