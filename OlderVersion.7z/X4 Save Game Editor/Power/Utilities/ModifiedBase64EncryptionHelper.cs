﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Power.Utilities
{
    public class ModifiedBase64EncryptionHelper
    {
        private ModifiedBase64EncryptionHelper() { }

        /// <summary>
        /// Creates an instance of a ModifiedBase64Encryption object that assumes the given keys when encoding/decoding
        /// </summary>
        /// <param name="keys">A list of keys to use when encoding/decoding</param>
        /// <returns>An instance of a ModifiedBase64Encryption with the given keys used for encoding/decoding</returns>
        public static ModifiedBase64EncryptionHelper Create(List<string> keys)
        {
            return new ModifiedBase64EncryptionHelper()
            {
                Keys = keys
            };
        }

        /// <summary>
        /// Decodes a string in Base64 format into a standard string 
        /// </summary>
        /// <param name="data">The string to decode</param>
        /// <returns>The unencoded string</returns>
        public static string Base64Decode(string data)
        {
            return Encoding.Default.GetString(Convert.FromBase64String(data));
        }

        /// <summary>
        /// Encodes a string into a standard Base64 formatted string
        /// </summary>
        /// <param name="data">The string data to be encoded</param>
        /// <returns>A string of Base64 data containing the data given to encode</returns>
        public static string Base64Encode(string data)
        {
            return Convert.ToBase64String(Encoding.Default.GetBytes(data));
        }

        /// <summary>
        /// Decodes a string in modified Base64 format into a standard string. Modified format Base64 contains no special characters
        /// </summary>
        /// <param name="data">The string to decode</param>
        /// <returns>The unencoded string</returns>
        public static string ModifiedBase64Decode(string data)
        {
            var modifiedData = data
                .Replace(".a", "+")
                .Replace(".b", "=")
                .Replace(".c", "/");
            return ModifiedBase64EncryptionHelper
                .Base64Decode(modifiedData);
        }

        /// <summary>
        /// Encodes a string into a modified Base64 formatted string, containing no special characters.
        /// </summary>
        /// <param name="data">The string data to be encoded</param>
        /// <returns>A string of Base64 data containing the data given to encode</returns>
        public static string ModifiedBase64Encode(string data)
        {
            return ModifiedBase64EncryptionHelper
                .Base64Encode(data)
                .Replace("+", ".a")
                .Replace("=", ".b")
                .Replace("/", ".c");
        }

        /// <summary>
        /// Encrypts the given data against the given key.
        /// </summary>
        /// <param name="data">The data to encrypt</param>
        /// <param name="key">The key to encrypt the data with</param>
        /// <returns>The encrypted data</returns>
        public static string Encrypt(string data, string key)
        {
            var output = new char[data.Length];
            var characters = data.ToCharArray();
            var maskcharacters = new char[data.Length];
            maskcharacters = ModifiedBase64EncryptionHelper
                .CreateMask(key, characters.Length);
            for (var i = 0; i < characters.Length; i++)
            {
                var value = Convert.ToInt32(characters[i]) ^ Convert.ToInt32(maskcharacters[i]);
                output[i] = char.ConvertFromUtf32(value).ToCharArray()[0];
            }
            return new string(output);
        }

        /// <summary>
        /// Encrypts the given data against the given set of keys
        /// </summary>
        /// <param name="data">The data to encrypt</param>
        /// <param name="orderedkeys">A list of keys to encrypt the data with</param>
        /// <returns>The encrypted data</returns>
        public static string Encrypt(string data, List<string> orderedkeys)
        {
            var output = data;
            foreach (var key in orderedkeys)
            {
                output = ModifiedBase64EncryptionHelper
                    .Encrypt(output, key);
            }
            return output;
        }

        /// <summary>
        /// Creates a mask from a given key of a given length
        /// </summary>
        /// <param name="mask">The mask pattern to use</param>
        /// <param name="length">The length the mask is required to be</param>
        /// <returns>The mask to be used against a specified peice of data</returns>
        private static char[] CreateMask(string mask, int length)
        {
            var output = string.Empty;
            while (output.Length < length)
            {
                output += mask;
            }
            return output
                .Substring(0, length)
                .ToCharArray();
        }

        /// <summary>
        /// The list of keys used to encode/decode the data given the Encode() and Decode() functions
        /// </summary>
        private List<string> Keys { get; set; }

        /// <summary>
        /// Encodes the given data using the keys used to instantiate this class. This result is given in modified Base64 string format.
        /// </summary>
        /// <param name="data">the data to encode</param>
        /// <returns>A Modified Base64 string containing the encrypted data</returns>
        public string Encode(string data)
        {
            return ModifiedBase64EncryptionHelper
                .ModifiedBase64Encode(ModifiedBase64EncryptionHelper.Encrypt(data, this.Keys));
        }

        /// <summary>
        /// Decodes the given data using the keys used to instantiate this class. Returns the data in an unencrypted format.
        /// </summary>
        /// <param name="data">The data to decode</param>
        /// <returns>The decoded data</returns>
        public string Decode(string data)
        {
            return ModifiedBase64EncryptionHelper
                .Encrypt(ModifiedBase64EncryptionHelper.ModifiedBase64Decode(data), this.Keys);
        }
    }
}
