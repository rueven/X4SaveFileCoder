﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;
using System.Linq;
using System.Reflection;
using System.Security.Principal;
using System.Threading;

namespace Power.Utilities
{
    public static class StartupHelper
    {
        #region Static Properties
        private const string ParentProcessParameter = "ParentProcess";
        private const int CancelledRestartRequest = 1223;
        private static Mutex ApplicationMutex { get; set; }
        public static Assembly CurrentAssembly => Assembly
            .GetExecutingAssembly();
        public static Process CurrentProcess => Process
            .GetCurrentProcess();
        public static WindowsIdentity Identity => WindowsIdentity
            .GetCurrent();
        public static WindowsPrincipal Principal { get; } = new WindowsPrincipal(Identity);
        public static string ExecutableFilePath => CurrentProcess
            .MainModule
            .FileName;
        public static bool IsRunningAsAdministrator => Principal
            .IsInRole(WindowsBuiltInRole.Administrator);
        public static bool IsVisualStudioSession => CurrentProcess
            .MainModule
            .ModuleName
            .Contains(".vshost");
        #endregion

        public static string GetApplicationVersion()
        {
            var assembly = Assembly
                .GetExecutingAssembly();
            var fileVersionInfo = FileVersionInfo
                .GetVersionInfo(assembly.Location);
            var output = fileVersionInfo
                .ProductVersion;
            return output;
        }

        private static void RestartAsAdministrator(Action<string> auditor = null)
        {
            try
            {
                auditor?.Invoke($"Administrator check ({ExecutableFilePath})");
                try
                {
                    var process = Process
                        .Start(new ProcessStartInfo(ExecutableFilePath)
                        {
                            UseShellExecute = true,
                            Verb = "runas",
                            Arguments = $"/{StartupHelper.ParentProcessParameter}:{Process.GetCurrentProcess().Id}"
                        });
                    auditor?.Invoke($"Successfully started process with administrative priviledges ({process.Id})");
                }
                catch (Win32Exception ex)
                {
                    if (ex.NativeErrorCode == StartupHelper.CancelledRestartRequest)
                    {
                        auditor?.Invoke("This application must be run as administrator");
                    }
                    else { throw; }
                }
            }
            catch (Exception e)
            {
                auditor?.Invoke($"Unable to start application as administrator: {e}");
            }
        }

        public static void WaitOnParentProcess(string[] parameters)
        {
            var parentProcess = StartupHelper
                .FindParameterValue(parameters, StartupHelper.ParentProcessParameter)
                .Select(DataHelper.ToNullableInt32)
                .Where(x => x.HasValue)
                .FirstOrDefault();
            if (parentProcess.HasValue)
            {
                try
                {
                    var process = Process
                        .GetProcessById(parentProcess.Value);
                    if (process == null) { return; }
                    if (process.HasExited) { return; }
                    process.WaitForExit();
                }
                catch (Exception e)
                {
                    EventLog.WriteEntry("ReLauncher.Application", $"Could not wait on ProcessId ({parentProcess})): {e.ToString()}");
                }
            }
        }

        private static bool IsAlreadyRunning(string key)
        {
            var output = false;
            StartupHelper.ApplicationMutex = new Mutex(true, "ReLauncher", out output);
            return !output;
        }

        public static bool Initialize(string uniqueApplicationKey, bool allowMultipleAppInstances = false, bool enforceRunAsAdministrator = false, Action<string> auditor = null)
        {
            auditor = auditor ?? new Action<string>(x => EventLog.WriteEntry("ReLauncher", x));
            if (!allowMultipleAppInstances)
            {
                var isAlreadyRunning = StartupHelper
                    .IsAlreadyRunning(uniqueApplicationKey);
                if (isAlreadyRunning)
                {
                    auditor?.Invoke("This application is already running");
                    return false;
                }
            }
            if (StartupHelper.IsVisualStudioSession)
            {
                auditor?.Invoke($"This process is running via Visual Studio");
            }
            auditor?.Invoke("Running as administrator: " + (StartupHelper.IsRunningAsAdministrator ? "yes": "no"));
            if (enforceRunAsAdministrator && !StartupHelper.IsVisualStudioSession && !StartupHelper.IsRunningAsAdministrator)
            {
                StartupHelper
                    .RestartAsAdministrator(auditor);
                return false;
            }
            return true;
        }

        public static IReadOnlyList<string> FindParameterValue(string[] parameters, string name)
        {
            var output = new List<string>();
            var criteria = $"/{name}:";
            foreach (var argument in parameters)
            {
                if (argument.StartsWith(criteria, StringComparison.CurrentCultureIgnoreCase))
                {
                    var value = argument
                        .Substring(name.Length + 2)
                        .Trim();
                    output
                        .Add(value);
                }
            }
            return output;
        }

        public static void Cleanup()
        {
            StartupHelper
                .ApplicationMutex
                ?.ReleaseMutex();
            StartupHelper
                .ApplicationMutex
                ?.Dispose();
            StartupHelper
                .ApplicationMutex = null;
        }
    }
}
