﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Regex = System.Text.RegularExpressions.Regex;
using RegexOptions = System.Text.RegularExpressions.RegexOptions;

namespace Power.Utilities
{
    public static class General
    {
        private readonly static Regex LikeExpressionCreator = new Regex(@"\.|\$|\^|\{|\[|\(|\||\)|\*|\+|\?|\\", RegexOptions.Compiled);

        /// <summary>
        /// Levenshtein distance algorithm
        /// </summary>
        /// <param name="expected">The value that serves as the template</param>
        /// <param name="actual">The value being compared</param>
        /// <returns>The levenshtein difference between the two values</returns>
        public static int LevenshteinDifference(string expected, string actual)
        {
            var n = expected.Length;
            var m = actual.Length;
            var d = new int[n + 1, m + 1];
            // Step 1
            if (n == 0) { return m; }
            if (m == 0) { return n; }
            // Step 2
            for (int i = 0; i <= n; d[i, 0] = i++);
            for (int j = 0; j <= m; d[0, j] = j++);
            // Step 3
            for (int i = 1; i <= n; i++)
            {
                //Step 4
                for (int j = 1; j <= m; j++)
                {
                    // Step 5
                    var cost = (actual[j - 1] == expected[i - 1]) ? 0 : 1;
                    // Step 6
                    d[i, j] = Math.Min(Math.Min(d[i - 1, j] + 1, d[i, j - 1] + 1), d[i - 1, j - 1] + cost);
                }
            }
            // Step 7
            return d[n, m];
        }

        public static bool Like(this string text, string criteria)
        {
            if (text == null && criteria == null) { return true; }
            if (text == null) { return false; }
            var pattern = General
                .LikeExpressionCreator
                .Replace(criteria, ch => @"\" + ch)
                .Replace('_', '.')
                .Replace("%", ".*");
            var result = Regex.IsMatch(text, @"\A" + pattern + @"\z", RegexOptions.Compiled | RegexOptions.Singleline);
            return result;
        }

        /// <summary>
        /// Given a string value used as a key, compares that value against other specified values using case insensitive invariant matching
        /// </summary>
        /// <param name="key">The key to look for in values</param>
        /// <param name="values">The values that must match the key</param>
        /// <returns>True if one of the values match the key, false otherwise</returns>
        public static bool KeyedEquals(this string key, params string[] values)
        {
            return values != null && values.Any(x => string.Equals(key, x, StringComparison.InvariantCultureIgnoreCase));
        }
    }
}
