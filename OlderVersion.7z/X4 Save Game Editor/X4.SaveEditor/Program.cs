﻿using Power.Utilities;
using System;
using System.Collections.Generic;
using System.Data.Common;
using System.Linq;
using X4.Constants;
using X4.Extensions;
using X4.Models.Implementations;
using X4.Models.Interfaces;
using X4.Objects.Interfaces;
using X4.Services.Implementations;

namespace X4.SaveEditor
{
    public static class Program
    {
        public static CharacterBluePrintList Baldies { get; } = new CharacterBluePrintList()
        {
            { 1398050047, "character_pioneer_male_afr_crew_01_macro" },
            { 1748090323, "character_terran_male_afr_marine_01_macro" },
            { 413808341, "character_terran_male_asi_marine_01_macro" },
            { 1349618728, "character_terran_male_afr_pilot_01_macro" },
            { 2575357009, "character_scavenger_male_cau_01_macro" },
        };

        public static IReadOnlyCharacterBluePrint WellemWinger { get; } = new CharacterBluePrint()
        {
            Model = "character_pirate_male_cau_01_macro",
            Seed = 2774933323
        };

        public static IReadOnlyList<string> Prefixes { get; } = new List<string>()
        {
            "ACE",
            "GUN",
            "BAY",
            "HUT",
            "DEN",
            "INN",
            "BAR",
            "SPY",
            "EYE",
            "PAD",
            "PIT",
            "AXE",
            "LAB",
            "LAW",
            "MAP",
            "PUB",
            "RAY",
            "RED",
            "RIG",
            "RUN",
            "SKY",
            "TOP",
            "TUG",
            "VAN",
            "WAY",
            "WAR",
            "BOX",
            "ORE",
            "GAS",
            "OIL",
            "WEB",
            "ARK",
            "USE",
            "BIZ",
            "TIP",
            "OWN",
            "ART",
            "RAW",
            "SUN",
            "SOL",
            "CAR",
            "PAY",
            "YAP",
            "SAY",
            "SIR",
            "PIN",
            "BUS",
            "SUB",
            "NPC",
            "TAG",
            "BIT",
            "BUY",
            "TAX",
            "JOB",
            "ART",
            "DAY",
            "ACT",
            "VOW",
            "MOB",
            "TAB",
            "RAG",
            "ARM",
            "PUT",
            "CUT",
            "LOT",
            "SET",
            "KIT",
            "AID",
            "POD"
        };

        public static IReadOnlyList<string> Pilots { get; } = new List<string>()
        {
            "character_argon_male_cau_pilot_01_macro",
            "character_argon_male_asi_pilot_01_macro"
        };

        public static IReadOnlyList<string> Managers { get; } = new List<string>()
        {
            "character_argon_male_cau_crew_02_macro"
        };

        public static string TimelinesRed = "character_argon_male_asi_timelines_hub_random_macro";
        public static string LadyPilotWithGlasses = "15990400926056763815";
        public static string FormalTunic = "character_butler_male_cau_01_macro";
        /// <summary>
        /// The main entry point for the application.
        /// </summary>
        [STAThread]
        static void Main()
        {
            var service = new SaveFileService();
            var file = service
                .LoadFromGZipSlot(1);

            file.FindShipByCode("BUS-000", ship =>
            {
                ship.Pilot(pilot =>
                {
                    pilot.SetModel("character_argon_male_cau_pilot_01_macro");
                });
            });

            file.FindShipByCode("WAR-000", ship =>
            {
                ship.Pilot(pilot =>
                {
                    pilot.SetModel("character_argon_male_cau_crew_02_macro");
                });
            });

            file.FindShipByCode("ORE-005", ship =>
            {
                ship.Pilot(pilot =>
                {
                    pilot.SetModel("character_argon_male_cau_crew_02_macro");
                });
            });

            file.FindStationByCode("PAD-000", ship =>
            {
                ship.Manager(pilot =>
                {
                    pilot.SetModel("character_argon_male_cau_crew_02_macro");
                });
            });

            service.Save(file);
        }

        public static void AddInventoryToPlayer(this IPlayer player)
        {
            player
                .AddInventory("bomb_player_limpet_emp_01_mk1", 10)
                .AddInventory("bomb_player_limpet_mine_01_mk1")
                .AddInventory("engine_gen_spacesuit_01_mk2")
                .AddInventory("weapon_gen_spacesuit_laser_02_mk1")
                .AddInventory("weapon_gen_spacesuit_laser_03_mk1")
                .AddInventory("weapon_gen_spacesuit_demolition_01_mk1")
                .AddInventory("inv_remotedetonator", 1)
                .AddBluePrint("module_hab_arg_antigonespire_01")
                .AddBluePrint("module_conn_arg_antigonescaffolding_01")
                .AddBluePrint("module_conn_arg_antigonearc_01")
                .AddBluePrint("module_hab_arg_antigonepillar_01")
                .AddBluePrint("module_conn_arg_antigonestraight_01");
        }

        public static string Wrapped(string value) => "<connection connection=\"ships\">" + value + "</connection>";
    }
}
