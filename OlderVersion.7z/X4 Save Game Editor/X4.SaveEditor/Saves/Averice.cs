﻿using X4.Constants;
using X4.Extensions;
using X4.Objects.Interfaces;
using X4.Services.Implementations;

namespace X4.SaveEditor.Saves
{
    static class Averice
    {
        public static void Process(ISaveFile file)
        {
            file.FindShipByCode("HTP-432", ship =>
            {
                ship.TrainAllEmployees(CharacterTraitValue.Recruit);
            });
            file.FindShipByCode("WBE-546", ship =>
            {
                ship.WithEngineType(BluePrints.Engines.Argon.Medium.Combat.Mk3.AsMacro())
                    .WithShieldType(BluePrints.Shields.Terran.Medium.Mk3.AsMacro())
                    .WithThrusterType(BluePrints.Thrusters.Medium.Combat.Mk3.AsMacro())
                    .WithEngineModification()
                    .WithShieldsModification()
                    .WithWeaponModifications(reload: 1)
                    .WithStreamlinedHullChassisModification()
                    .Pilot(p => p.TrainPilotForRole(CharacterTraitValue.Elite));
            });

            var nomenclature = new ShipNomenclatureService()
                .AddBlackListedShipCode("NPC")
                .RegisterShipPrefixWithIncrementationFromCurrentHighestValue("GUN", x => x.IsFighter() || x.IsScout())
                .RegisterShipPrefixWithIncrementationFromCurrentHighestValue("WAR", x => x.IsWarship())
                .RegisterShipPrefixWithIncrementationFromCurrentHighestValue("BOX", x => x.IsTradeship())
                .RegisterShipPrefixWithIncrementationFromCurrentHighestValue("ORE", x => x.IsOreShip())
                .RegisterShipPrefixWithIncrementationFromCurrentHighestValue("GAS", x => x.IsGasShip());
            file.ForEachPlayerShip(nomenclature.RegisterShip);
            file.ForEachPlayerStation(nomenclature.RegisterStation);

            var result = nomenclature
                .Execute(file);
        }
    }
}
