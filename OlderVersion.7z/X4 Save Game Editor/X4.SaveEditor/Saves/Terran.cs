﻿using X4.Extensions;
using X4.Objects.Interfaces;
using X4.Services.Implementations;

namespace X4.SaveEditor.Saves
{
    static class Terran
    {
        public static void Process(ISaveFile file)
        {
            var nomenclature = new ShipNomenclatureService()
                .AddBlackListedShipCode("FGL", 696)
                .AddBlackListedShipCode("CAQ", 194)
                .AddBlackListedShipCode("DBL", 469)
                .AddBlackListedShipCode("BGE", 101)
                .AddBlackListedShipCode("IBL", 604)
                .AddBlackListedShipCode("GQH", 722)
                .AddBlackListedShipCode("XFK", 273)
                .AddBlackListedShipCode("ACE")
                .AddBlackListedShipCode("EYE")
                .RegisterShipSkip(x => x.Model == "ship_pir_s_fighter_01_a_macro")
                .RegisterStationPrefixStartingFromValue("LAB", 1, x => x.IsPlayerHeadQuarters(), true)
                .RegisterStationPrefixStartingFromValue("BAY", 1, x => x.HasConstructionDock(), true)
                .RegisterStationPrefixStartingFromValue("FIX", 1, x => x.HasEquipmentDock(), true)
                .RegisterStationPrefixStartingFromValue("ART", 1, x => x.HasProductionModules(), true)
                .RegisterStationPrefixStartingFromValue("LAW", 1, x => x.HasDefensiveClaim(), true)
                .RegisterStationPrefixStartingFromValue("PAD", 1, x => true, true)
                .RegisterShipSkip(x => x.IsFighterDrone())
                .RegisterShipPrefixWithIncrementationFromCurrentHighestValue("TUG", x => x.IsTug())
                .RegisterShipPrefixWithIncrementationFromCurrentHighestValue("RAW", x => x.IsScrapper())
                .RegisterShipPrefixWithIncrementationFromCurrentHighestValue("RIG", x => x.IsBuilder())
                .RegisterShipPrefixWithIncrementationFromCurrentHighestValue("SPY", x => x.IsScout())
                .RegisterShipPrefixWithIncrementationFromCurrentHighestValue("GUN", x => x.IsFighter())
                .RegisterShipPrefixWithIncrementationFromCurrentHighestValue("WAR", x => x.IsWarship())
                .RegisterShipPrefixWithBackfill("BOX", x => x.IsTradeship())
                .RegisterShipPrefixWithBackfill("GAS", x => x.IsGasShip())
                .RegisterShipPrefixWithBackfill("ORE", x => x.IsOreShip());
            file.ForEachPlayerShip(nomenclature.RegisterShip);
            file.ForEachPlayerStation(nomenclature.RegisterStation);
            var result = nomenclature
                .Execute(file);

            file.ForEachPlayerShip(ship =>
            {
                if (ship.Code.StartsWith("BOX") || ship.Code.StartsWith("GAS") || ship.Code.StartsWith("ORE") || ship.Code.StartsWith("RIG") || ship.Code.StartsWith("TUG"))
                {
                    ship.WithPaintJob(Constants.PaintMods.CaptainPearle);
                }
            });
        }
    }
}
